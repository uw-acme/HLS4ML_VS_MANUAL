#include "dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_0_V_fu_25471_p2() {
    acc_0_V_fu_25471_p2 = (!add_ln703_71_fu_25443_p2.read().is_01() || !add_ln703_81_fu_25466_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_71_fu_25443_p2.read()) + sc_biguint<18>(add_ln703_81_fu_25466_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_10_V_fu_25750_p2() {
    acc_10_V_fu_25750_p2 = (!add_ln703_271_fu_25726_p2.read().is_01() || !add_ln703_281_fu_25745_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_271_fu_25726_p2.read()) + sc_biguint<18>(add_ln703_281_fu_25745_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_11_V_fu_25769_p2() {
    acc_11_V_fu_25769_p2 = (!add_ln703_291_fu_25760_p2.read().is_01() || !add_ln703_300_fu_25765_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_291_fu_25760_p2.read()) + sc_biguint<18>(add_ln703_300_fu_25765_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_12_V_fu_25788_p2() {
    acc_12_V_fu_25788_p2 = (!add_ln703_310_fu_25779_p2.read().is_01() || !add_ln703_320_fu_25784_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_310_fu_25779_p2.read()) + sc_biguint<18>(add_ln703_320_fu_25784_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_13_V_fu_25820_p2() {
    acc_13_V_fu_25820_p2 = (!add_ln703_330_fu_25798_p2.read().is_01() || !add_ln703_340_fu_25815_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_330_fu_25798_p2.read()) + sc_biguint<18>(add_ln703_340_fu_25815_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_14_V_fu_25857_p2() {
    acc_14_V_fu_25857_p2 = (!add_ln703_350_fu_25833_p2.read().is_01() || !add_ln703_360_fu_25852_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_350_fu_25833_p2.read()) + sc_biguint<18>(add_ln703_360_fu_25852_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_15_V_fu_25876_p2() {
    acc_15_V_fu_25876_p2 = (!add_ln703_370_fu_25867_p2.read().is_01() || !add_ln703_380_fu_25872_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_370_fu_25867_p2.read()) + sc_biguint<18>(add_ln703_380_fu_25872_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_16_V_fu_25913_p2() {
    acc_16_V_fu_25913_p2 = (!add_ln703_390_fu_25889_p2.read().is_01() || !add_ln703_400_fu_25908_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_390_fu_25889_p2.read()) + sc_biguint<18>(add_ln703_400_fu_25908_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_17_V_fu_25932_p2() {
    acc_17_V_fu_25932_p2 = (!add_ln703_410_fu_25923_p2.read().is_01() || !add_ln703_420_fu_25928_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_410_fu_25923_p2.read()) + sc_biguint<18>(add_ln703_420_fu_25928_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_18_V_fu_25951_p2() {
    acc_18_V_fu_25951_p2 = (!add_ln703_430_fu_25942_p2.read().is_01() || !add_ln703_440_fu_25947_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_430_fu_25942_p2.read()) + sc_biguint<18>(add_ln703_440_fu_25947_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_19_V_fu_25970_p2() {
    acc_19_V_fu_25970_p2 = (!add_ln703_450_fu_25961_p2.read().is_01() || !add_ln703_460_fu_25966_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_450_fu_25961_p2.read()) + sc_biguint<18>(add_ln703_460_fu_25966_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_1_V_fu_25490_p2() {
    acc_1_V_fu_25490_p2 = (!add_ln703_91_fu_25481_p2.read().is_01() || !add_ln703_101_fu_25486_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_91_fu_25481_p2.read()) + sc_biguint<18>(add_ln703_101_fu_25486_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_20_V_fu_25989_p2() {
    acc_20_V_fu_25989_p2 = (!add_ln703_470_fu_25980_p2.read().is_01() || !add_ln703_480_fu_25985_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_470_fu_25980_p2.read()) + sc_biguint<18>(add_ln703_480_fu_25985_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_21_V_fu_26008_p2() {
    acc_21_V_fu_26008_p2 = (!add_ln703_490_fu_25999_p2.read().is_01() || !add_ln703_500_fu_26004_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_490_fu_25999_p2.read()) + sc_biguint<18>(add_ln703_500_fu_26004_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_22_V_fu_26027_p2() {
    acc_22_V_fu_26027_p2 = (!add_ln703_511_fu_26018_p2.read().is_01() || !add_ln703_520_fu_26023_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_511_fu_26018_p2.read()) + sc_biguint<18>(add_ln703_520_fu_26023_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_23_V_fu_26046_p2() {
    acc_23_V_fu_26046_p2 = (!add_ln703_530_fu_26037_p2.read().is_01() || !add_ln703_540_fu_26042_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_530_fu_26037_p2.read()) + sc_biguint<18>(add_ln703_540_fu_26042_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_24_V_fu_26083_p2() {
    acc_24_V_fu_26083_p2 = (!add_ln703_550_fu_26059_p2.read().is_01() || !add_ln703_560_fu_26078_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_550_fu_26059_p2.read()) + sc_biguint<18>(add_ln703_560_fu_26078_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_25_V_fu_26102_p2() {
    acc_25_V_fu_26102_p2 = (!add_ln703_570_fu_26093_p2.read().is_01() || !add_ln703_580_fu_26098_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_570_fu_26093_p2.read()) + sc_biguint<18>(add_ln703_580_fu_26098_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_26_V_fu_26121_p2() {
    acc_26_V_fu_26121_p2 = (!add_ln703_590_fu_26112_p2.read().is_01() || !add_ln703_600_fu_26117_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_590_fu_26112_p2.read()) + sc_biguint<18>(add_ln703_600_fu_26117_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_27_V_fu_26140_p2() {
    acc_27_V_fu_26140_p2 = (!add_ln703_610_fu_26131_p2.read().is_01() || !add_ln703_620_fu_26136_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_610_fu_26131_p2.read()) + sc_biguint<18>(add_ln703_620_fu_26136_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_28_V_fu_26172_p2() {
    acc_28_V_fu_26172_p2 = (!add_ln703_630_fu_26150_p2.read().is_01() || !add_ln703_640_fu_26167_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_630_fu_26150_p2.read()) + sc_biguint<18>(add_ln703_640_fu_26167_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_29_V_fu_26213_p2() {
    acc_29_V_fu_26213_p2 = (!add_ln703_650_fu_26185_p2.read().is_01() || !add_ln703_660_fu_26208_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_650_fu_26185_p2.read()) + sc_biguint<18>(add_ln703_660_fu_26208_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_2_V_fu_25513_p2() {
    acc_2_V_fu_25513_p2 = (!add_ln703_111_fu_25500_p2.read().is_01() || !add_ln703_121_fu_25508_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_111_fu_25500_p2.read()) + sc_biguint<18>(add_ln703_121_fu_25508_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_30_V_fu_26260_p2() {
    acc_30_V_fu_26260_p2 = (!add_ln703_670_fu_26229_p2.read().is_01() || !add_ln703_680_fu_26255_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_670_fu_26229_p2.read()) + sc_biguint<18>(add_ln703_680_fu_26255_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_31_V_fu_26279_p2() {
    acc_31_V_fu_26279_p2 = (!add_ln703_690_fu_26270_p2.read().is_01() || !add_ln703_700_fu_26275_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_690_fu_26270_p2.read()) + sc_biguint<18>(add_ln703_700_fu_26275_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_32_V_fu_26316_p2() {
    acc_32_V_fu_26316_p2 = (!add_ln703_710_fu_26292_p2.read().is_01() || !add_ln703_720_fu_26311_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_710_fu_26292_p2.read()) + sc_biguint<18>(add_ln703_720_fu_26311_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_33_V_fu_26339_p2() {
    acc_33_V_fu_26339_p2 = (!add_ln703_730_fu_26326_p2.read().is_01() || !add_ln703_740_fu_26334_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_730_fu_26326_p2.read()) + sc_biguint<18>(add_ln703_740_fu_26334_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_34_V_fu_26380_p2() {
    acc_34_V_fu_26380_p2 = (!add_ln703_750_fu_26352_p2.read().is_01() || !add_ln703_760_fu_26375_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_750_fu_26352_p2.read()) + sc_biguint<18>(add_ln703_760_fu_26375_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_35_V_fu_26417_p2() {
    acc_35_V_fu_26417_p2 = (!add_ln703_770_fu_26393_p2.read().is_01() || !add_ln703_780_fu_26412_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_770_fu_26393_p2.read()) + sc_biguint<18>(add_ln703_780_fu_26412_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_36_V_fu_26440_p2() {
    acc_36_V_fu_26440_p2 = (!add_ln703_790_fu_26427_p2.read().is_01() || !add_ln703_800_fu_26435_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_790_fu_26427_p2.read()) + sc_biguint<18>(add_ln703_800_fu_26435_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_37_V_fu_26459_p2() {
    acc_37_V_fu_26459_p2 = (!add_ln703_810_fu_26450_p2.read().is_01() || !add_ln703_820_fu_26455_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_810_fu_26450_p2.read()) + sc_biguint<18>(add_ln703_820_fu_26455_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_38_V_fu_26478_p2() {
    acc_38_V_fu_26478_p2 = (!add_ln703_830_fu_26469_p2.read().is_01() || !add_ln703_840_fu_26474_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_830_fu_26469_p2.read()) + sc_biguint<18>(add_ln703_840_fu_26474_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_39_V_fu_26497_p2() {
    acc_39_V_fu_26497_p2 = (!add_ln703_850_fu_26488_p2.read().is_01() || !add_ln703_860_fu_26493_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_850_fu_26488_p2.read()) + sc_biguint<18>(add_ln703_860_fu_26493_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_3_V_fu_25532_p2() {
    acc_3_V_fu_25532_p2 = (!add_ln703_131_fu_25523_p2.read().is_01() || !add_ln703_141_fu_25528_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_131_fu_25523_p2.read()) + sc_biguint<18>(add_ln703_141_fu_25528_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_40_V_fu_26516_p2() {
    acc_40_V_fu_26516_p2 = (!add_ln703_870_fu_26507_p2.read().is_01() || !add_ln703_880_fu_26512_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_870_fu_26507_p2.read()) + sc_biguint<18>(add_ln703_880_fu_26512_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_41_V_fu_26548_p2() {
    acc_41_V_fu_26548_p2 = (!add_ln703_890_fu_26526_p2.read().is_01() || !add_ln703_900_fu_26543_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_890_fu_26526_p2.read()) + sc_biguint<18>(add_ln703_900_fu_26543_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_42_V_fu_26589_p2() {
    acc_42_V_fu_26589_p2 = (!add_ln703_910_fu_26561_p2.read().is_01() || !add_ln703_920_fu_26584_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_910_fu_26561_p2.read()) + sc_biguint<18>(add_ln703_920_fu_26584_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_43_V_fu_26608_p2() {
    acc_43_V_fu_26608_p2 = (!add_ln703_930_fu_26599_p2.read().is_01() || !add_ln703_940_fu_26604_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_930_fu_26599_p2.read()) + sc_biguint<18>(add_ln703_940_fu_26604_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_44_V_fu_26649_p2() {
    acc_44_V_fu_26649_p2 = (!add_ln703_950_fu_26621_p2.read().is_01() || !add_ln703_960_fu_26644_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_950_fu_26621_p2.read()) + sc_biguint<18>(add_ln703_960_fu_26644_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_45_V_fu_26668_p2() {
    acc_45_V_fu_26668_p2 = (!add_ln703_970_fu_26659_p2.read().is_01() || !add_ln703_980_fu_26664_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_970_fu_26659_p2.read()) + sc_biguint<18>(add_ln703_980_fu_26664_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_46_V_fu_26709_p2() {
    acc_46_V_fu_26709_p2 = (!add_ln703_990_fu_26681_p2.read().is_01() || !add_ln703_1000_fu_26704_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_990_fu_26681_p2.read()) + sc_biguint<18>(add_ln703_1000_fu_26704_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_47_V_fu_26756_p2() {
    acc_47_V_fu_26756_p2 = (!add_ln703_1010_fu_26725_p2.read().is_01() || !add_ln703_1020_fu_26751_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1010_fu_26725_p2.read()) + sc_biguint<18>(add_ln703_1020_fu_26751_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_48_V_fu_26775_p2() {
    acc_48_V_fu_26775_p2 = (!add_ln703_1030_fu_26766_p2.read().is_01() || !add_ln703_1040_fu_26771_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1030_fu_26766_p2.read()) + sc_biguint<18>(add_ln703_1040_fu_26771_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_49_V_fu_26794_p2() {
    acc_49_V_fu_26794_p2 = (!add_ln703_1050_fu_26785_p2.read().is_01() || !add_ln703_1060_fu_26790_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1050_fu_26785_p2.read()) + sc_biguint<18>(add_ln703_1060_fu_26790_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_4_V_fu_25573_p2() {
    acc_4_V_fu_25573_p2 = (!add_ln703_151_fu_25545_p2.read().is_01() || !add_ln703_161_fu_25568_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_151_fu_25545_p2.read()) + sc_biguint<18>(add_ln703_161_fu_25568_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_50_V_fu_26813_p2() {
    acc_50_V_fu_26813_p2 = (!add_ln703_1070_fu_26804_p2.read().is_01() || !add_ln703_1080_fu_26809_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1070_fu_26804_p2.read()) + sc_biguint<18>(add_ln703_1080_fu_26809_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_51_V_fu_26832_p2() {
    acc_51_V_fu_26832_p2 = (!add_ln703_1090_fu_26823_p2.read().is_01() || !add_ln703_1100_fu_26828_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1090_fu_26823_p2.read()) + sc_biguint<18>(add_ln703_1100_fu_26828_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_52_V_fu_26851_p2() {
    acc_52_V_fu_26851_p2 = (!add_ln703_1110_fu_26842_p2.read().is_01() || !add_ln703_1120_fu_26847_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1110_fu_26842_p2.read()) + sc_biguint<18>(add_ln703_1120_fu_26847_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_53_V_fu_26870_p2() {
    acc_53_V_fu_26870_p2 = (!add_ln703_1130_fu_26861_p2.read().is_01() || !add_ln703_1140_fu_26866_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1130_fu_26861_p2.read()) + sc_biguint<18>(add_ln703_1140_fu_26866_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_54_V_fu_26889_p2() {
    acc_54_V_fu_26889_p2 = (!add_ln703_1150_fu_26880_p2.read().is_01() || !add_ln703_1160_fu_26885_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1150_fu_26880_p2.read()) + sc_biguint<18>(add_ln703_1160_fu_26885_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_55_V_fu_26908_p2() {
    acc_55_V_fu_26908_p2 = (!add_ln703_1170_fu_26899_p2.read().is_01() || !add_ln703_1180_fu_26904_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1170_fu_26899_p2.read()) + sc_biguint<18>(add_ln703_1180_fu_26904_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_56_V_fu_26949_p2() {
    acc_56_V_fu_26949_p2 = (!add_ln703_1190_fu_26921_p2.read().is_01() || !add_ln703_1200_fu_26944_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1190_fu_26921_p2.read()) + sc_biguint<18>(add_ln703_1200_fu_26944_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_57_V_fu_26990_p2() {
    acc_57_V_fu_26990_p2 = (!add_ln703_1210_fu_26965_p2.read().is_01() || !add_ln703_1219_fu_26985_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1210_fu_26965_p2.read()) + sc_biguint<18>(add_ln703_1219_fu_26985_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_58_V_fu_27037_p2() {
    acc_58_V_fu_27037_p2 = (!add_ln703_1229_fu_27006_p2.read().is_01() || !add_ln703_1239_fu_27032_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1229_fu_27006_p2.read()) + sc_biguint<18>(add_ln703_1239_fu_27032_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_59_V_fu_27056_p2() {
    acc_59_V_fu_27056_p2 = (!add_ln703_1249_fu_27047_p2.read().is_01() || !add_ln703_1259_fu_27052_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1249_fu_27047_p2.read()) + sc_biguint<18>(add_ln703_1259_fu_27052_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_5_V_fu_25592_p2() {
    acc_5_V_fu_25592_p2 = (!add_ln703_171_fu_25583_p2.read().is_01() || !add_ln703_181_fu_25588_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_171_fu_25583_p2.read()) + sc_biguint<18>(add_ln703_181_fu_25588_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_60_V_fu_27099_p2() {
    acc_60_V_fu_27099_p2 = (!add_ln703_1269_fu_27072_p2.read().is_01() || !add_ln703_1279_fu_27094_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1269_fu_27072_p2.read()) + sc_biguint<18>(add_ln703_1279_fu_27094_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_61_V_fu_27118_p2() {
    acc_61_V_fu_27118_p2 = (!add_ln703_1289_fu_27109_p2.read().is_01() || !add_ln703_1299_fu_27114_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1289_fu_27109_p2.read()) + sc_biguint<18>(add_ln703_1299_fu_27114_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_62_V_fu_27137_p2() {
    acc_62_V_fu_27137_p2 = (!add_ln703_1309_fu_27128_p2.read().is_01() || !add_ln703_1319_fu_27133_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1309_fu_27128_p2.read()) + sc_biguint<18>(add_ln703_1319_fu_27133_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_63_V_fu_27160_p2() {
    acc_63_V_fu_27160_p2 = (!add_ln703_1329_fu_27147_p2.read().is_01() || !add_ln703_1339_fu_27155_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1329_fu_27147_p2.read()) + sc_biguint<18>(add_ln703_1339_fu_27155_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_6_V_fu_25639_p2() {
    acc_6_V_fu_25639_p2 = (!add_ln703_191_fu_25608_p2.read().is_01() || !add_ln703_201_fu_25634_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_191_fu_25608_p2.read()) + sc_biguint<18>(add_ln703_201_fu_25634_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_7_V_fu_25675_p2() {
    acc_7_V_fu_25675_p2 = (!add_ln703_211_fu_25649_p2.read().is_01() || !add_ln703_221_fu_25669_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_211_fu_25649_p2.read()) + sc_biguint<18>(add_ln703_221_fu_25669_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_8_V_fu_25694_p2() {
    acc_8_V_fu_25694_p2 = (!add_ln703_231_fu_25685_p2.read().is_01() || !add_ln703_241_fu_25690_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_231_fu_25685_p2.read()) + sc_biguint<18>(add_ln703_241_fu_25690_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_acc_9_V_fu_25713_p2() {
    acc_9_V_fu_25713_p2 = (!add_ln703_251_fu_25704_p2.read().is_01() || !add_ln703_261_fu_25709_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_251_fu_25704_p2.read()) + sc_biguint<18>(add_ln703_261_fu_25709_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_10_fu_9223_p2() {
    add_ln1118_10_fu_9223_p2 = (!sext_ln1118_276_fu_7061_p1.read().is_01() || !shl_ln1118_118_fu_9215_p3.read().is_01())? sc_lv<28>(): (sc_bigint<28>(sext_ln1118_276_fu_7061_p1.read()) + sc_biguint<28>(shl_ln1118_118_fu_9215_p3.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_11_fu_10600_p2() {
    add_ln1118_11_fu_10600_p2 = (!sext_ln1118_271_fu_6941_p1.read().is_01() || !sext_ln1118_335_fu_10596_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_271_fu_6941_p1.read()) + sc_bigint<26>(sext_ln1118_335_fu_10596_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_12_fu_11552_p2() {
    add_ln1118_12_fu_11552_p2 = (!sext_ln1118_234_fu_5556_p1.read().is_01() || !sext_ln1118_333_fu_10434_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_234_fu_5556_p1.read()) + sc_bigint<24>(sext_ln1118_333_fu_10434_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_13_fu_11744_p2() {
    add_ln1118_13_fu_11744_p2 = (!sext_ln1118_358_fu_11736_p1.read().is_01() || !sext_ln1118_357_fu_11724_p1.read().is_01())? sc_lv<28>(): (sc_bigint<28>(sext_ln1118_358_fu_11736_p1.read()) + sc_bigint<28>(sext_ln1118_357_fu_11724_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_14_fu_12183_p2() {
    add_ln1118_14_fu_12183_p2 = (!sext_ln1118_252_fu_6293_p1.read().is_01() || !sext_ln1118_184_fu_4149_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_252_fu_6293_p1.read()) + sc_bigint<25>(sext_ln1118_184_fu_4149_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_15_fu_12215_p2() {
    add_ln1118_15_fu_12215_p2 = (!sext_ln1118_367_fu_12211_p1.read().is_01() || !sext_ln1118_199_fu_4578_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_367_fu_12211_p1.read()) + sc_bigint<25>(sext_ln1118_199_fu_4578_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_16_fu_12947_p2() {
    add_ln1118_16_fu_12947_p2 = (!sext_ln1118_375_fu_12939_p1.read().is_01() || !sext_ln1118_236_fu_5564_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_375_fu_12939_p1.read()) + sc_bigint<22>(sext_ln1118_236_fu_5564_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_17_fu_13205_p2() {
    add_ln1118_17_fu_13205_p2 = (!sext_ln1118_382_fu_13201_p1.read().is_01() || !sext_ln1118_381_fu_13189_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_382_fu_13201_p1.read()) + sc_bigint<22>(sext_ln1118_381_fu_13189_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_18_fu_14213_p2() {
    add_ln1118_18_fu_14213_p2 = (!sext_ln1118_400_fu_14205_p1.read().is_01() || !sext_ln1118_398_fu_14189_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_400_fu_14205_p1.read()) + sc_bigint<27>(sext_ln1118_398_fu_14189_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_19_fu_14997_p2() {
    add_ln1118_19_fu_14997_p2 = (!sext_ln1118_298_fu_7993_p1.read().is_01() || !sext_ln1118_151_fu_2987_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_298_fu_7993_p1.read()) + sc_bigint<22>(sext_ln1118_151_fu_2987_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_1_fu_4919_p2() {
    add_ln1118_1_fu_4919_p2 = (!sext_ln1118_210_fu_4915_p1.read().is_01() || !sext_ln1118_207_fu_4895_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_210_fu_4915_p1.read()) + sc_bigint<27>(sext_ln1118_207_fu_4895_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_20_fu_15683_p2() {
    add_ln1118_20_fu_15683_p2 = (!sext_ln1118_235_fu_5560_p1.read().is_01() || !sext_ln1118_172_fu_3800_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_235_fu_5560_p1.read()) + sc_bigint<27>(sext_ln1118_172_fu_3800_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_21_fu_17229_p2() {
    add_ln1118_21_fu_17229_p2 = (!sext_ln1118_155_fu_3185_p1.read().is_01() || !sext_ln1118_270_fu_6937_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_155_fu_3185_p1.read()) + sc_bigint<24>(sext_ln1118_270_fu_6937_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_22_fu_17647_p2() {
    add_ln1118_22_fu_17647_p2 = (!sext_ln1118_449_fu_17639_p1.read().is_01() || !sext_ln1118_308_fu_8850_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_449_fu_17639_p1.read()) + sc_bigint<24>(sext_ln1118_308_fu_8850_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_23_fu_18019_p2() {
    add_ln1118_23_fu_18019_p2 = (!sext_ln1118_158_fu_3275_p1.read().is_01() || !sext_ln1118_456_fu_18015_p1.read().is_01())? sc_lv<28>(): (sc_bigint<28>(sext_ln1118_158_fu_3275_p1.read()) + sc_bigint<28>(sext_ln1118_456_fu_18015_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_24_fu_18140_p2() {
    add_ln1118_24_fu_18140_p2 = (!sext_ln1118_376_fu_12943_p1.read().is_01() || !sext_ln1118_333_fu_10434_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_376_fu_12943_p1.read()) + sc_bigint<24>(sext_ln1118_333_fu_10434_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_25_fu_19474_p2() {
    add_ln1118_25_fu_19474_p2 = (!sext_ln1118_475_fu_19470_p1.read().is_01() || !sext_ln1118_474_fu_19458_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_475_fu_19470_p1.read()) + sc_bigint<27>(sext_ln1118_474_fu_19458_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_26_fu_20529_p2() {
    add_ln1118_26_fu_20529_p2 = (!sext_ln1118_481_fu_20525_p1.read().is_01() || !sext_ln1118_174_fu_3968_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_481_fu_20525_p1.read()) + sc_bigint<26>(sext_ln1118_174_fu_3968_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_27_fu_20655_p2() {
    add_ln1118_27_fu_20655_p2 = (!sext_ln1118_223_fu_5379_p1.read().is_01() || !sext_ln1118_321_fu_9654_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_223_fu_5379_p1.read()) + sc_bigint<26>(sext_ln1118_321_fu_9654_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_28_fu_21038_p2() {
    add_ln1118_28_fu_21038_p2 = (!sext_ln1118_491_fu_21034_p1.read().is_01() || !sext_ln1118_470_fu_19052_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_491_fu_21034_p1.read()) + sc_bigint<27>(sext_ln1118_470_fu_19052_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_29_fu_21114_p2() {
    add_ln1118_29_fu_21114_p2 = (!sext_ln1118_493_fu_21110_p1.read().is_01() || !sext_ln1118_492_fu_21106_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_493_fu_21110_p1.read()) + sc_bigint<25>(sext_ln1118_492_fu_21106_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_2_fu_4969_p2() {
    add_ln1118_2_fu_4969_p2 = (!sext_ln1118_192_fu_4467_p1.read().is_01() || !sext_ln1118_211_fu_4965_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_192_fu_4467_p1.read()) + sc_bigint<27>(sext_ln1118_211_fu_4965_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_30_fu_21431_p2() {
    add_ln1118_30_fu_21431_p2 = (!sext_ln1118_183_fu_4145_p1.read().is_01() || !sext_ln1118_395_fu_13976_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_183_fu_4145_p1.read()) + sc_bigint<27>(sext_ln1118_395_fu_13976_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_31_fu_21790_p2() {
    add_ln1118_31_fu_21790_p2 = (!sext_ln1118_504_fu_21786_p1.read().is_01() || !sext_ln1118_470_fu_19052_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_504_fu_21786_p1.read()) + sc_bigint<27>(sext_ln1118_470_fu_19052_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_32_fu_22109_p2() {
    add_ln1118_32_fu_22109_p2 = (!sext_ln1118_488_fu_20974_p1.read().is_01() || !sext_ln1118_403_fu_14600_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_488_fu_20974_p1.read()) + sc_bigint<26>(sext_ln1118_403_fu_14600_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_33_fu_22477_p2() {
    add_ln1118_33_fu_22477_p2 = (!sext_ln1118_162_fu_3299_p1.read().is_01() || !sext_ln1118_441_fu_16981_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_162_fu_3299_p1.read()) + sc_bigint<25>(sext_ln1118_441_fu_16981_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_34_fu_24945_p2() {
    add_ln1118_34_fu_24945_p2 = (!sext_ln1118_543_fu_24941_p1.read().is_01() || !sext_ln1118_169_fu_3464_p1.read().is_01())? sc_lv<27>(): (sc_bigint<27>(sext_ln1118_543_fu_24941_p1.read()) + sc_bigint<27>(sext_ln1118_169_fu_3464_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_3_fu_5411_p2() {
    add_ln1118_3_fu_5411_p2 = (!sext_ln1118_105_fu_2467_p1.read().is_01() || !sext_ln1118_185_fu_4161_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_105_fu_2467_p1.read()) + sc_bigint<21>(sext_ln1118_185_fu_4161_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_4_fu_5572_p2() {
    add_ln1118_4_fu_5572_p2 = (!sext_ln1118_140_fu_2665_p1.read().is_01() || !sext_ln1118_236_fu_5564_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_140_fu_2665_p1.read()) + sc_bigint<22>(sext_ln1118_236_fu_5564_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_5_fu_5727_p2() {
    add_ln1118_5_fu_5727_p2 = (!sext_ln1118_175_fu_3986_p1.read().is_01() || !sext_ln1118_239_fu_5723_p1.read().is_01())? sc_lv<28>(): (sc_bigint<28>(sext_ln1118_175_fu_3986_p1.read()) + sc_bigint<28>(sext_ln1118_239_fu_5723_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_6_fu_7069_p2() {
    add_ln1118_6_fu_7069_p2 = (!sext_ln1118_80_fu_2318_p1.read().is_01() || !sext_ln1118_275_fu_7057_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_80_fu_2318_p1.read()) + sc_bigint<21>(sext_ln1118_275_fu_7057_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_7_fu_7126_p2() {
    add_ln1118_7_fu_7126_p2 = (!sext_ln1118_280_fu_7122_p1.read().is_01() || !sext_ln1118_279_fu_7110_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_280_fu_7122_p1.read()) + sc_bigint<26>(sext_ln1118_279_fu_7110_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_8_fu_7883_p2() {
    add_ln1118_8_fu_7883_p2 = (!sext_ln1118_94_fu_2396_p1.read().is_01() || !sext_ln1118_196_fu_4515_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_94_fu_2396_p1.read()) + sc_bigint<22>(sext_ln1118_196_fu_4515_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_9_fu_8995_p2() {
    add_ln1118_9_fu_8995_p2 = (!sext_ln1118_284_fu_7247_p1.read().is_01() || !shl_ln1118_117_fu_8987_p3.read().is_01())? sc_lv<28>(): (sc_bigint<28>(sext_ln1118_284_fu_7247_p1.read()) + sc_biguint<28>(shl_ln1118_117_fu_8987_p3.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln1118_fu_3193_p2() {
    add_ln1118_fu_3193_p2 = (!sext_ln1118_154_fu_3181_p1.read().is_01() || !sext_ln1118_153_fu_3169_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_154_fu_3181_p1.read()) + sc_bigint<25>(sext_ln1118_153_fu_3169_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1000_fu_26704_p2() {
    add_ln703_1000_fu_26704_p2 = (!add_ln703_994_reg_36496.read().is_01() || !add_ln703_999_fu_26698_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_994_reg_36496.read()) + sc_biguint<18>(add_ln703_999_fu_26698_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1002_fu_19789_p2() {
    add_ln703_1002_fu_19789_p2 = (!trunc_ln708_990_fu_19635_p4.read().is_01() || !trunc_ln708_988_fu_19613_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_990_fu_19635_p4.read()) + sc_biguint<18>(trunc_ln708_988_fu_19613_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1003_fu_19795_p2() {
    add_ln703_1003_fu_19795_p2 = (!trunc_ln708_995_fu_19691_p4.read().is_01() || !trunc_ln708_994_fu_19682_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_995_fu_19691_p4.read()) + sc_biguint<18>(trunc_ln708_994_fu_19682_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1004_fu_19801_p2() {
    add_ln703_1004_fu_19801_p2 = (!trunc_ln708_992_fu_19659_p4.read().is_01() || !add_ln703_1003_fu_19795_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_992_fu_19659_p4.read()) + sc_biguint<18>(add_ln703_1003_fu_19795_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1005_fu_19807_p2() {
    add_ln703_1005_fu_19807_p2 = (!add_ln703_1002_fu_19789_p2.read().is_01() || !add_ln703_1004_fu_19801_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1002_fu_19789_p2.read()) + sc_biguint<18>(add_ln703_1004_fu_19801_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1006_fu_19813_p2() {
    add_ln703_1006_fu_19813_p2 = (!trunc_ln708_997_fu_19709_p4.read().is_01() || !trunc_ln708_996_fu_19700_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_997_fu_19709_p4.read()) + sc_biguint<18>(trunc_ln708_996_fu_19700_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1007_fu_19819_p2() {
    add_ln703_1007_fu_19819_p2 = (!trunc_ln708_1001_fu_19749_p4.read().is_01() || !trunc_ln708_431_fu_9697_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1001_fu_19749_p4.read()) + sc_biguint<18>(trunc_ln708_431_fu_9697_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1008_fu_19825_p2() {
    add_ln703_1008_fu_19825_p2 = (!trunc_ln708_999_fu_19731_p4.read().is_01() || !add_ln703_1007_fu_19819_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_999_fu_19731_p4.read()) + sc_biguint<18>(add_ln703_1007_fu_19819_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1009_fu_26721_p2() {
    add_ln703_1009_fu_26721_p2 = (!add_ln703_1006_reg_36526.read().is_01() || !add_ln703_1008_reg_36531.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1006_reg_36526.read()) + sc_biguint<18>(add_ln703_1008_reg_36531.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_100_fu_3146_p2() {
    add_ln703_100_fu_3146_p2 = (!add_ln703_97_fu_3120_p2.read().is_01() || !sext_ln703_45_fu_3142_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_97_fu_3120_p2.read()) + sc_bigint<18>(sext_ln703_45_fu_3142_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1010_fu_26725_p2() {
    add_ln703_1010_fu_26725_p2 = (!add_ln703_1005_reg_36521.read().is_01() || !add_ln703_1009_fu_26721_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1005_reg_36521.read()) + sc_biguint<18>(add_ln703_1009_fu_26721_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1011_fu_19831_p2() {
    add_ln703_1011_fu_19831_p2 = (!trunc_ln708_1003_fu_19771_p4.read().is_01() || !trunc_ln708_963_fu_19109_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1003_fu_19771_p4.read()) + sc_biguint<18>(trunc_ln708_963_fu_19109_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1012_fu_19837_p2() {
    add_ln703_1012_fu_19837_p2 = (!sext_ln708_231_fu_19678_p1.read().is_01() || !sext_ln708_229_fu_19631_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_231_fu_19678_p1.read()) + sc_bigint<18>(sext_ln708_229_fu_19631_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1013_fu_19843_p2() {
    add_ln703_1013_fu_19843_p2 = (!trunc_ln708_1004_fu_19780_p4.read().is_01() || !add_ln703_1012_fu_19837_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1004_fu_19780_p4.read()) + sc_biguint<18>(add_ln703_1012_fu_19837_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1014_fu_19849_p2() {
    add_ln703_1014_fu_19849_p2 = (!add_ln703_1011_fu_19831_p2.read().is_01() || !add_ln703_1013_fu_19843_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1011_fu_19831_p2.read()) + sc_biguint<18>(add_ln703_1013_fu_19843_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1015_fu_19855_p2() {
    add_ln703_1015_fu_19855_p2 = (!sext_ln708_140_fu_12297_p1.read().is_01() || !sext_ln708_233_fu_19767_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_140_fu_12297_p1.read()) + sc_bigint<18>(sext_ln708_233_fu_19767_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1016_fu_19861_p2() {
    add_ln703_1016_fu_19861_p2 = (!sext_ln708_232_fu_19727_p1.read().is_01() || !add_ln703_1015_fu_19855_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_232_fu_19727_p1.read()) + sc_biguint<18>(add_ln703_1015_fu_19855_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1017_fu_26730_p2() {
    add_ln703_1017_fu_26730_p2 = (!sext_ln1118_476_fu_26718_p1.read().is_01() || !ap_const_lv17_73.is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_476_fu_26718_p1.read()) + sc_biguint<17>(ap_const_lv17_73));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1018_fu_26740_p2() {
    add_ln703_1018_fu_26740_p2 = (!sext_ln708_230_fu_26715_p1.read().is_01() || !sext_ln703_189_fu_26736_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_230_fu_26715_p1.read()) + sc_bigint<18>(sext_ln703_189_fu_26736_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1019_fu_26746_p2() {
    add_ln703_1019_fu_26746_p2 = (!add_ln703_1016_reg_36541.read().is_01() || !add_ln703_1018_fu_26740_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1016_reg_36541.read()) + sc_biguint<18>(add_ln703_1018_fu_26740_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_101_fu_25486_p2() {
    add_ln703_101_fu_25486_p2 = (!add_ln703_95_reg_35216.read().is_01() || !add_ln703_100_reg_35221.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_95_reg_35216.read()) + sc_biguint<18>(add_ln703_100_reg_35221.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1020_fu_26751_p2() {
    add_ln703_1020_fu_26751_p2 = (!add_ln703_1014_reg_36536.read().is_01() || !add_ln703_1019_fu_26746_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1014_reg_36536.read()) + sc_biguint<18>(add_ln703_1019_fu_26746_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1022_fu_20076_p2() {
    add_ln703_1022_fu_20076_p2 = (!trunc_ln708_1008_fu_19902_p4.read().is_01() || !trunc_ln708_1007_fu_19893_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1008_fu_19902_p4.read()) + sc_biguint<18>(trunc_ln708_1007_fu_19893_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1023_fu_20082_p2() {
    add_ln703_1023_fu_20082_p2 = (!trunc_ln708_1012_fu_19942_p4.read().is_01() || !trunc_ln708_1011_fu_19933_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1012_fu_19942_p4.read()) + sc_biguint<18>(trunc_ln708_1011_fu_19933_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1024_fu_20088_p2() {
    add_ln703_1024_fu_20088_p2 = (!trunc_ln708_1010_fu_19924_p4.read().is_01() || !add_ln703_1023_fu_20082_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1010_fu_19924_p4.read()) + sc_biguint<18>(add_ln703_1023_fu_20082_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1025_fu_20094_p2() {
    add_ln703_1025_fu_20094_p2 = (!add_ln703_1022_fu_20076_p2.read().is_01() || !add_ln703_1024_fu_20088_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1022_fu_20076_p2.read()) + sc_biguint<18>(add_ln703_1024_fu_20088_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1026_fu_20100_p2() {
    add_ln703_1026_fu_20100_p2 = (!trunc_ln708_1015_fu_19973_p4.read().is_01() || !trunc_ln708_1013_fu_19951_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1015_fu_19973_p4.read()) + sc_biguint<18>(trunc_ln708_1013_fu_19951_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1027_fu_20106_p2() {
    add_ln703_1027_fu_20106_p2 = (!trunc_ln708_1019_fu_20013_p4.read().is_01() || !trunc_ln708_1017_fu_19991_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1019_fu_20013_p4.read()) + sc_biguint<18>(trunc_ln708_1017_fu_19991_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1028_fu_20112_p2() {
    add_ln703_1028_fu_20112_p2 = (!trunc_ln708_1016_fu_19982_p4.read().is_01() || !add_ln703_1027_fu_20106_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1016_fu_19982_p4.read()) + sc_biguint<18>(add_ln703_1027_fu_20106_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1029_fu_26762_p2() {
    add_ln703_1029_fu_26762_p2 = (!add_ln703_1026_reg_36551.read().is_01() || !add_ln703_1028_reg_36556.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1026_reg_36551.read()) + sc_biguint<18>(add_ln703_1028_reg_36556.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1030_fu_26766_p2() {
    add_ln703_1030_fu_26766_p2 = (!add_ln703_1025_reg_36546.read().is_01() || !add_ln703_1029_fu_26762_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1025_reg_36546.read()) + sc_biguint<18>(add_ln703_1029_fu_26762_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1031_fu_20118_p2() {
    add_ln703_1031_fu_20118_p2 = (!trunc_ln708_1022_fu_20044_p4.read().is_01() || !trunc_ln708_1020_fu_20022_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1022_fu_20044_p4.read()) + sc_biguint<18>(trunc_ln708_1020_fu_20022_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1032_fu_20124_p2() {
    add_ln703_1032_fu_20124_p2 = (!sext_ln708_236_fu_19920_p1.read().is_01() || !sext_ln708_234_fu_19876_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_236_fu_19920_p1.read()) + sc_bigint<18>(sext_ln708_234_fu_19876_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1033_fu_20130_p2() {
    add_ln703_1033_fu_20130_p2 = (!trunc_ln708_1023_fu_20053_p4.read().is_01() || !add_ln703_1032_fu_20124_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1023_fu_20053_p4.read()) + sc_biguint<18>(add_ln703_1032_fu_20124_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1034_fu_20136_p2() {
    add_ln703_1034_fu_20136_p2 = (!add_ln703_1031_fu_20118_p2.read().is_01() || !add_ln703_1033_fu_20130_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1031_fu_20118_p2.read()) + sc_biguint<18>(add_ln703_1033_fu_20130_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1035_fu_20142_p2() {
    add_ln703_1035_fu_20142_p2 = (!sext_ln708_235_fu_19889_p1.read().is_01() || !sext_ln708_238_fu_20009_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_235_fu_19889_p1.read()) + sc_bigint<18>(sext_ln708_238_fu_20009_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1036_fu_20148_p2() {
    add_ln703_1036_fu_20148_p2 = (!sext_ln708_237_fu_19969_p1.read().is_01() || !add_ln703_1035_fu_20142_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_237_fu_19969_p1.read()) + sc_biguint<18>(add_ln703_1035_fu_20142_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1037_fu_20154_p2() {
    add_ln703_1037_fu_20154_p2 = (!sext_ln703_190_fu_20072_p1.read().is_01() || !ap_const_lv13_1F3F.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_190_fu_20072_p1.read()) + sc_bigint<13>(ap_const_lv13_1F3F));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1038_fu_20164_p2() {
    add_ln703_1038_fu_20164_p2 = (!sext_ln1118_477_fu_20040_p1.read().is_01() || !sext_ln703_191_fu_20160_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_477_fu_20040_p1.read()) + sc_bigint<16>(sext_ln703_191_fu_20160_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1039_fu_20174_p2() {
    add_ln703_1039_fu_20174_p2 = (!add_ln703_1036_fu_20148_p2.read().is_01() || !sext_ln703_192_fu_20170_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1036_fu_20148_p2.read()) + sc_bigint<18>(sext_ln703_192_fu_20170_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_103_fu_3494_p2() {
    add_ln703_103_fu_3494_p2 = (!trunc_ln708_103_fu_3213_p4.read().is_01() || !trunc_ln708_101_fu_3152_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_103_fu_3213_p4.read()) + sc_biguint<18>(trunc_ln708_101_fu_3152_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1040_fu_26771_p2() {
    add_ln703_1040_fu_26771_p2 = (!add_ln703_1034_reg_36561.read().is_01() || !add_ln703_1039_reg_36566.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1034_reg_36561.read()) + sc_biguint<18>(add_ln703_1039_reg_36566.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1042_fu_20413_p2() {
    add_ln703_1042_fu_20413_p2 = (!trunc_ln708_1027_fu_20233_p4.read().is_01() || !trunc_ln708_1025_fu_20192_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1027_fu_20233_p4.read()) + sc_biguint<18>(trunc_ln708_1025_fu_20192_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1043_fu_20419_p2() {
    add_ln703_1043_fu_20419_p2 = (!trunc_ln708_1031_fu_20274_p4.read().is_01() || !trunc_ln708_1030_fu_20265_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1031_fu_20274_p4.read()) + sc_biguint<18>(trunc_ln708_1030_fu_20265_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1044_fu_20425_p2() {
    add_ln703_1044_fu_20425_p2 = (!trunc_ln708_1029_fu_20256_p4.read().is_01() || !add_ln703_1043_fu_20419_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1029_fu_20256_p4.read()) + sc_biguint<18>(add_ln703_1043_fu_20419_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1045_fu_20431_p2() {
    add_ln703_1045_fu_20431_p2 = (!add_ln703_1042_fu_20413_p2.read().is_01() || !add_ln703_1044_fu_20425_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1042_fu_20413_p2.read()) + sc_biguint<18>(add_ln703_1044_fu_20425_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1046_fu_20437_p2() {
    add_ln703_1046_fu_20437_p2 = (!trunc_ln708_1033_fu_20292_p4.read().is_01() || !trunc_ln708_1032_fu_20283_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1033_fu_20292_p4.read()) + sc_biguint<18>(trunc_ln708_1032_fu_20283_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1047_fu_20443_p2() {
    add_ln703_1047_fu_20443_p2 = (!trunc_ln708_1036_fu_20319_p4.read().is_01() || !trunc_ln708_1035_fu_20310_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1036_fu_20319_p4.read()) + sc_biguint<18>(trunc_ln708_1035_fu_20310_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1048_fu_20449_p2() {
    add_ln703_1048_fu_20449_p2 = (!trunc_ln708_1034_fu_20301_p4.read().is_01() || !add_ln703_1047_fu_20443_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1034_fu_20301_p4.read()) + sc_biguint<18>(add_ln703_1047_fu_20443_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1049_fu_26781_p2() {
    add_ln703_1049_fu_26781_p2 = (!add_ln703_1046_reg_36576.read().is_01() || !add_ln703_1048_reg_36581.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1046_reg_36576.read()) + sc_biguint<18>(add_ln703_1048_reg_36581.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_104_fu_3500_p2() {
    add_ln703_104_fu_3500_p2 = (!trunc_ln708_106_fu_3240_p4.read().is_01() || !trunc_ln708_105_fu_3231_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_106_fu_3240_p4.read()) + sc_biguint<18>(trunc_ln708_105_fu_3231_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1050_fu_26785_p2() {
    add_ln703_1050_fu_26785_p2 = (!add_ln703_1045_reg_36571.read().is_01() || !add_ln703_1049_fu_26781_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1045_reg_36571.read()) + sc_biguint<18>(add_ln703_1049_fu_26781_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1051_fu_20455_p2() {
    add_ln703_1051_fu_20455_p2 = (!trunc_ln708_1039_fu_20350_p4.read().is_01() || !trunc_ln708_1038_fu_20341_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1039_fu_20350_p4.read()) + sc_biguint<18>(trunc_ln708_1038_fu_20341_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1052_fu_20461_p2() {
    add_ln703_1052_fu_20461_p2 = (!trunc_ln708_1044_fu_20404_p4.read().is_01() || !trunc_ln708_1042_fu_20381_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1044_fu_20404_p4.read()) + sc_biguint<18>(trunc_ln708_1042_fu_20381_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1053_fu_20467_p2() {
    add_ln703_1053_fu_20467_p2 = (!trunc_ln708_1041_fu_20372_p4.read().is_01() || !add_ln703_1052_fu_20461_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1041_fu_20372_p4.read()) + sc_biguint<18>(add_ln703_1052_fu_20461_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1054_fu_20473_p2() {
    add_ln703_1054_fu_20473_p2 = (!add_ln703_1051_fu_20455_p2.read().is_01() || !add_ln703_1053_fu_20467_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1051_fu_20455_p2.read()) + sc_biguint<18>(add_ln703_1053_fu_20467_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1055_fu_20479_p2() {
    add_ln703_1055_fu_20479_p2 = (!sext_ln708_241_fu_20368_p1.read().is_01() || !sext_ln708_240_fu_20337_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_241_fu_20368_p1.read()) + sc_bigint<18>(sext_ln708_240_fu_20337_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1056_fu_20485_p2() {
    add_ln703_1056_fu_20485_p2 = (!sext_ln708_239_fu_20211_p1.read().is_01() || !add_ln703_1055_fu_20479_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_239_fu_20211_p1.read()) + sc_biguint<18>(add_ln703_1055_fu_20479_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1057_fu_20491_p2() {
    add_ln703_1057_fu_20491_p2 = (!sext_ln1118_480_fu_20400_p1.read().is_01() || !ap_const_lv16_FFE0.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_480_fu_20400_p1.read()) + sc_bigint<16>(ap_const_lv16_FFE0));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1058_fu_20501_p2() {
    add_ln703_1058_fu_20501_p2 = (!sext_ln1118_479_fu_20252_p1.read().is_01() || !sext_ln703_193_fu_20497_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_479_fu_20252_p1.read()) + sc_bigint<17>(sext_ln703_193_fu_20497_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1059_fu_20511_p2() {
    add_ln703_1059_fu_20511_p2 = (!add_ln703_1056_fu_20485_p2.read().is_01() || !sext_ln703_194_fu_20507_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1056_fu_20485_p2.read()) + sc_bigint<18>(sext_ln703_194_fu_20507_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_105_fu_3506_p2() {
    add_ln703_105_fu_3506_p2 = (!trunc_ln708_104_fu_3222_p4.read().is_01() || !add_ln703_104_fu_3500_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_104_fu_3222_p4.read()) + sc_biguint<18>(add_ln703_104_fu_3500_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1060_fu_26790_p2() {
    add_ln703_1060_fu_26790_p2 = (!add_ln703_1054_reg_36586.read().is_01() || !add_ln703_1059_reg_36591.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1054_reg_36586.read()) + sc_biguint<18>(add_ln703_1059_reg_36591.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1062_fu_20770_p2() {
    add_ln703_1062_fu_20770_p2 = (!trunc_ln708_1048_fu_20571_p4.read().is_01() || !trunc_ln708_1047_fu_20562_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1048_fu_20571_p4.read()) + sc_biguint<18>(trunc_ln708_1047_fu_20562_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1063_fu_20776_p2() {
    add_ln703_1063_fu_20776_p2 = (!trunc_ln708_1051_fu_20598_p4.read().is_01() || !trunc_ln708_1050_fu_20589_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1051_fu_20598_p4.read()) + sc_biguint<18>(trunc_ln708_1050_fu_20589_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1064_fu_20782_p2() {
    add_ln703_1064_fu_20782_p2 = (!trunc_ln708_1049_fu_20580_p4.read().is_01() || !add_ln703_1063_fu_20776_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1049_fu_20580_p4.read()) + sc_biguint<18>(add_ln703_1063_fu_20776_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1065_fu_20788_p2() {
    add_ln703_1065_fu_20788_p2 = (!add_ln703_1062_fu_20770_p2.read().is_01() || !add_ln703_1064_fu_20782_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1062_fu_20770_p2.read()) + sc_biguint<18>(add_ln703_1064_fu_20782_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1066_fu_20794_p2() {
    add_ln703_1066_fu_20794_p2 = (!trunc_ln708_1059_fu_20721_p4.read().is_01() || !trunc_ln708_1053_fu_20633_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1059_fu_20721_p4.read()) + sc_biguint<18>(trunc_ln708_1053_fu_20633_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1067_fu_20800_p2() {
    add_ln703_1067_fu_20800_p2 = (!trunc_ln708_1063_fu_20761_p4.read().is_01() || !trunc_ln708_1062_fu_20752_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1063_fu_20761_p4.read()) + sc_biguint<18>(trunc_ln708_1062_fu_20752_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1068_fu_20806_p2() {
    add_ln703_1068_fu_20806_p2 = (!trunc_ln708_1061_fu_20743_p4.read().is_01() || !add_ln703_1067_fu_20800_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1061_fu_20743_p4.read()) + sc_biguint<18>(add_ln703_1067_fu_20800_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1069_fu_26800_p2() {
    add_ln703_1069_fu_26800_p2 = (!add_ln703_1066_reg_36601.read().is_01() || !add_ln703_1068_reg_36606.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1066_reg_36601.read()) + sc_biguint<18>(add_ln703_1068_reg_36606.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_106_fu_3512_p2() {
    add_ln703_106_fu_3512_p2 = (!add_ln703_103_fu_3494_p2.read().is_01() || !add_ln703_105_fu_3506_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_103_fu_3494_p2.read()) + sc_biguint<18>(add_ln703_105_fu_3506_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1070_fu_26804_p2() {
    add_ln703_1070_fu_26804_p2 = (!add_ln703_1065_reg_36596.read().is_01() || !add_ln703_1069_fu_26800_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1065_reg_36596.read()) + sc_biguint<18>(add_ln703_1069_fu_26800_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1071_fu_20812_p2() {
    add_ln703_1071_fu_20812_p2 = (!sext_ln708_243_fu_20651_p1.read().is_01() || !sext_ln708_242_fu_20558_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_243_fu_20651_p1.read()) + sc_bigint<18>(sext_ln708_242_fu_20558_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1072_fu_20818_p2() {
    add_ln703_1072_fu_20818_p2 = (!sext_ln1118_484_fu_20671_p1.read().is_01() || !sext_ln1118_482_fu_20545_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_484_fu_20671_p1.read()) + sc_bigint<17>(sext_ln1118_482_fu_20545_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1073_fu_20828_p2() {
    add_ln703_1073_fu_20828_p2 = (!sext_ln708_244_fu_20684_p1.read().is_01() || !sext_ln703_195_fu_20824_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_244_fu_20684_p1.read()) + sc_bigint<18>(sext_ln703_195_fu_20824_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1074_fu_20834_p2() {
    add_ln703_1074_fu_20834_p2 = (!add_ln703_1071_fu_20812_p2.read().is_01() || !add_ln703_1073_fu_20828_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1071_fu_20812_p2.read()) + sc_biguint<18>(add_ln703_1073_fu_20828_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1075_fu_20840_p2() {
    add_ln703_1075_fu_20840_p2 = (!sext_ln1118_486_fu_20739_p1.read().is_01() || !sext_ln1118_485_fu_20717_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_486_fu_20739_p1.read()) + sc_bigint<17>(sext_ln1118_485_fu_20717_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1076_fu_20850_p2() {
    add_ln703_1076_fu_20850_p2 = (!sext_ln708_245_fu_20697_p1.read().is_01() || !sext_ln703_196_fu_20846_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_245_fu_20697_p1.read()) + sc_bigint<18>(sext_ln703_196_fu_20846_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1077_fu_20856_p2() {
    add_ln703_1077_fu_20856_p2 = (!sext_ln1118_483_fu_20629_p1.read().is_01() || !ap_const_lv16_3F.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_483_fu_20629_p1.read()) + sc_biguint<16>(ap_const_lv16_3F));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1078_fu_20866_p2() {
    add_ln703_1078_fu_20866_p2 = (!sext_ln1118_324_fu_9896_p1.read().is_01() || !sext_ln703_197_fu_20862_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_324_fu_9896_p1.read()) + sc_bigint<17>(sext_ln703_197_fu_20862_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1079_fu_20876_p2() {
    add_ln703_1079_fu_20876_p2 = (!add_ln703_1076_fu_20850_p2.read().is_01() || !sext_ln703_198_fu_20872_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1076_fu_20850_p2.read()) + sc_bigint<18>(sext_ln703_198_fu_20872_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_107_fu_3518_p2() {
    add_ln703_107_fu_3518_p2 = (!trunc_ln708_108_fu_3258_p4.read().is_01() || !trunc_ln708_107_fu_3249_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_108_fu_3258_p4.read()) + sc_biguint<18>(trunc_ln708_107_fu_3249_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1080_fu_26809_p2() {
    add_ln703_1080_fu_26809_p2 = (!add_ln703_1074_reg_36611.read().is_01() || !add_ln703_1079_reg_36616.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1074_reg_36611.read()) + sc_biguint<18>(add_ln703_1079_reg_36616.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1082_fu_21169_p2() {
    add_ln703_1082_fu_21169_p2 = (!trunc_ln708_1066_fu_20904_p4.read().is_01() || !trunc_ln708_1064_fu_20882_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1066_fu_20904_p4.read()) + sc_biguint<18>(trunc_ln708_1064_fu_20882_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1083_fu_21175_p2() {
    add_ln703_1083_fu_21175_p2 = (!trunc_ln708_1071_fu_20957_p4.read().is_01() || !trunc_ln708_1070_fu_20948_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1071_fu_20957_p4.read()) + sc_biguint<18>(trunc_ln708_1070_fu_20948_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1084_fu_21181_p2() {
    add_ln703_1084_fu_21181_p2 = (!trunc_ln708_1068_fu_20926_p4.read().is_01() || !add_ln703_1083_fu_21175_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1068_fu_20926_p4.read()) + sc_biguint<18>(add_ln703_1083_fu_21175_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1085_fu_21187_p2() {
    add_ln703_1085_fu_21187_p2 = (!add_ln703_1082_fu_21169_p2.read().is_01() || !add_ln703_1084_fu_21181_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1082_fu_21169_p2.read()) + sc_biguint<18>(add_ln703_1084_fu_21181_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1086_fu_21193_p2() {
    add_ln703_1086_fu_21193_p2 = (!trunc_ln708_1074_fu_21017_p4.read().is_01() || !trunc_ln708_1073_fu_21008_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1074_fu_21017_p4.read()) + sc_biguint<18>(trunc_ln708_1073_fu_21008_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1087_fu_21199_p2() {
    add_ln703_1087_fu_21199_p2 = (!trunc_ln708_1079_fu_21089_p4.read().is_01() || !trunc_ln708_1077_fu_21067_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1079_fu_21089_p4.read()) + sc_biguint<18>(trunc_ln708_1077_fu_21067_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1088_fu_21205_p2() {
    add_ln703_1088_fu_21205_p2 = (!trunc_ln708_1076_fu_21058_p4.read().is_01() || !add_ln703_1087_fu_21199_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1076_fu_21058_p4.read()) + sc_biguint<18>(add_ln703_1087_fu_21199_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1089_fu_26819_p2() {
    add_ln703_1089_fu_26819_p2 = (!add_ln703_1086_reg_36626.read().is_01() || !add_ln703_1088_reg_36631.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1086_reg_36626.read()) + sc_biguint<18>(add_ln703_1088_reg_36631.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_108_fu_3524_p2() {
    add_ln703_108_fu_3524_p2 = (!trunc_ln708_115_fu_3384_p4.read().is_01() || !trunc_ln708_111_fu_3336_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_115_fu_3384_p4.read()) + sc_biguint<18>(trunc_ln708_111_fu_3336_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1090_fu_26823_p2() {
    add_ln703_1090_fu_26823_p2 = (!add_ln703_1085_reg_36621.read().is_01() || !add_ln703_1089_fu_26819_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1085_reg_36621.read()) + sc_biguint<18>(add_ln703_1089_fu_26819_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1091_fu_21211_p2() {
    add_ln703_1091_fu_21211_p2 = (!sext_ln708_246_fu_20922_p1.read().is_01() || !trunc_ln708_1082_fu_21147_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_246_fu_20922_p1.read()) + sc_biguint<18>(trunc_ln708_1082_fu_21147_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1092_fu_21217_p2() {
    add_ln703_1092_fu_21217_p2 = (!sext_ln708_249_fu_21085_p1.read().is_01() || !sext_ln708_248_fu_21054_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_249_fu_21085_p1.read()) + sc_bigint<18>(sext_ln708_248_fu_21054_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1093_fu_21223_p2() {
    add_ln703_1093_fu_21223_p2 = (!sext_ln708_247_fu_20944_p1.read().is_01() || !add_ln703_1092_fu_21217_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_247_fu_20944_p1.read()) + sc_biguint<18>(add_ln703_1092_fu_21217_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1094_fu_21229_p2() {
    add_ln703_1094_fu_21229_p2 = (!add_ln703_1091_fu_21211_p2.read().is_01() || !add_ln703_1093_fu_21223_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1091_fu_21211_p2.read()) + sc_biguint<18>(add_ln703_1093_fu_21223_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1095_fu_21235_p2() {
    add_ln703_1095_fu_21235_p2 = (!sext_ln703_199_fu_21165_p1.read().is_01() || !sext_ln1118_487_fu_20900_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_199_fu_21165_p1.read()) + sc_bigint<17>(sext_ln1118_487_fu_20900_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1096_fu_21245_p2() {
    add_ln703_1096_fu_21245_p2 = (!sext_ln708_250_fu_21143_p1.read().is_01() || !sext_ln703_200_fu_21241_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_250_fu_21143_p1.read()) + sc_bigint<18>(sext_ln703_200_fu_21241_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1097_fu_21251_p2() {
    add_ln703_1097_fu_21251_p2 = (!sext_ln1118_490_fu_21004_p1.read().is_01() || !ap_const_lv15_6C.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_490_fu_21004_p1.read()) + sc_biguint<15>(ap_const_lv15_6C));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1098_fu_21261_p2() {
    add_ln703_1098_fu_21261_p2 = (!sext_ln1118_495_fu_21130_p1.read().is_01() || !sext_ln703_201_fu_21257_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_495_fu_21130_p1.read()) + sc_bigint<16>(sext_ln703_201_fu_21257_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1099_fu_21271_p2() {
    add_ln703_1099_fu_21271_p2 = (!add_ln703_1096_fu_21245_p2.read().is_01() || !sext_ln703_202_fu_21267_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1096_fu_21245_p2.read()) + sc_bigint<18>(sext_ln703_202_fu_21267_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_109_fu_3530_p2() {
    add_ln703_109_fu_3530_p2 = (!trunc_ln708_110_fu_3327_p4.read().is_01() || !add_ln703_108_fu_3524_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_110_fu_3327_p4.read()) + sc_biguint<18>(add_ln703_108_fu_3524_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1100_fu_26828_p2() {
    add_ln703_1100_fu_26828_p2 = (!add_ln703_1094_reg_36636.read().is_01() || !add_ln703_1099_reg_36641.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1094_reg_36636.read()) + sc_biguint<18>(add_ln703_1099_reg_36641.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1102_fu_21523_p2() {
    add_ln703_1102_fu_21523_p2 = (!trunc_ln708_1086_fu_21306_p4.read().is_01() || !trunc_ln708_1085_fu_21297_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1086_fu_21306_p4.read()) + sc_biguint<18>(trunc_ln708_1085_fu_21297_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1103_fu_21529_p2() {
    add_ln703_1103_fu_21529_p2 = (!trunc_ln708_1089_fu_21333_p4.read().is_01() || !trunc_ln708_1088_fu_21324_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1089_fu_21333_p4.read()) + sc_biguint<18>(trunc_ln708_1088_fu_21324_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1104_fu_21535_p2() {
    add_ln703_1104_fu_21535_p2 = (!trunc_ln708_1087_fu_21315_p4.read().is_01() || !add_ln703_1103_fu_21529_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1087_fu_21315_p4.read()) + sc_biguint<18>(add_ln703_1103_fu_21529_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1105_fu_21541_p2() {
    add_ln703_1105_fu_21541_p2 = (!add_ln703_1102_fu_21523_p2.read().is_01() || !add_ln703_1104_fu_21535_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1102_fu_21523_p2.read()) + sc_biguint<18>(add_ln703_1104_fu_21535_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1106_fu_21547_p2() {
    add_ln703_1106_fu_21547_p2 = (!trunc_ln708_1094_fu_21409_p4.read().is_01() || !trunc_ln708_1093_fu_21400_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1094_fu_21409_p4.read()) + sc_biguint<18>(trunc_ln708_1093_fu_21400_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1107_fu_21553_p2() {
    add_ln703_1107_fu_21553_p2 = (!trunc_ln708_1099_fu_21469_p4.read().is_01() || !trunc_ln708_1098_fu_21460_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1099_fu_21469_p4.read()) + sc_biguint<18>(trunc_ln708_1098_fu_21460_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1108_fu_21559_p2() {
    add_ln703_1108_fu_21559_p2 = (!trunc_ln708_1097_fu_21451_p4.read().is_01() || !add_ln703_1107_fu_21553_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1097_fu_21451_p4.read()) + sc_biguint<18>(add_ln703_1107_fu_21553_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1109_fu_26838_p2() {
    add_ln703_1109_fu_26838_p2 = (!add_ln703_1106_reg_36651.read().is_01() || !add_ln703_1108_reg_36656.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1106_reg_36651.read()) + sc_biguint<18>(add_ln703_1108_reg_36656.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_110_fu_25496_p2() {
    add_ln703_110_fu_25496_p2 = (!add_ln703_107_reg_35231.read().is_01() || !add_ln703_109_reg_35236.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_107_reg_35231.read()) + sc_biguint<18>(add_ln703_109_reg_35236.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1110_fu_26842_p2() {
    add_ln703_1110_fu_26842_p2 = (!add_ln703_1105_reg_36646.read().is_01() || !add_ln703_1109_fu_26838_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1105_reg_36646.read()) + sc_biguint<18>(add_ln703_1109_fu_26838_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1111_fu_21565_p2() {
    add_ln703_1111_fu_21565_p2 = (!trunc_ln708_1102_fu_21500_p4.read().is_01() || !trunc_ln708_1100_fu_21478_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1102_fu_21500_p4.read()) + sc_biguint<18>(trunc_ln708_1100_fu_21478_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1112_fu_21571_p2() {
    add_ln703_1112_fu_21571_p2 = (!sext_ln708_254_fu_21447_p1.read().is_01() || !sext_ln708_253_fu_21396_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_254_fu_21447_p1.read()) + sc_bigint<18>(sext_ln708_253_fu_21396_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1113_fu_21577_p2() {
    add_ln703_1113_fu_21577_p2 = (!sext_ln708_252_fu_21351_p1.read().is_01() || !add_ln703_1112_fu_21571_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_252_fu_21351_p1.read()) + sc_biguint<18>(add_ln703_1112_fu_21571_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1114_fu_21583_p2() {
    add_ln703_1114_fu_21583_p2 = (!add_ln703_1111_fu_21565_p2.read().is_01() || !add_ln703_1113_fu_21577_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1111_fu_21565_p2.read()) + sc_biguint<18>(add_ln703_1113_fu_21577_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1115_fu_21589_p2() {
    add_ln703_1115_fu_21589_p2 = (!sext_ln708_251_fu_21293_p1.read().is_01() || !sext_ln708_7_fu_21519_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_251_fu_21293_p1.read()) + sc_bigint<18>(sext_ln708_7_fu_21519_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1116_fu_21595_p2() {
    add_ln703_1116_fu_21595_p2 = (!sext_ln708_255_fu_21496_p1.read().is_01() || !add_ln703_1115_fu_21589_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_255_fu_21496_p1.read()) + sc_biguint<18>(add_ln703_1115_fu_21589_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1117_fu_21601_p2() {
    add_ln703_1117_fu_21601_p2 = (!sext_ln1118_497_fu_21383_p1.read().is_01() || !ap_const_lv15_26.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_497_fu_21383_p1.read()) + sc_biguint<15>(ap_const_lv15_26));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1118_fu_21611_p2() {
    add_ln703_1118_fu_21611_p2 = (!sext_ln1118_498_fu_21427_p1.read().is_01() || !sext_ln703_203_fu_21607_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_498_fu_21427_p1.read()) + sc_bigint<17>(sext_ln703_203_fu_21607_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1119_fu_21621_p2() {
    add_ln703_1119_fu_21621_p2 = (!add_ln703_1116_fu_21595_p2.read().is_01() || !sext_ln703_204_fu_21617_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1116_fu_21595_p2.read()) + sc_bigint<18>(sext_ln703_204_fu_21617_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_111_fu_25500_p2() {
    add_ln703_111_fu_25500_p2 = (!add_ln703_106_reg_35226.read().is_01() || !add_ln703_110_fu_25496_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_106_reg_35226.read()) + sc_biguint<18>(add_ln703_110_fu_25496_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1120_fu_26847_p2() {
    add_ln703_1120_fu_26847_p2 = (!add_ln703_1114_reg_36661.read().is_01() || !add_ln703_1119_reg_36666.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1114_reg_36661.read()) + sc_biguint<18>(add_ln703_1119_reg_36666.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1122_fu_21918_p2() {
    add_ln703_1122_fu_21918_p2 = (!trunc_ln708_1107_fu_21662_p4.read().is_01() || !trunc_ln708_1104_fu_21627_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1107_fu_21662_p4.read()) + sc_biguint<18>(trunc_ln708_1104_fu_21627_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1123_fu_21924_p2() {
    add_ln703_1123_fu_21924_p2 = (!trunc_ln708_563_fu_12138_p4.read().is_01() || !trunc_ln708_1110_fu_21712_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_563_fu_12138_p4.read()) + sc_biguint<18>(trunc_ln708_1110_fu_21712_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1124_fu_21930_p2() {
    add_ln703_1124_fu_21930_p2 = (!trunc_ln708_1109_fu_21702_p4.read().is_01() || !add_ln703_1123_fu_21924_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1109_fu_21702_p4.read()) + sc_biguint<18>(add_ln703_1123_fu_21924_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1125_fu_21936_p2() {
    add_ln703_1125_fu_21936_p2 = (!add_ln703_1122_fu_21918_p2.read().is_01() || !add_ln703_1124_fu_21930_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1122_fu_21918_p2.read()) + sc_biguint<18>(add_ln703_1124_fu_21930_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1126_fu_21942_p2() {
    add_ln703_1126_fu_21942_p2 = (!trunc_ln708_1114_fu_21810_p4.read().is_01() || !trunc_ln708_1112_fu_21768_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1114_fu_21810_p4.read()) + sc_biguint<18>(trunc_ln708_1112_fu_21768_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1127_fu_21948_p2() {
    add_ln703_1127_fu_21948_p2 = (!trunc_ln708_1121_fu_21909_p4.read().is_01() || !trunc_ln708_1116_fu_21828_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1121_fu_21909_p4.read()) + sc_biguint<18>(trunc_ln708_1116_fu_21828_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1128_fu_21954_p2() {
    add_ln703_1128_fu_21954_p2 = (!trunc_ln708_1115_fu_21819_p4.read().is_01() || !add_ln703_1127_fu_21948_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1115_fu_21819_p4.read()) + sc_biguint<18>(add_ln703_1127_fu_21948_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1129_fu_26857_p2() {
    add_ln703_1129_fu_26857_p2 = (!add_ln703_1126_reg_36676.read().is_01() || !add_ln703_1128_reg_36681.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1126_reg_36676.read()) + sc_biguint<18>(add_ln703_1128_reg_36681.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_112_fu_3536_p2() {
    add_ln703_112_fu_3536_p2 = (!trunc_ln708_118_fu_3434_p4.read().is_01() || !trunc_ln708_116_fu_3393_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_118_fu_3434_p4.read()) + sc_biguint<18>(trunc_ln708_116_fu_3393_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1130_fu_26861_p2() {
    add_ln703_1130_fu_26861_p2 = (!add_ln703_1125_reg_36671.read().is_01() || !add_ln703_1129_fu_26857_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1125_reg_36671.read()) + sc_biguint<18>(add_ln703_1129_fu_26857_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1131_fu_21960_p2() {
    add_ln703_1131_fu_21960_p2 = (!sext_ln708_256_fu_21645_p1.read().is_01() || !sext_ln708_185_fu_15809_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_256_fu_21645_p1.read()) + sc_bigint<18>(sext_ln708_185_fu_15809_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1132_fu_21966_p2() {
    add_ln703_1132_fu_21966_p2 = (!sext_ln708_259_fu_21806_p1.read().is_01() || !sext_ln708_258_fu_21730_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_259_fu_21806_p1.read()) + sc_bigint<18>(sext_ln708_258_fu_21730_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1133_fu_21972_p2() {
    add_ln703_1133_fu_21972_p2 = (!sext_ln708_257_fu_21680_p1.read().is_01() || !add_ln703_1132_fu_21966_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_257_fu_21680_p1.read()) + sc_biguint<18>(add_ln703_1132_fu_21966_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1134_fu_21978_p2() {
    add_ln703_1134_fu_21978_p2 = (!add_ln703_1131_fu_21960_p2.read().is_01() || !add_ln703_1133_fu_21972_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1131_fu_21960_p2.read()) + sc_biguint<18>(add_ln703_1133_fu_21972_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1135_fu_21984_p2() {
    add_ln703_1135_fu_21984_p2 = (!sext_ln708_8_fu_21873_p1.read().is_01() || !sext_ln708_261_fu_21859_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_8_fu_21873_p1.read()) + sc_bigint<18>(sext_ln708_261_fu_21859_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1136_fu_21990_p2() {
    add_ln703_1136_fu_21990_p2 = (!sext_ln708_260_fu_21846_p1.read().is_01() || !add_ln703_1135_fu_21984_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_260_fu_21846_p1.read()) + sc_biguint<18>(add_ln703_1135_fu_21984_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1137_fu_21996_p2() {
    add_ln703_1137_fu_21996_p2 = (!sext_ln1118_505_fu_21905_p1.read().is_01() || !ap_const_lv14_21.is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_505_fu_21905_p1.read()) + sc_biguint<14>(ap_const_lv14_21));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1138_fu_22006_p2() {
    add_ln703_1138_fu_22006_p2 = (!sext_ln1118_499_fu_21658_p1.read().is_01() || !sext_ln703_205_fu_22002_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_499_fu_21658_p1.read()) + sc_bigint<17>(sext_ln703_205_fu_22002_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1139_fu_22016_p2() {
    add_ln703_1139_fu_22016_p2 = (!add_ln703_1136_fu_21990_p2.read().is_01() || !sext_ln703_206_fu_22012_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1136_fu_21990_p2.read()) + sc_bigint<18>(sext_ln703_206_fu_22012_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_113_fu_3542_p2() {
    add_ln703_113_fu_3542_p2 = (!sext_ln708_21_fu_3452_p1.read().is_01() || !sext_ln708_22_fu_3490_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_21_fu_3452_p1.read()) + sc_bigint<18>(sext_ln708_22_fu_3490_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1140_fu_26866_p2() {
    add_ln703_1140_fu_26866_p2 = (!add_ln703_1134_reg_36686.read().is_01() || !add_ln703_1139_reg_36691.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1134_reg_36686.read()) + sc_biguint<18>(add_ln703_1139_reg_36691.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1142_fu_22278_p2() {
    add_ln703_1142_fu_22278_p2 = (!trunc_ln708_1124_fu_22051_p4.read().is_01() || !trunc_ln708_1123_fu_22042_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1124_fu_22051_p4.read()) + sc_biguint<18>(trunc_ln708_1123_fu_22042_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1143_fu_22284_p2() {
    add_ln703_1143_fu_22284_p2 = (!trunc_ln708_1128_fu_22091_p4.read().is_01() || !trunc_ln708_1127_fu_22082_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1128_fu_22091_p4.read()) + sc_biguint<18>(trunc_ln708_1127_fu_22082_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1144_fu_22290_p2() {
    add_ln703_1144_fu_22290_p2 = (!trunc_ln708_1126_fu_22073_p4.read().is_01() || !add_ln703_1143_fu_22284_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1126_fu_22073_p4.read()) + sc_biguint<18>(add_ln703_1143_fu_22284_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1145_fu_22296_p2() {
    add_ln703_1145_fu_22296_p2 = (!add_ln703_1142_fu_22278_p2.read().is_01() || !add_ln703_1144_fu_22290_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1142_fu_22278_p2.read()) + sc_biguint<18>(add_ln703_1144_fu_22290_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1146_fu_22302_p2() {
    add_ln703_1146_fu_22302_p2 = (!trunc_ln708_1131_fu_22129_p4.read().is_01() || !trunc_ln708_1129_fu_22100_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1131_fu_22129_p4.read()) + sc_biguint<18>(trunc_ln708_1129_fu_22100_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1147_fu_22308_p2() {
    add_ln703_1147_fu_22308_p2 = (!trunc_ln708_1136_fu_22201_p4.read().is_01() || !trunc_ln708_1135_fu_22192_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1136_fu_22201_p4.read()) + sc_biguint<18>(trunc_ln708_1135_fu_22192_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1148_fu_22314_p2() {
    add_ln703_1148_fu_22314_p2 = (!trunc_ln708_1133_fu_22170_p4.read().is_01() || !add_ln703_1147_fu_22308_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1133_fu_22170_p4.read()) + sc_biguint<18>(add_ln703_1147_fu_22308_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1149_fu_26876_p2() {
    add_ln703_1149_fu_26876_p2 = (!add_ln703_1146_reg_36701.read().is_01() || !add_ln703_1148_reg_36706.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1146_reg_36701.read()) + sc_biguint<18>(add_ln703_1148_reg_36706.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_114_fu_3548_p2() {
    add_ln703_114_fu_3548_p2 = (!sext_ln708_20_fu_3367_p1.read().is_01() || !add_ln703_113_fu_3542_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_20_fu_3367_p1.read()) + sc_biguint<18>(add_ln703_113_fu_3542_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1150_fu_26880_p2() {
    add_ln703_1150_fu_26880_p2 = (!add_ln703_1145_reg_36696.read().is_01() || !add_ln703_1149_fu_26876_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1145_reg_36696.read()) + sc_biguint<18>(add_ln703_1149_fu_26876_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1151_fu_22320_p2() {
    add_ln703_1151_fu_22320_p2 = (!trunc_ln708_1138_fu_22219_p4.read().is_01() || !trunc_ln708_1137_fu_22210_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1138_fu_22219_p4.read()) + sc_biguint<18>(trunc_ln708_1137_fu_22210_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1152_fu_22326_p2() {
    add_ln703_1152_fu_22326_p2 = (!sext_ln708_262_fu_22038_p1.read().is_01() || !trunc_ln708_1141_fu_22269_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_262_fu_22038_p1.read()) + sc_biguint<18>(trunc_ln708_1141_fu_22269_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1153_fu_22332_p2() {
    add_ln703_1153_fu_22332_p2 = (!trunc_ln708_1139_fu_22228_p4.read().is_01() || !add_ln703_1152_fu_22326_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1139_fu_22228_p4.read()) + sc_biguint<18>(add_ln703_1152_fu_22326_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1154_fu_22338_p2() {
    add_ln703_1154_fu_22338_p2 = (!add_ln703_1151_fu_22320_p2.read().is_01() || !add_ln703_1153_fu_22332_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1151_fu_22320_p2.read()) + sc_biguint<18>(add_ln703_1153_fu_22332_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1155_fu_22344_p2() {
    add_ln703_1155_fu_22344_p2 = (!sext_ln708_264_fu_22125_p1.read().is_01() || !sext_ln708_265_fu_22188_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_264_fu_22125_p1.read()) + sc_bigint<18>(sext_ln708_265_fu_22188_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1156_fu_22350_p2() {
    add_ln703_1156_fu_22350_p2 = (!sext_ln708_263_fu_22069_p1.read().is_01() || !add_ln703_1155_fu_22344_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_263_fu_22069_p1.read()) + sc_biguint<18>(add_ln703_1155_fu_22344_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1157_fu_22356_p2() {
    add_ln703_1157_fu_22356_p2 = (!sext_ln1118_510_fu_22265_p1.read().is_01() || !ap_const_lv14_3DEA.is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_510_fu_22265_p1.read()) + sc_bigint<14>(ap_const_lv14_3DEA));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1158_fu_22366_p2() {
    add_ln703_1158_fu_22366_p2 = (!sext_ln1118_507_fu_22166_p1.read().is_01() || !sext_ln703_207_fu_22362_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_507_fu_22166_p1.read()) + sc_bigint<16>(sext_ln703_207_fu_22362_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1159_fu_22376_p2() {
    add_ln703_1159_fu_22376_p2 = (!add_ln703_1156_fu_22350_p2.read().is_01() || !sext_ln703_208_fu_22372_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1156_fu_22350_p2.read()) + sc_bigint<18>(sext_ln703_208_fu_22372_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_115_fu_3554_p2() {
    add_ln703_115_fu_3554_p2 = (!add_ln703_112_fu_3536_p2.read().is_01() || !add_ln703_114_fu_3548_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_112_fu_3536_p2.read()) + sc_biguint<18>(add_ln703_114_fu_3548_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1160_fu_26885_p2() {
    add_ln703_1160_fu_26885_p2 = (!add_ln703_1154_reg_36711.read().is_01() || !add_ln703_1159_reg_36716.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1154_reg_36711.read()) + sc_biguint<18>(add_ln703_1159_reg_36716.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1162_fu_22642_p2() {
    add_ln703_1162_fu_22642_p2 = (!trunc_ln708_1144_fu_22404_p4.read().is_01() || !trunc_ln708_1142_fu_22382_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1144_fu_22404_p4.read()) + sc_biguint<18>(trunc_ln708_1142_fu_22382_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1163_fu_22648_p2() {
    add_ln703_1163_fu_22648_p2 = (!trunc_ln708_1153_fu_22523_p4.read().is_01() || !trunc_ln708_1146_fu_22422_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1153_fu_22523_p4.read()) + sc_biguint<18>(trunc_ln708_1146_fu_22422_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1164_fu_22654_p2() {
    add_ln703_1164_fu_22654_p2 = (!trunc_ln708_1145_fu_22413_p4.read().is_01() || !add_ln703_1163_fu_22648_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1145_fu_22413_p4.read()) + sc_biguint<18>(add_ln703_1163_fu_22648_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1165_fu_22660_p2() {
    add_ln703_1165_fu_22660_p2 = (!add_ln703_1162_fu_22642_p2.read().is_01() || !add_ln703_1164_fu_22654_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1162_fu_22642_p2.read()) + sc_biguint<18>(add_ln703_1164_fu_22654_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1166_fu_22666_p2() {
    add_ln703_1166_fu_22666_p2 = (!trunc_ln708_1158_fu_22591_p4.read().is_01() || !trunc_ln708_1154_fu_22532_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1158_fu_22591_p4.read()) + sc_biguint<18>(trunc_ln708_1154_fu_22532_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1167_fu_22672_p2() {
    add_ln703_1167_fu_22672_p2 = (!sext_ln708_268_fu_22460_p1.read().is_01() || !sext_ln708_267_fu_22440_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_268_fu_22460_p1.read()) + sc_bigint<18>(sext_ln708_267_fu_22440_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1168_fu_22678_p2() {
    add_ln703_1168_fu_22678_p2 = (!trunc_ln708_1160_fu_22620_p4.read().is_01() || !add_ln703_1167_fu_22672_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1160_fu_22620_p4.read()) + sc_biguint<18>(add_ln703_1167_fu_22672_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1169_fu_26895_p2() {
    add_ln703_1169_fu_26895_p2 = (!add_ln703_1166_reg_36726.read().is_01() || !add_ln703_1168_reg_36731.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1166_reg_36726.read()) + sc_biguint<18>(add_ln703_1168_reg_36731.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_116_fu_3560_p2() {
    add_ln703_116_fu_3560_p2 = (!sext_ln1118_165_fu_3354_p1.read().is_01() || !sext_ln1118_166_fu_3380_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_165_fu_3354_p1.read()) + sc_bigint<16>(sext_ln1118_166_fu_3380_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1170_fu_26899_p2() {
    add_ln703_1170_fu_26899_p2 = (!add_ln703_1165_reg_36721.read().is_01() || !add_ln703_1169_fu_26895_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1165_reg_36721.read()) + sc_biguint<18>(add_ln703_1169_fu_26895_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1171_fu_22684_p2() {
    add_ln703_1171_fu_22684_p2 = (!sext_ln708_271_fu_22519_p1.read().is_01() || !sext_ln708_270_fu_22506_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_271_fu_22519_p1.read()) + sc_bigint<18>(sext_ln708_270_fu_22506_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1172_fu_22690_p2() {
    add_ln703_1172_fu_22690_p2 = (!sext_ln708_266_fu_22400_p1.read().is_01() || !sext_ln708_273_fu_22638_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_266_fu_22400_p1.read()) + sc_bigint<18>(sext_ln708_273_fu_22638_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1173_fu_22696_p2() {
    add_ln703_1173_fu_22696_p2 = (!sext_ln708_272_fu_22574_p1.read().is_01() || !add_ln703_1172_fu_22690_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_272_fu_22574_p1.read()) + sc_biguint<18>(add_ln703_1172_fu_22690_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1174_fu_22702_p2() {
    add_ln703_1174_fu_22702_p2 = (!add_ln703_1171_fu_22684_p2.read().is_01() || !add_ln703_1173_fu_22696_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1171_fu_22684_p2.read()) + sc_biguint<18>(add_ln703_1173_fu_22696_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1175_fu_22708_p2() {
    add_ln703_1175_fu_22708_p2 = (!sext_ln1118_514_fu_22616_p1.read().is_01() || !sext_ln1118_513_fu_22587_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_514_fu_22616_p1.read()) + sc_bigint<17>(sext_ln1118_513_fu_22587_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1176_fu_22718_p2() {
    add_ln703_1176_fu_22718_p2 = (!sext_ln708_269_fu_22473_p1.read().is_01() || !sext_ln703_209_fu_22714_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_269_fu_22473_p1.read()) + sc_bigint<18>(sext_ln703_209_fu_22714_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1177_fu_22724_p2() {
    add_ln703_1177_fu_22724_p2 = (!sext_ln1118_512_fu_22561_p1.read().is_01() || !ap_const_lv13_AA.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_512_fu_22561_p1.read()) + sc_biguint<13>(ap_const_lv13_AA));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1178_fu_22734_p2() {
    add_ln703_1178_fu_22734_p2 = (!sext_ln1118_511_fu_22493_p1.read().is_01() || !sext_ln703_210_fu_22730_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_511_fu_22493_p1.read()) + sc_bigint<16>(sext_ln703_210_fu_22730_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1179_fu_22744_p2() {
    add_ln703_1179_fu_22744_p2 = (!add_ln703_1176_fu_22718_p2.read().is_01() || !sext_ln703_211_fu_22740_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1176_fu_22718_p2.read()) + sc_bigint<18>(sext_ln703_211_fu_22740_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_117_fu_3570_p2() {
    add_ln703_117_fu_3570_p2 = (!sext_ln1118_157_fu_3209_p1.read().is_01() || !sext_ln703_46_fu_3566_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_157_fu_3209_p1.read()) + sc_bigint<17>(sext_ln703_46_fu_3566_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1180_fu_26904_p2() {
    add_ln703_1180_fu_26904_p2 = (!add_ln703_1174_reg_36736.read().is_01() || !add_ln703_1179_reg_36741.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1174_reg_36736.read()) + sc_biguint<18>(add_ln703_1179_reg_36741.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1182_fu_22984_p2() {
    add_ln703_1182_fu_22984_p2 = (!trunc_ln708_1163_fu_22766_p4.read().is_01() || !trunc_ln708_1162_fu_22756_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1163_fu_22766_p4.read()) + sc_biguint<18>(trunc_ln708_1162_fu_22756_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1183_fu_22990_p2() {
    add_ln703_1183_fu_22990_p2 = (!trunc_ln708_1166_fu_22793_p4.read().is_01() || !trunc_ln708_1165_fu_22784_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1166_fu_22793_p4.read()) + sc_biguint<18>(trunc_ln708_1165_fu_22784_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1184_fu_22996_p2() {
    add_ln703_1184_fu_22996_p2 = (!trunc_ln708_1164_fu_22775_p4.read().is_01() || !add_ln703_1183_fu_22990_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1164_fu_22775_p4.read()) + sc_biguint<18>(add_ln703_1183_fu_22990_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1185_fu_23002_p2() {
    add_ln703_1185_fu_23002_p2 = (!add_ln703_1182_fu_22984_p2.read().is_01() || !add_ln703_1184_fu_22996_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1182_fu_22984_p2.read()) + sc_biguint<18>(add_ln703_1184_fu_22996_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1186_fu_23008_p2() {
    add_ln703_1186_fu_23008_p2 = (!trunc_ln708_1172_fu_22882_p4.read().is_01() || !trunc_ln708_1169_fu_22846_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1172_fu_22882_p4.read()) + sc_biguint<18>(trunc_ln708_1169_fu_22846_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1187_fu_23014_p2() {
    add_ln703_1187_fu_23014_p2 = (!trunc_ln708_1177_fu_22935_p4.read().is_01() || !trunc_ln708_1176_fu_22926_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1177_fu_22935_p4.read()) + sc_biguint<18>(trunc_ln708_1176_fu_22926_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1188_fu_23020_p2() {
    add_ln703_1188_fu_23020_p2 = (!trunc_ln708_1173_fu_22891_p4.read().is_01() || !add_ln703_1187_fu_23014_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1173_fu_22891_p4.read()) + sc_biguint<18>(add_ln703_1187_fu_23014_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1189_fu_26917_p2() {
    add_ln703_1189_fu_26917_p2 = (!add_ln703_1186_reg_36756.read().is_01() || !add_ln703_1188_reg_36761.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1186_reg_36756.read()) + sc_biguint<18>(add_ln703_1188_reg_36761.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_118_fu_3576_p2() {
    add_ln703_118_fu_3576_p2 = (!sext_ln1118_164_fu_3323_p1.read().is_01() || !ap_const_lv13_26.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_164_fu_3323_p1.read()) + sc_biguint<13>(ap_const_lv13_26));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1190_fu_26921_p2() {
    add_ln703_1190_fu_26921_p2 = (!add_ln703_1185_reg_36751.read().is_01() || !add_ln703_1189_fu_26917_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1185_reg_36751.read()) + sc_biguint<18>(add_ln703_1189_fu_26917_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1191_fu_23026_p2() {
    add_ln703_1191_fu_23026_p2 = (!trunc_ln708_1180_fu_22962_p4.read().is_01() || !trunc_ln708_1179_fu_22953_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1180_fu_22962_p4.read()) + sc_biguint<18>(trunc_ln708_1179_fu_22953_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1192_fu_23032_p2() {
    add_ln703_1192_fu_23032_p2 = (!sext_ln708_276_fu_22922_p1.read().is_01() || !sext_ln708_275_fu_22878_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_276_fu_22922_p1.read()) + sc_bigint<18>(sext_ln708_275_fu_22878_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1193_fu_23038_p2() {
    add_ln703_1193_fu_23038_p2 = (!sext_ln708_274_fu_22824_p1.read().is_01() || !add_ln703_1192_fu_23032_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_274_fu_22824_p1.read()) + sc_biguint<18>(add_ln703_1192_fu_23032_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1194_fu_23044_p2() {
    add_ln703_1194_fu_23044_p2 = (!add_ln703_1191_fu_23026_p2.read().is_01() || !add_ln703_1193_fu_23038_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1191_fu_23026_p2.read()) + sc_biguint<18>(add_ln703_1193_fu_23038_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1195_fu_23050_p2() {
    add_ln703_1195_fu_23050_p2 = (!sext_ln703_212_fu_22980_p1.read().is_01() || !sext_ln1118_518_fu_22909_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_212_fu_22980_p1.read()) + sc_bigint<17>(sext_ln1118_518_fu_22909_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1196_fu_26929_p2() {
    add_ln703_1196_fu_26929_p2 = (!sext_ln708_277_fu_26914_p1.read().is_01() || !sext_ln703_213_fu_26926_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_277_fu_26914_p1.read()) + sc_bigint<18>(sext_ln703_213_fu_26926_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1197_fu_23056_p2() {
    add_ln703_1197_fu_23056_p2 = (!sext_ln1118_517_fu_22865_p1.read().is_01() || !ap_const_lv16_53.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_517_fu_22865_p1.read()) + sc_biguint<16>(ap_const_lv16_53));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1198_fu_23066_p2() {
    add_ln703_1198_fu_23066_p2 = (!sext_ln1118_515_fu_22811_p1.read().is_01() || !sext_ln703_214_fu_23062_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_515_fu_22811_p1.read()) + sc_bigint<17>(sext_ln703_214_fu_23062_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1199_fu_26938_p2() {
    add_ln703_1199_fu_26938_p2 = (!add_ln703_1196_fu_26929_p2.read().is_01() || !sext_ln703_215_fu_26935_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1196_fu_26929_p2.read()) + sc_bigint<18>(sext_ln703_215_fu_26935_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_119_fu_3586_p2() {
    add_ln703_119_fu_3586_p2 = (!sext_ln1118_168_fu_3430_p1.read().is_01() || !sext_ln703_47_fu_3582_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_168_fu_3430_p1.read()) + sc_bigint<15>(sext_ln703_47_fu_3582_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1200_fu_26944_p2() {
    add_ln703_1200_fu_26944_p2 = (!add_ln703_1194_reg_36766.read().is_01() || !add_ln703_1199_fu_26938_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1194_reg_36766.read()) + sc_biguint<18>(add_ln703_1199_fu_26938_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1202_fu_23283_p2() {
    add_ln703_1202_fu_23283_p2 = (!trunc_ln708_1183_fu_23081_p4.read().is_01() || !trunc_ln708_1182_fu_23072_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1183_fu_23081_p4.read()) + sc_biguint<18>(trunc_ln708_1182_fu_23072_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1203_fu_23289_p2() {
    add_ln703_1203_fu_23289_p2 = (!trunc_ln708_1187_fu_23121_p4.read().is_01() || !trunc_ln708_1186_fu_23112_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1187_fu_23121_p4.read()) + sc_biguint<18>(trunc_ln708_1186_fu_23112_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1204_fu_23295_p2() {
    add_ln703_1204_fu_23295_p2 = (!trunc_ln708_1184_fu_23090_p4.read().is_01() || !add_ln703_1203_fu_23289_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1184_fu_23090_p4.read()) + sc_biguint<18>(add_ln703_1203_fu_23289_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1205_fu_23301_p2() {
    add_ln703_1205_fu_23301_p2 = (!add_ln703_1202_fu_23283_p2.read().is_01() || !add_ln703_1204_fu_23295_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1202_fu_23283_p2.read()) + sc_biguint<18>(add_ln703_1204_fu_23295_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1206_fu_23307_p2() {
    add_ln703_1206_fu_23307_p2 = (!trunc_ln708_1189_fu_23139_p4.read().is_01() || !trunc_ln708_1188_fu_23130_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1189_fu_23139_p4.read()) + sc_biguint<18>(trunc_ln708_1188_fu_23130_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1207_fu_23313_p2() {
    add_ln703_1207_fu_23313_p2 = (!trunc_ln708_1198_fu_23256_p4.read().is_01() || !trunc_ln708_1196_fu_23234_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1198_fu_23256_p4.read()) + sc_biguint<18>(trunc_ln708_1196_fu_23234_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1208_fu_23319_p2() {
    add_ln703_1208_fu_23319_p2 = (!trunc_ln708_1191_fu_23161_p4.read().is_01() || !add_ln703_1207_fu_23313_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1191_fu_23161_p4.read()) + sc_biguint<18>(add_ln703_1207_fu_23313_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1209_fu_26961_p2() {
    add_ln703_1209_fu_26961_p2 = (!add_ln703_1206_reg_36796.read().is_01() || !add_ln703_1208_reg_36801.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1206_reg_36796.read()) + sc_biguint<18>(add_ln703_1208_reg_36801.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_120_fu_3596_p2() {
    add_ln703_120_fu_3596_p2 = (!add_ln703_117_fu_3570_p2.read().is_01() || !sext_ln703_48_fu_3592_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(add_ln703_117_fu_3570_p2.read()) + sc_bigint<17>(sext_ln703_48_fu_3592_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1210_fu_26965_p2() {
    add_ln703_1210_fu_26965_p2 = (!add_ln703_1205_reg_36791.read().is_01() || !add_ln703_1209_fu_26961_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1205_reg_36791.read()) + sc_biguint<18>(add_ln703_1209_fu_26961_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1211_fu_23325_p2() {
    add_ln703_1211_fu_23325_p2 = (!trunc_ln708_1200_fu_23274_p4.read().is_01() || !trunc_ln708_1199_fu_23265_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1200_fu_23274_p4.read()) + sc_biguint<18>(trunc_ln708_1199_fu_23265_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1212_fu_23331_p2() {
    add_ln703_1212_fu_23331_p2 = (!sext_ln708_280_fu_23205_p1.read().is_01() || !sext_ln708_279_fu_23179_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_280_fu_23205_p1.read()) + sc_bigint<18>(sext_ln708_279_fu_23179_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1213_fu_23337_p2() {
    add_ln703_1213_fu_23337_p2 = (!sext_ln708_278_fu_23108_p1.read().is_01() || !add_ln703_1212_fu_23331_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_278_fu_23108_p1.read()) + sc_biguint<18>(add_ln703_1212_fu_23331_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1214_fu_23343_p2() {
    add_ln703_1214_fu_23343_p2 = (!add_ln703_1211_fu_23325_p2.read().is_01() || !add_ln703_1213_fu_23337_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1211_fu_23325_p2.read()) + sc_biguint<18>(add_ln703_1213_fu_23337_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1215_fu_26970_p2() {
    add_ln703_1215_fu_26970_p2 = (!sext_ln708_282_fu_26958_p1.read().is_01() || !sext_ln708_281_fu_26955_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_282_fu_26958_p1.read()) + sc_bigint<18>(sext_ln708_281_fu_26955_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1216_fu_23349_p2() {
    add_ln703_1216_fu_23349_p2 = (!sext_ln1118_519_fu_23157_p1.read().is_01() || !ap_const_lv16_74.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_519_fu_23157_p1.read()) + sc_biguint<16>(ap_const_lv16_74));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1217_fu_23359_p2() {
    add_ln703_1217_fu_23359_p2 = (!sext_ln1118_520_fu_23252_p1.read().is_01() || !sext_ln703_216_fu_23355_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_520_fu_23252_p1.read()) + sc_bigint<17>(sext_ln703_216_fu_23355_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1218_fu_26979_p2() {
    add_ln703_1218_fu_26979_p2 = (!add_ln703_1215_fu_26970_p2.read().is_01() || !sext_ln703_217_fu_26976_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1215_fu_26970_p2.read()) + sc_bigint<18>(sext_ln703_217_fu_26976_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1219_fu_26985_p2() {
    add_ln703_1219_fu_26985_p2 = (!add_ln703_1214_reg_36806.read().is_01() || !add_ln703_1218_fu_26979_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1214_reg_36806.read()) + sc_biguint<18>(add_ln703_1218_fu_26979_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_121_fu_25508_p2() {
    add_ln703_121_fu_25508_p2 = (!add_ln703_115_reg_35241.read().is_01() || !sext_ln703_49_fu_25505_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_115_reg_35241.read()) + sc_bigint<18>(sext_ln703_49_fu_25505_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1221_fu_23589_p2() {
    add_ln703_1221_fu_23589_p2 = (!trunc_ln708_1202_fu_23374_p4.read().is_01() || !trunc_ln708_1201_fu_23365_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1202_fu_23374_p4.read()) + sc_biguint<18>(trunc_ln708_1201_fu_23365_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1222_fu_23595_p2() {
    add_ln703_1222_fu_23595_p2 = (!trunc_ln708_1205_fu_23401_p4.read().is_01() || !trunc_ln708_1204_fu_23392_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1205_fu_23401_p4.read()) + sc_biguint<18>(trunc_ln708_1204_fu_23392_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1223_fu_23601_p2() {
    add_ln703_1223_fu_23601_p2 = (!trunc_ln708_1203_fu_23383_p4.read().is_01() || !add_ln703_1222_fu_23595_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1203_fu_23383_p4.read()) + sc_biguint<18>(add_ln703_1222_fu_23595_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1224_fu_23607_p2() {
    add_ln703_1224_fu_23607_p2 = (!add_ln703_1221_fu_23589_p2.read().is_01() || !add_ln703_1223_fu_23601_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1221_fu_23589_p2.read()) + sc_biguint<18>(add_ln703_1223_fu_23601_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1225_fu_23613_p2() {
    add_ln703_1225_fu_23613_p2 = (!trunc_ln708_1207_fu_23419_p4.read().is_01() || !trunc_ln708_1206_fu_23410_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1207_fu_23419_p4.read()) + sc_biguint<18>(trunc_ln708_1206_fu_23410_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1226_fu_23619_p2() {
    add_ln703_1226_fu_23619_p2 = (!trunc_ln708_1213_fu_23498_p4.read().is_01() || !trunc_ln708_1211_fu_23476_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1213_fu_23498_p4.read()) + sc_biguint<18>(trunc_ln708_1211_fu_23476_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1227_fu_23625_p2() {
    add_ln703_1227_fu_23625_p2 = (!trunc_ln708_1210_fu_23467_p4.read().is_01() || !add_ln703_1226_fu_23619_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1210_fu_23467_p4.read()) + sc_biguint<18>(add_ln703_1226_fu_23619_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1228_fu_27002_p2() {
    add_ln703_1228_fu_27002_p2 = (!add_ln703_1225_reg_36831.read().is_01() || !add_ln703_1227_reg_36836.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1225_reg_36831.read()) + sc_biguint<18>(add_ln703_1227_reg_36836.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1229_fu_27006_p2() {
    add_ln703_1229_fu_27006_p2 = (!add_ln703_1224_reg_36826.read().is_01() || !add_ln703_1228_fu_27002_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1224_reg_36826.read()) + sc_biguint<18>(add_ln703_1228_fu_27002_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1230_fu_23631_p2() {
    add_ln703_1230_fu_23631_p2 = (!trunc_ln708_1215_fu_23516_p4.read().is_01() || !trunc_ln708_1214_fu_23507_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1215_fu_23516_p4.read()) + sc_biguint<18>(trunc_ln708_1214_fu_23507_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1231_fu_23637_p2() {
    add_ln703_1231_fu_23637_p2 = (!trunc_ln708_1220_fu_23580_p4.read().is_01() || !trunc_ln708_1217_fu_23534_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1220_fu_23580_p4.read()) + sc_biguint<18>(trunc_ln708_1217_fu_23534_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1232_fu_23643_p2() {
    add_ln703_1232_fu_23643_p2 = (!trunc_ln708_1216_fu_23525_p4.read().is_01() || !add_ln703_1231_fu_23637_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1216_fu_23525_p4.read()) + sc_biguint<18>(add_ln703_1231_fu_23637_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1233_fu_23649_p2() {
    add_ln703_1233_fu_23649_p2 = (!add_ln703_1230_fu_23631_p2.read().is_01() || !add_ln703_1232_fu_23643_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1230_fu_23631_p2.read()) + sc_biguint<18>(add_ln703_1232_fu_23643_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1234_fu_23655_p2() {
    add_ln703_1234_fu_23655_p2 = (!sext_ln1118_522_fu_23494_p1.read().is_01() || !sext_ln1118_521_fu_23437_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_522_fu_23494_p1.read()) + sc_bigint<17>(sext_ln1118_521_fu_23437_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1235_fu_23665_p2() {
    add_ln703_1235_fu_23665_p2 = (!sext_ln708_283_fu_23463_p1.read().is_01() || !sext_ln703_218_fu_23661_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_283_fu_23463_p1.read()) + sc_bigint<18>(sext_ln703_218_fu_23661_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1236_fu_27011_p2() {
    add_ln703_1236_fu_27011_p2 = (!sext_ln1118_524_fu_26999_p1.read().is_01() || !ap_const_lv17_1D.is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_524_fu_26999_p1.read()) + sc_biguint<17>(ap_const_lv17_1D));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1237_fu_27021_p2() {
    add_ln703_1237_fu_27021_p2 = (!sext_ln708_284_fu_26996_p1.read().is_01() || !sext_ln703_219_fu_27017_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_284_fu_26996_p1.read()) + sc_bigint<18>(sext_ln703_219_fu_27017_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1238_fu_27027_p2() {
    add_ln703_1238_fu_27027_p2 = (!add_ln703_1235_reg_36846.read().is_01() || !add_ln703_1237_fu_27021_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1235_reg_36846.read()) + sc_biguint<18>(add_ln703_1237_fu_27021_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1239_fu_27032_p2() {
    add_ln703_1239_fu_27032_p2 = (!add_ln703_1233_reg_36841.read().is_01() || !add_ln703_1238_fu_27027_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1233_reg_36841.read()) + sc_biguint<18>(add_ln703_1238_fu_27027_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_123_fu_3856_p2() {
    add_ln703_123_fu_3856_p2 = (!trunc_ln708_123_fu_3629_p4.read().is_01() || !trunc_ln708_103_fu_3213_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_123_fu_3629_p4.read()) + sc_biguint<18>(trunc_ln708_103_fu_3213_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1241_fu_23943_p2() {
    add_ln703_1241_fu_23943_p2 = (!trunc_ln708_1224_fu_23706_p4.read().is_01() || !trunc_ln708_1223_fu_23697_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1224_fu_23706_p4.read()) + sc_biguint<18>(trunc_ln708_1223_fu_23697_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1242_fu_23949_p2() {
    add_ln703_1242_fu_23949_p2 = (!trunc_ln708_1230_fu_23809_p4.read().is_01() || !trunc_ln708_1227_fu_23774_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1230_fu_23809_p4.read()) + sc_biguint<18>(trunc_ln708_1227_fu_23774_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1243_fu_23955_p2() {
    add_ln703_1243_fu_23955_p2 = (!trunc_ln708_1226_fu_23765_p4.read().is_01() || !add_ln703_1242_fu_23949_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1226_fu_23765_p4.read()) + sc_biguint<18>(add_ln703_1242_fu_23949_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1244_fu_23961_p2() {
    add_ln703_1244_fu_23961_p2 = (!add_ln703_1241_fu_23943_p2.read().is_01() || !add_ln703_1243_fu_23955_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1241_fu_23943_p2.read()) + sc_biguint<18>(add_ln703_1243_fu_23955_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1245_fu_23967_p2() {
    add_ln703_1245_fu_23967_p2 = (!trunc_ln708_1232_fu_23827_p4.read().is_01() || !trunc_ln708_1231_fu_23818_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1232_fu_23827_p4.read()) + sc_biguint<18>(trunc_ln708_1231_fu_23818_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1246_fu_23973_p2() {
    add_ln703_1246_fu_23973_p2 = (!trunc_ln708_1238_fu_23912_p4.read().is_01() || !trunc_ln708_1237_fu_23903_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1238_fu_23912_p4.read()) + sc_biguint<18>(trunc_ln708_1237_fu_23903_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1247_fu_23979_p2() {
    add_ln703_1247_fu_23979_p2 = (!trunc_ln708_1234_fu_23849_p4.read().is_01() || !add_ln703_1246_fu_23973_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1234_fu_23849_p4.read()) + sc_biguint<18>(add_ln703_1246_fu_23973_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1248_fu_27043_p2() {
    add_ln703_1248_fu_27043_p2 = (!add_ln703_1245_reg_36856.read().is_01() || !add_ln703_1247_reg_36861.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1245_reg_36856.read()) + sc_biguint<18>(add_ln703_1247_reg_36861.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1249_fu_27047_p2() {
    add_ln703_1249_fu_27047_p2 = (!add_ln703_1244_reg_36851.read().is_01() || !add_ln703_1248_fu_27043_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1244_reg_36851.read()) + sc_biguint<18>(add_ln703_1248_fu_27043_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_124_fu_3862_p2() {
    add_ln703_124_fu_3862_p2 = (!trunc_ln708_130_fu_3708_p4.read().is_01() || !trunc_ln708_129_fu_3699_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_130_fu_3708_p4.read()) + sc_biguint<18>(trunc_ln708_129_fu_3699_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1250_fu_23985_p2() {
    add_ln703_1250_fu_23985_p2 = (!sext_ln708_285_fu_23680_p1.read().is_01() || !trunc_ln708_1240_fu_23934_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_285_fu_23680_p1.read()) + sc_biguint<18>(trunc_ln708_1240_fu_23934_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1251_fu_23991_p2() {
    add_ln703_1251_fu_23991_p2 = (!sext_ln708_288_fu_23805_p1.read().is_01() || !sext_ln708_287_fu_23792_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_288_fu_23805_p1.read()) + sc_bigint<18>(sext_ln708_287_fu_23792_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1252_fu_23997_p2() {
    add_ln703_1252_fu_23997_p2 = (!sext_ln708_286_fu_23693_p1.read().is_01() || !add_ln703_1251_fu_23991_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_286_fu_23693_p1.read()) + sc_biguint<18>(add_ln703_1251_fu_23991_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1253_fu_24003_p2() {
    add_ln703_1253_fu_24003_p2 = (!add_ln703_1250_fu_23985_p2.read().is_01() || !add_ln703_1252_fu_23997_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1250_fu_23985_p2.read()) + sc_biguint<18>(add_ln703_1252_fu_23997_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1254_fu_24009_p2() {
    add_ln703_1254_fu_24009_p2 = (!sext_ln1118_527_fu_23761_p1.read().is_01() || !sext_ln1118_528_fu_23845_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_527_fu_23761_p1.read()) + sc_bigint<17>(sext_ln1118_528_fu_23845_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1255_fu_24019_p2() {
    add_ln703_1255_fu_24019_p2 = (!sext_ln708_289_fu_23867_p1.read().is_01() || !sext_ln703_220_fu_24015_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_289_fu_23867_p1.read()) + sc_bigint<18>(sext_ln703_220_fu_24015_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1256_fu_24025_p2() {
    add_ln703_1256_fu_24025_p2 = (!sext_ln1118_530_fu_23899_p1.read().is_01() || !ap_const_lv15_12.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_530_fu_23899_p1.read()) + sc_biguint<15>(ap_const_lv15_12));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1257_fu_24035_p2() {
    add_ln703_1257_fu_24035_p2 = (!sext_ln1118_531_fu_23930_p1.read().is_01() || !sext_ln703_221_fu_24031_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_531_fu_23930_p1.read()) + sc_bigint<16>(sext_ln703_221_fu_24031_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1258_fu_24045_p2() {
    add_ln703_1258_fu_24045_p2 = (!add_ln703_1255_fu_24019_p2.read().is_01() || !sext_ln703_222_fu_24041_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1255_fu_24019_p2.read()) + sc_bigint<18>(sext_ln703_222_fu_24041_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1259_fu_27052_p2() {
    add_ln703_1259_fu_27052_p2 = (!add_ln703_1253_reg_36866.read().is_01() || !add_ln703_1258_reg_36871.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1253_reg_36866.read()) + sc_biguint<18>(add_ln703_1258_reg_36871.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_125_fu_3868_p2() {
    add_ln703_125_fu_3868_p2 = (!trunc_ln708_124_fu_3638_p4.read().is_01() || !add_ln703_124_fu_3862_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_124_fu_3638_p4.read()) + sc_biguint<18>(add_ln703_124_fu_3862_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1261_fu_24234_p2() {
    add_ln703_1261_fu_24234_p2 = (!trunc_ln708_1242_fu_24060_p4.read().is_01() || !trunc_ln708_1241_fu_24051_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1242_fu_24060_p4.read()) + sc_biguint<18>(trunc_ln708_1241_fu_24051_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1262_fu_24240_p2() {
    add_ln703_1262_fu_24240_p2 = (!trunc_ln708_1246_fu_24100_p4.read().is_01() || !trunc_ln708_1245_fu_24091_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1246_fu_24100_p4.read()) + sc_biguint<18>(trunc_ln708_1245_fu_24091_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1263_fu_24246_p2() {
    add_ln703_1263_fu_24246_p2 = (!trunc_ln708_1243_fu_24069_p4.read().is_01() || !add_ln703_1262_fu_24240_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1243_fu_24069_p4.read()) + sc_biguint<18>(add_ln703_1262_fu_24240_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1264_fu_24252_p2() {
    add_ln703_1264_fu_24252_p2 = (!add_ln703_1261_fu_24234_p2.read().is_01() || !add_ln703_1263_fu_24246_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1261_fu_24234_p2.read()) + sc_biguint<18>(add_ln703_1263_fu_24246_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1265_fu_24258_p2() {
    add_ln703_1265_fu_24258_p2 = (!trunc_ln708_1250_fu_24144_p4.read().is_01() || !trunc_ln708_1249_fu_24135_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1250_fu_24144_p4.read()) + sc_biguint<18>(trunc_ln708_1249_fu_24135_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1266_fu_24264_p2() {
    add_ln703_1266_fu_24264_p2 = (!trunc_ln708_1253_fu_24171_p4.read().is_01() || !trunc_ln708_1252_fu_24162_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1253_fu_24171_p4.read()) + sc_biguint<18>(trunc_ln708_1252_fu_24162_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1267_fu_24270_p2() {
    add_ln703_1267_fu_24270_p2 = (!trunc_ln708_565_fu_12161_p4.read().is_01() || !add_ln703_1266_fu_24264_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_565_fu_12161_p4.read()) + sc_biguint<18>(add_ln703_1266_fu_24264_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1268_fu_27068_p2() {
    add_ln703_1268_fu_27068_p2 = (!add_ln703_1265_reg_36891.read().is_01() || !add_ln703_1267_reg_36896.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1265_reg_36891.read()) + sc_biguint<18>(add_ln703_1267_reg_36896.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1269_fu_27072_p2() {
    add_ln703_1269_fu_27072_p2 = (!add_ln703_1264_reg_36886.read().is_01() || !add_ln703_1268_fu_27068_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1264_reg_36886.read()) + sc_biguint<18>(add_ln703_1268_fu_27068_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_126_fu_3874_p2() {
    add_ln703_126_fu_3874_p2 = (!add_ln703_123_fu_3856_p2.read().is_01() || !add_ln703_125_fu_3868_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_123_fu_3856_p2.read()) + sc_biguint<18>(add_ln703_125_fu_3868_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1270_fu_24276_p2() {
    add_ln703_1270_fu_24276_p2 = (!trunc_ln708_1256_fu_24198_p4.read().is_01() || !trunc_ln708_1255_fu_24189_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1256_fu_24198_p4.read()) + sc_biguint<18>(trunc_ln708_1255_fu_24189_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1271_fu_24282_p2() {
    add_ln703_1271_fu_24282_p2 = (!trunc_ln708_1259_fu_24225_p4.read().is_01() || !trunc_ln708_1258_fu_24216_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1259_fu_24225_p4.read()) + sc_biguint<18>(trunc_ln708_1258_fu_24216_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1272_fu_24288_p2() {
    add_ln703_1272_fu_24288_p2 = (!trunc_ln708_1257_fu_24207_p4.read().is_01() || !add_ln703_1271_fu_24282_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1257_fu_24207_p4.read()) + sc_biguint<18>(add_ln703_1271_fu_24282_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1273_fu_24294_p2() {
    add_ln703_1273_fu_24294_p2 = (!add_ln703_1270_fu_24276_p2.read().is_01() || !add_ln703_1272_fu_24288_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1270_fu_24276_p2.read()) + sc_biguint<18>(add_ln703_1272_fu_24288_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1274_fu_24300_p2() {
    add_ln703_1274_fu_24300_p2 = (!sext_ln708_292_fu_24131_p1.read().is_01() || !sext_ln708_291_fu_24118_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_292_fu_24131_p1.read()) + sc_bigint<18>(sext_ln708_291_fu_24118_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1275_fu_24306_p2() {
    add_ln703_1275_fu_24306_p2 = (!sext_ln708_290_fu_24087_p1.read().is_01() || !add_ln703_1274_fu_24300_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_290_fu_24087_p1.read()) + sc_biguint<18>(add_ln703_1274_fu_24300_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1276_fu_27077_p2() {
    add_ln703_1276_fu_27077_p2 = (!sext_ln708_294_fu_27065_p1.read().is_01() || !ap_const_lv18_3FF5B.is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_294_fu_27065_p1.read()) + sc_bigint<18>(ap_const_lv18_3FF5B));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1277_fu_27083_p2() {
    add_ln703_1277_fu_27083_p2 = (!sext_ln708_293_fu_27062_p1.read().is_01() || !add_ln703_1276_fu_27077_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_293_fu_27062_p1.read()) + sc_biguint<18>(add_ln703_1276_fu_27077_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1278_fu_27089_p2() {
    add_ln703_1278_fu_27089_p2 = (!add_ln703_1275_reg_36906.read().is_01() || !add_ln703_1277_fu_27083_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1275_reg_36906.read()) + sc_biguint<18>(add_ln703_1277_fu_27083_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1279_fu_27094_p2() {
    add_ln703_1279_fu_27094_p2 = (!add_ln703_1273_reg_36901.read().is_01() || !add_ln703_1278_fu_27089_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1273_reg_36901.read()) + sc_biguint<18>(add_ln703_1278_fu_27089_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_127_fu_3880_p2() {
    add_ln703_127_fu_3880_p2 = (!trunc_ln708_132_fu_3726_p4.read().is_01() || !trunc_ln708_131_fu_3717_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_132_fu_3726_p4.read()) + sc_biguint<18>(trunc_ln708_131_fu_3717_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1281_fu_24547_p2() {
    add_ln703_1281_fu_24547_p2 = (!trunc_ln708_1261_fu_24321_p4.read().is_01() || !trunc_ln708_1260_fu_24312_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1261_fu_24321_p4.read()) + sc_biguint<18>(trunc_ln708_1260_fu_24312_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1282_fu_24553_p2() {
    add_ln703_1282_fu_24553_p2 = (!trunc_ln708_1265_fu_24361_p4.read().is_01() || !trunc_ln708_1264_fu_24352_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1265_fu_24361_p4.read()) + sc_biguint<18>(trunc_ln708_1264_fu_24352_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1283_fu_24559_p2() {
    add_ln703_1283_fu_24559_p2 = (!trunc_ln708_1263_fu_24343_p4.read().is_01() || !add_ln703_1282_fu_24553_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1263_fu_24343_p4.read()) + sc_biguint<18>(add_ln703_1282_fu_24553_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1284_fu_24565_p2() {
    add_ln703_1284_fu_24565_p2 = (!add_ln703_1281_fu_24547_p2.read().is_01() || !add_ln703_1283_fu_24559_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1281_fu_24547_p2.read()) + sc_biguint<18>(add_ln703_1283_fu_24559_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1285_fu_24571_p2() {
    add_ln703_1285_fu_24571_p2 = (!trunc_ln708_1267_fu_24379_p4.read().is_01() || !trunc_ln708_1266_fu_24370_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1267_fu_24379_p4.read()) + sc_biguint<18>(trunc_ln708_1266_fu_24370_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1286_fu_24577_p2() {
    add_ln703_1286_fu_24577_p2 = (!trunc_ln708_1272_fu_24439_p4.read().is_01() || !trunc_ln708_1271_fu_24430_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1272_fu_24439_p4.read()) + sc_biguint<18>(trunc_ln708_1271_fu_24430_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1287_fu_24583_p2() {
    add_ln703_1287_fu_24583_p2 = (!trunc_ln708_1268_fu_24388_p4.read().is_01() || !add_ln703_1286_fu_24577_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1268_fu_24388_p4.read()) + sc_biguint<18>(add_ln703_1286_fu_24577_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1288_fu_27105_p2() {
    add_ln703_1288_fu_27105_p2 = (!add_ln703_1285_reg_36916.read().is_01() || !add_ln703_1287_reg_36921.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1285_reg_36916.read()) + sc_biguint<18>(add_ln703_1287_reg_36921.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1289_fu_27109_p2() {
    add_ln703_1289_fu_27109_p2 = (!add_ln703_1284_reg_36911.read().is_01() || !add_ln703_1288_fu_27105_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1284_reg_36911.read()) + sc_biguint<18>(add_ln703_1288_fu_27105_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_128_fu_3886_p2() {
    add_ln703_128_fu_3886_p2 = (!sext_ln708_23_fu_3611_p1.read().is_01() || !trunc_ln708_136_fu_3770_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_23_fu_3611_p1.read()) + sc_biguint<18>(trunc_ln708_136_fu_3770_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1290_fu_24589_p2() {
    add_ln703_1290_fu_24589_p2 = (!trunc_ln708_1275_fu_24470_p4.read().is_01() || !trunc_ln708_1274_fu_24461_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1275_fu_24470_p4.read()) + sc_biguint<18>(trunc_ln708_1274_fu_24461_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1291_fu_24595_p2() {
    add_ln703_1291_fu_24595_p2 = (!sext_ln708_297_fu_24523_p1.read().is_01() || !sext_ln708_296_fu_24426_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_297_fu_24523_p1.read()) + sc_bigint<18>(sext_ln708_296_fu_24426_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1292_fu_24601_p2() {
    add_ln703_1292_fu_24601_p2 = (!trunc_ln708_1277_fu_24505_p4.read().is_01() || !add_ln703_1291_fu_24595_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1277_fu_24505_p4.read()) + sc_biguint<18>(add_ln703_1291_fu_24595_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1293_fu_24607_p2() {
    add_ln703_1293_fu_24607_p2 = (!add_ln703_1290_fu_24589_p2.read().is_01() || !add_ln703_1292_fu_24601_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1290_fu_24589_p2.read()) + sc_biguint<18>(add_ln703_1292_fu_24601_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1294_fu_24613_p2() {
    add_ln703_1294_fu_24613_p2 = (!sext_ln703_223_fu_24543_p1.read().is_01() || !sext_ln1118_533_fu_24457_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_223_fu_24543_p1.read()) + sc_bigint<17>(sext_ln1118_533_fu_24457_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1295_fu_24623_p2() {
    add_ln703_1295_fu_24623_p2 = (!sext_ln708_295_fu_24339_p1.read().is_01() || !sext_ln703_224_fu_24619_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_295_fu_24339_p1.read()) + sc_bigint<18>(sext_ln703_224_fu_24619_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1296_fu_24629_p2() {
    add_ln703_1296_fu_24629_p2 = (!sext_ln1118_532_fu_24413_p1.read().is_01() || !ap_const_lv13_1E12.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_532_fu_24413_p1.read()) + sc_bigint<13>(ap_const_lv13_1E12));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1297_fu_24639_p2() {
    add_ln703_1297_fu_24639_p2 = (!sext_ln1118_534_fu_24501_p1.read().is_01() || !sext_ln703_225_fu_24635_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_534_fu_24501_p1.read()) + sc_bigint<14>(sext_ln703_225_fu_24635_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1298_fu_24649_p2() {
    add_ln703_1298_fu_24649_p2 = (!add_ln703_1295_fu_24623_p2.read().is_01() || !sext_ln703_226_fu_24645_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1295_fu_24623_p2.read()) + sc_bigint<18>(sext_ln703_226_fu_24645_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1299_fu_27114_p2() {
    add_ln703_1299_fu_27114_p2 = (!add_ln703_1293_reg_36926.read().is_01() || !add_ln703_1298_reg_36931.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1293_reg_36926.read()) + sc_biguint<18>(add_ln703_1298_reg_36931.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_129_fu_3892_p2() {
    add_ln703_129_fu_3892_p2 = (!trunc_ln708_135_fu_3761_p4.read().is_01() || !add_ln703_128_fu_3886_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_135_fu_3761_p4.read()) + sc_biguint<18>(add_ln703_128_fu_3886_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1301_fu_24965_p2() {
    add_ln703_1301_fu_24965_p2 = (!trunc_ln708_1282_fu_24718_p4.read().is_01() || !trunc_ln708_1280_fu_24655_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1282_fu_24718_p4.read()) + sc_biguint<18>(trunc_ln708_1280_fu_24655_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1302_fu_24971_p2() {
    add_ln703_1302_fu_24971_p2 = (!trunc_ln708_1285_fu_24745_p4.read().is_01() || !trunc_ln708_1284_fu_24736_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1285_fu_24745_p4.read()) + sc_biguint<18>(trunc_ln708_1284_fu_24736_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1303_fu_24977_p2() {
    add_ln703_1303_fu_24977_p2 = (!trunc_ln708_1283_fu_24727_p4.read().is_01() || !add_ln703_1302_fu_24971_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1283_fu_24727_p4.read()) + sc_biguint<18>(add_ln703_1302_fu_24971_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1304_fu_24983_p2() {
    add_ln703_1304_fu_24983_p2 = (!add_ln703_1301_fu_24965_p2.read().is_01() || !add_ln703_1303_fu_24977_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1301_fu_24965_p2.read()) + sc_biguint<18>(add_ln703_1303_fu_24977_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1305_fu_24989_p2() {
    add_ln703_1305_fu_24989_p2 = (!trunc_ln708_1294_fu_24873_p4.read().is_01() || !trunc_ln708_1287_fu_24786_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1294_fu_24873_p4.read()) + sc_biguint<18>(trunc_ln708_1287_fu_24786_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1306_fu_24995_p2() {
    add_ln703_1306_fu_24995_p2 = (!sext_ln708_298_fu_24782_p1.read().is_01() || !trunc_ln708_1297_fu_24904_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_298_fu_24782_p1.read()) + sc_biguint<18>(trunc_ln708_1297_fu_24904_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1307_fu_25001_p2() {
    add_ln703_1307_fu_25001_p2 = (!trunc_ln708_1296_fu_24895_p4.read().is_01() || !add_ln703_1306_fu_24995_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1296_fu_24895_p4.read()) + sc_biguint<18>(add_ln703_1306_fu_24995_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1308_fu_27124_p2() {
    add_ln703_1308_fu_27124_p2 = (!add_ln703_1305_reg_36941.read().is_01() || !add_ln703_1307_reg_36946.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1305_reg_36941.read()) + sc_biguint<18>(add_ln703_1307_reg_36946.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1309_fu_27128_p2() {
    add_ln703_1309_fu_27128_p2 = (!add_ln703_1304_reg_36936.read().is_01() || !add_ln703_1308_fu_27124_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1304_reg_36936.read()) + sc_biguint<18>(add_ln703_1308_fu_27124_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_130_fu_25519_p2() {
    add_ln703_130_fu_25519_p2 = (!add_ln703_127_reg_35256.read().is_01() || !add_ln703_129_reg_35261.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_127_reg_35256.read()) + sc_biguint<18>(add_ln703_129_reg_35261.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1310_fu_25007_p2() {
    add_ln703_1310_fu_25007_p2 = (!sext_ln708_301_fu_24830_p1.read().is_01() || !sext_ln708_300_fu_24817_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_301_fu_24830_p1.read()) + sc_bigint<18>(sext_ln708_300_fu_24817_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1311_fu_25013_p2() {
    add_ln703_1311_fu_25013_p2 = (!sext_ln708_304_fu_24961_p1.read().is_01() || !sext_ln708_303_fu_24856_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_304_fu_24961_p1.read()) + sc_bigint<18>(sext_ln708_303_fu_24856_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1312_fu_25019_p2() {
    add_ln703_1312_fu_25019_p2 = (!sext_ln708_302_fu_24843_p1.read().is_01() || !add_ln703_1311_fu_25013_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_302_fu_24843_p1.read()) + sc_biguint<18>(add_ln703_1311_fu_25013_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1313_fu_25025_p2() {
    add_ln703_1313_fu_25025_p2 = (!add_ln703_1310_fu_25007_p2.read().is_01() || !add_ln703_1312_fu_25019_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1310_fu_25007_p2.read()) + sc_biguint<18>(add_ln703_1312_fu_25019_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1314_fu_25031_p2() {
    add_ln703_1314_fu_25031_p2 = (!sext_ln1118_541_fu_24891_p1.read().is_01() || !sext_ln1118_540_fu_24869_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_541_fu_24891_p1.read()) + sc_bigint<17>(sext_ln1118_540_fu_24869_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1315_fu_25041_p2() {
    add_ln703_1315_fu_25041_p2 = (!sext_ln708_299_fu_24804_p1.read().is_01() || !sext_ln703_227_fu_25037_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_299_fu_24804_p1.read()) + sc_bigint<18>(sext_ln703_227_fu_25037_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1316_fu_25047_p2() {
    add_ln703_1316_fu_25047_p2 = (!sext_ln1118_542_fu_24929_p1.read().is_01() || !ap_const_lv13_49.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_542_fu_24929_p1.read()) + sc_biguint<13>(ap_const_lv13_49));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1317_fu_25057_p2() {
    add_ln703_1317_fu_25057_p2 = (!sext_ln1118_538_fu_24714_p1.read().is_01() || !sext_ln703_228_fu_25053_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_538_fu_24714_p1.read()) + sc_bigint<14>(sext_ln703_228_fu_25053_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1318_fu_25067_p2() {
    add_ln703_1318_fu_25067_p2 = (!add_ln703_1315_fu_25041_p2.read().is_01() || !sext_ln703_229_fu_25063_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1315_fu_25041_p2.read()) + sc_bigint<18>(sext_ln703_229_fu_25063_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1319_fu_27133_p2() {
    add_ln703_1319_fu_27133_p2 = (!add_ln703_1313_reg_36951.read().is_01() || !add_ln703_1318_reg_36956.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1313_reg_36951.read()) + sc_biguint<18>(add_ln703_1318_reg_36956.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_131_fu_25523_p2() {
    add_ln703_131_fu_25523_p2 = (!add_ln703_126_reg_35251.read().is_01() || !add_ln703_130_fu_25519_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_126_reg_35251.read()) + sc_biguint<18>(add_ln703_130_fu_25519_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1321_fu_25328_p2() {
    add_ln703_1321_fu_25328_p2 = (!trunc_ln708_1302_fu_25108_p4.read().is_01() || !trunc_ln708_1301_fu_25098_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1302_fu_25108_p4.read()) + sc_biguint<18>(trunc_ln708_1301_fu_25098_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1322_fu_25334_p2() {
    add_ln703_1322_fu_25334_p2 = (!trunc_ln708_1309_fu_25226_p4.read().is_01() || !trunc_ln708_1306_fu_25178_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1309_fu_25226_p4.read()) + sc_biguint<18>(trunc_ln708_1306_fu_25178_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1323_fu_25340_p2() {
    add_ln703_1323_fu_25340_p2 = (!trunc_ln708_1304_fu_25149_p4.read().is_01() || !add_ln703_1322_fu_25334_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1304_fu_25149_p4.read()) + sc_biguint<18>(add_ln703_1322_fu_25334_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1324_fu_25346_p2() {
    add_ln703_1324_fu_25346_p2 = (!add_ln703_1321_fu_25328_p2.read().is_01() || !add_ln703_1323_fu_25340_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1321_fu_25328_p2.read()) + sc_biguint<18>(add_ln703_1323_fu_25340_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1325_fu_25352_p2() {
    add_ln703_1325_fu_25352_p2 = (!trunc_ln708_1312_fu_25257_p4.read().is_01() || !trunc_ln708_1311_fu_25248_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1312_fu_25257_p4.read()) + sc_biguint<18>(trunc_ln708_1311_fu_25248_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1326_fu_25358_p2() {
    add_ln703_1326_fu_25358_p2 = (!trunc_ln708_1316_fu_25297_p4.read().is_01() || !trunc_ln708_1315_fu_25288_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1316_fu_25297_p4.read()) + sc_biguint<18>(trunc_ln708_1315_fu_25288_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1327_fu_25364_p2() {
    add_ln703_1327_fu_25364_p2 = (!trunc_ln708_1313_fu_25266_p4.read().is_01() || !add_ln703_1326_fu_25358_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_1313_fu_25266_p4.read()) + sc_biguint<18>(add_ln703_1326_fu_25358_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1328_fu_27143_p2() {
    add_ln703_1328_fu_27143_p2 = (!add_ln703_1325_reg_36966.read().is_01() || !add_ln703_1327_reg_36971.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1325_reg_36966.read()) + sc_biguint<18>(add_ln703_1327_reg_36971.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1329_fu_27147_p2() {
    add_ln703_1329_fu_27147_p2 = (!add_ln703_1324_reg_36961.read().is_01() || !add_ln703_1328_fu_27143_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1324_reg_36961.read()) + sc_biguint<18>(add_ln703_1328_fu_27143_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_132_fu_3898_p2() {
    add_ln703_132_fu_3898_p2 = (!sext_ln708_25_fu_3682_p1.read().is_01() || !sext_ln708_24_fu_3656_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_25_fu_3682_p1.read()) + sc_bigint<18>(sext_ln708_24_fu_3656_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1330_fu_25370_p2() {
    add_ln703_1330_fu_25370_p2 = (!sext_ln708_305_fu_25082_p1.read().is_01() || !trunc_ln708_1318_fu_25319_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_305_fu_25082_p1.read()) + sc_biguint<18>(trunc_ln708_1318_fu_25319_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1331_fu_25376_p2() {
    add_ln703_1331_fu_25376_p2 = (!sext_ln708_307_fu_25196_p1.read().is_01() || !sext_ln708_308_fu_25284_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_307_fu_25196_p1.read()) + sc_bigint<18>(sext_ln708_308_fu_25284_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1332_fu_25382_p2() {
    add_ln703_1332_fu_25382_p2 = (!sext_ln708_306_fu_25174_p1.read().is_01() || !add_ln703_1331_fu_25376_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_306_fu_25174_p1.read()) + sc_biguint<18>(add_ln703_1331_fu_25376_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1333_fu_25388_p2() {
    add_ln703_1333_fu_25388_p2 = (!add_ln703_1330_fu_25370_p2.read().is_01() || !add_ln703_1332_fu_25382_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1330_fu_25370_p2.read()) + sc_biguint<18>(add_ln703_1332_fu_25382_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1334_fu_25394_p2() {
    add_ln703_1334_fu_25394_p2 = (!sext_ln1118_548_fu_25315_p1.read().is_01() || !sext_ln1118_547_fu_25244_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_548_fu_25315_p1.read()) + sc_bigint<16>(sext_ln1118_547_fu_25244_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1335_fu_25404_p2() {
    add_ln703_1335_fu_25404_p2 = (!sext_ln1118_301_fu_8043_p1.read().is_01() || !sext_ln703_230_fu_25400_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_301_fu_8043_p1.read()) + sc_bigint<17>(sext_ln703_230_fu_25400_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1336_fu_25410_p2() {
    add_ln703_1336_fu_25410_p2 = (!sext_ln1118_545_fu_25145_p1.read().is_01() || !ap_const_lv12_82.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_545_fu_25145_p1.read()) + sc_biguint<12>(ap_const_lv12_82));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1337_fu_25420_p2() {
    add_ln703_1337_fu_25420_p2 = (!sext_ln1118_546_fu_25222_p1.read().is_01() || !sext_ln703_231_fu_25416_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_546_fu_25222_p1.read()) + sc_bigint<13>(sext_ln703_231_fu_25416_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1338_fu_25430_p2() {
    add_ln703_1338_fu_25430_p2 = (!add_ln703_1335_fu_25404_p2.read().is_01() || !sext_ln703_232_fu_25426_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(add_ln703_1335_fu_25404_p2.read()) + sc_bigint<17>(sext_ln703_232_fu_25426_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_1339_fu_27155_p2() {
    add_ln703_1339_fu_27155_p2 = (!add_ln703_1333_reg_36976.read().is_01() || !sext_ln703_233_fu_27152_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_1333_reg_36976.read()) + sc_bigint<18>(sext_ln703_233_fu_27152_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_133_fu_3904_p2() {
    add_ln703_133_fu_3904_p2 = (!sext_ln708_28_fu_3757_p1.read().is_01() || !sext_ln708_27_fu_3744_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_28_fu_3757_p1.read()) + sc_bigint<18>(sext_ln708_27_fu_3744_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_134_fu_3910_p2() {
    add_ln703_134_fu_3910_p2 = (!sext_ln708_26_fu_3695_p1.read().is_01() || !add_ln703_133_fu_3904_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_26_fu_3695_p1.read()) + sc_biguint<18>(add_ln703_133_fu_3904_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_135_fu_3916_p2() {
    add_ln703_135_fu_3916_p2 = (!add_ln703_132_fu_3898_p2.read().is_01() || !add_ln703_134_fu_3910_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_132_fu_3898_p2.read()) + sc_biguint<18>(add_ln703_134_fu_3910_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_136_fu_3922_p2() {
    add_ln703_136_fu_3922_p2 = (!sext_ln708_29_fu_3788_p1.read().is_01() || !sext_ln708_31_fu_3852_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_29_fu_3788_p1.read()) + sc_bigint<18>(sext_ln708_31_fu_3852_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_137_fu_3928_p2() {
    add_ln703_137_fu_3928_p2 = (!sext_ln708_30_fu_3832_p1.read().is_01() || !add_ln703_136_fu_3922_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_30_fu_3832_p1.read()) + sc_biguint<18>(add_ln703_136_fu_3922_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_138_fu_3934_p2() {
    add_ln703_138_fu_3934_p2 = (!sext_ln1118_170_fu_3625_p1.read().is_01() || !ap_const_lv13_91.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_170_fu_3625_p1.read()) + sc_biguint<13>(ap_const_lv13_91));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_139_fu_3944_p2() {
    add_ln703_139_fu_3944_p2 = (!sext_ln1118_171_fu_3669_p1.read().is_01() || !sext_ln703_50_fu_3940_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_171_fu_3669_p1.read()) + sc_bigint<16>(sext_ln703_50_fu_3940_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_140_fu_3954_p2() {
    add_ln703_140_fu_3954_p2 = (!add_ln703_137_fu_3928_p2.read().is_01() || !sext_ln703_51_fu_3950_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_137_fu_3928_p2.read()) + sc_bigint<18>(sext_ln703_51_fu_3950_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_141_fu_25528_p2() {
    add_ln703_141_fu_25528_p2 = (!add_ln703_135_reg_35266.read().is_01() || !add_ln703_140_reg_35271.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_135_reg_35266.read()) + sc_biguint<18>(add_ln703_140_reg_35271.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_143_fu_4276_p2() {
    add_ln703_143_fu_4276_p2 = (!trunc_ln708_144_fu_4057_p4.read().is_01() || !trunc_ln708_142_fu_4035_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_144_fu_4057_p4.read()) + sc_biguint<18>(trunc_ln708_142_fu_4035_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_144_fu_4282_p2() {
    add_ln703_144_fu_4282_p2 = (!trunc_ln708_150_fu_4119_p4.read().is_01() || !trunc_ln708_147_fu_4088_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_150_fu_4119_p4.read()) + sc_biguint<18>(trunc_ln708_147_fu_4088_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_145_fu_4288_p2() {
    add_ln703_145_fu_4288_p2 = (!trunc_ln708_146_fu_4079_p4.read().is_01() || !add_ln703_144_fu_4282_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_146_fu_4079_p4.read()) + sc_biguint<18>(add_ln703_144_fu_4282_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_146_fu_4294_p2() {
    add_ln703_146_fu_4294_p2 = (!add_ln703_143_fu_4276_p2.read().is_01() || !add_ln703_145_fu_4288_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_143_fu_4276_p2.read()) + sc_biguint<18>(add_ln703_145_fu_4288_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_147_fu_4300_p2() {
    add_ln703_147_fu_4300_p2 = (!trunc_ln708_155_fu_4223_p4.read().is_01() || !trunc_ln708_151_fu_4128_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_155_fu_4223_p4.read()) + sc_biguint<18>(trunc_ln708_151_fu_4128_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_148_fu_4306_p2() {
    add_ln703_148_fu_4306_p2 = (!sext_ln708_32_fu_4053_p1.read().is_01() || !trunc_ln708_159_fu_4267_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_32_fu_4053_p1.read()) + sc_biguint<18>(trunc_ln708_159_fu_4267_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_149_fu_4312_p2() {
    add_ln703_149_fu_4312_p2 = (!trunc_ln708_158_fu_4258_p4.read().is_01() || !add_ln703_148_fu_4306_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_158_fu_4258_p4.read()) + sc_biguint<18>(add_ln703_148_fu_4306_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_150_fu_25541_p2() {
    add_ln703_150_fu_25541_p2 = (!add_ln703_147_reg_35286.read().is_01() || !add_ln703_149_reg_35291.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_147_reg_35286.read()) + sc_biguint<18>(add_ln703_149_reg_35291.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_151_fu_25545_p2() {
    add_ln703_151_fu_25545_p2 = (!add_ln703_146_reg_35281.read().is_01() || !add_ln703_150_fu_25541_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_146_reg_35281.read()) + sc_biguint<18>(add_ln703_150_fu_25541_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_152_fu_4318_p2() {
    add_ln703_152_fu_4318_p2 = (!sext_ln708_35_fu_4241_p1.read().is_01() || !sext_ln708_34_fu_4206_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_35_fu_4241_p1.read()) + sc_bigint<18>(sext_ln708_34_fu_4206_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_153_fu_4324_p2() {
    add_ln703_153_fu_4324_p2 = (!sext_ln1118_180_fu_4031_p1.read().is_01() || !sext_ln1118_179_fu_4018_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_180_fu_4031_p1.read()) + sc_bigint<17>(sext_ln1118_179_fu_4018_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_154_fu_4334_p2() {
    add_ln703_154_fu_4334_p2 = (!sext_ln708_36_fu_4254_p1.read().is_01() || !sext_ln703_52_fu_4330_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_36_fu_4254_p1.read()) + sc_bigint<18>(sext_ln703_52_fu_4330_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_155_fu_4340_p2() {
    add_ln703_155_fu_4340_p2 = (!add_ln703_152_fu_4318_p2.read().is_01() || !add_ln703_154_fu_4334_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_152_fu_4318_p2.read()) + sc_biguint<18>(add_ln703_154_fu_4334_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_156_fu_4346_p2() {
    add_ln703_156_fu_4346_p2 = (!sext_ln1118_181_fu_4075_p1.read().is_01() || !sext_ln1118_190_fu_4219_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_181_fu_4075_p1.read()) + sc_bigint<17>(sext_ln1118_190_fu_4219_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_157_fu_25553_p2() {
    add_ln703_157_fu_25553_p2 = (!sext_ln708_33_fu_25538_p1.read().is_01() || !sext_ln703_53_fu_25550_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_33_fu_25538_p1.read()) + sc_bigint<18>(sext_ln703_53_fu_25550_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_158_fu_4352_p2() {
    add_ln703_158_fu_4352_p2 = (!sext_ln1118_182_fu_4106_p1.read().is_01() || !ap_const_lv15_46.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_182_fu_4106_p1.read()) + sc_biguint<15>(ap_const_lv15_46));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_159_fu_4362_p2() {
    add_ln703_159_fu_4362_p2 = (!sext_ln1118_189_fu_4193_p1.read().is_01() || !sext_ln703_54_fu_4358_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_189_fu_4193_p1.read()) + sc_bigint<16>(sext_ln703_54_fu_4358_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_160_fu_25562_p2() {
    add_ln703_160_fu_25562_p2 = (!add_ln703_157_fu_25553_p2.read().is_01() || !sext_ln703_55_fu_25559_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_157_fu_25553_p2.read()) + sc_bigint<18>(sext_ln703_55_fu_25559_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_161_fu_25568_p2() {
    add_ln703_161_fu_25568_p2 = (!add_ln703_155_reg_35296.read().is_01() || !add_ln703_160_fu_25562_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_155_reg_35296.read()) + sc_biguint<18>(add_ln703_160_fu_25562_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_163_fu_4722_p2() {
    add_ln703_163_fu_4722_p2 = (!trunc_ln708_163_fu_4407_p4.read().is_01() || !trunc_ln708_82_fu_2820_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_163_fu_4407_p4.read()) + sc_biguint<18>(trunc_ln708_82_fu_2820_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_164_fu_4728_p2() {
    add_ln703_164_fu_4728_p2 = (!trunc_ln708_169_fu_4543_p4.read().is_01() || !trunc_ln708_165_fu_4425_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_169_fu_4543_p4.read()) + sc_biguint<18>(trunc_ln708_165_fu_4425_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_165_fu_4734_p2() {
    add_ln703_165_fu_4734_p2 = (!trunc_ln708_164_fu_4416_p4.read().is_01() || !add_ln703_164_fu_4728_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_164_fu_4416_p4.read()) + sc_biguint<18>(add_ln703_164_fu_4728_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_166_fu_4740_p2() {
    add_ln703_166_fu_4740_p2 = (!add_ln703_163_fu_4722_p2.read().is_01() || !add_ln703_165_fu_4734_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_163_fu_4722_p2.read()) + sc_biguint<18>(add_ln703_165_fu_4734_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_167_fu_4746_p2() {
    add_ln703_167_fu_4746_p2 = (!trunc_ln708_171_fu_4561_p4.read().is_01() || !trunc_ln708_170_fu_4552_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_171_fu_4561_p4.read()) + sc_biguint<18>(trunc_ln708_170_fu_4552_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_168_fu_4752_p2() {
    add_ln703_168_fu_4752_p2 = (!trunc_ln708_176_fu_4691_p4.read().is_01() || !trunc_ln708_174_fu_4662_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_176_fu_4691_p4.read()) + sc_biguint<18>(trunc_ln708_174_fu_4662_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_169_fu_4758_p2() {
    add_ln703_169_fu_4758_p2 = (!trunc_ln708_173_fu_4652_p4.read().is_01() || !add_ln703_168_fu_4752_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_173_fu_4652_p4.read()) + sc_biguint<18>(add_ln703_168_fu_4752_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_170_fu_25579_p2() {
    add_ln703_170_fu_25579_p2 = (!add_ln703_167_reg_35316.read().is_01() || !add_ln703_169_reg_35321.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_167_reg_35316.read()) + sc_biguint<18>(add_ln703_169_reg_35321.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_171_fu_25583_p2() {
    add_ln703_171_fu_25583_p2 = (!add_ln703_166_reg_35311.read().is_01() || !add_ln703_170_fu_25579_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_166_reg_35311.read()) + sc_biguint<18>(add_ln703_170_fu_25579_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_172_fu_4764_p2() {
    add_ln703_172_fu_4764_p2 = (!sext_ln708_37_fu_4377_p1.read().is_01() || !trunc_ln708_177_fu_4700_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_37_fu_4377_p1.read()) + sc_biguint<18>(trunc_ln708_177_fu_4700_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_173_fu_4770_p2() {
    add_ln703_173_fu_4770_p2 = (!sext_ln708_39_fu_4403_p1.read().is_01() || !sext_ln708_40_fu_4443_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_39_fu_4403_p1.read()) + sc_bigint<18>(sext_ln708_40_fu_4443_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_174_fu_4776_p2() {
    add_ln703_174_fu_4776_p2 = (!sext_ln708_38_fu_4390_p1.read().is_01() || !add_ln703_173_fu_4770_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_38_fu_4390_p1.read()) + sc_biguint<18>(add_ln703_173_fu_4770_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_175_fu_4782_p2() {
    add_ln703_175_fu_4782_p2 = (!add_ln703_172_fu_4764_p2.read().is_01() || !add_ln703_174_fu_4776_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_172_fu_4764_p2.read()) + sc_biguint<18>(add_ln703_174_fu_4776_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_176_fu_4788_p2() {
    add_ln703_176_fu_4788_p2 = (!sext_ln1118_198_fu_4539_p1.read().is_01() || !sext_ln1118_203_fu_4618_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_198_fu_4539_p1.read()) + sc_bigint<16>(sext_ln1118_203_fu_4618_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_177_fu_4798_p2() {
    add_ln703_177_fu_4798_p2 = (!sext_ln703_56_fu_4718_p1.read().is_01() || !sext_ln703_57_fu_4794_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_56_fu_4718_p1.read()) + sc_bigint<17>(sext_ln703_57_fu_4794_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_178_fu_4808_p2() {
    add_ln703_178_fu_4808_p2 = (!sext_ln1118_206_fu_4687_p1.read().is_01() || !ap_const_lv14_3FD2.is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_206_fu_4687_p1.read()) + sc_bigint<14>(ap_const_lv14_3FD2));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_179_fu_4818_p2() {
    add_ln703_179_fu_4818_p2 = (!sext_ln1118_194_fu_4491_p1.read().is_01() || !sext_ln703_59_fu_4814_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_194_fu_4491_p1.read()) + sc_bigint<15>(sext_ln703_59_fu_4814_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_180_fu_4828_p2() {
    add_ln703_180_fu_4828_p2 = (!sext_ln703_58_fu_4804_p1.read().is_01() || !sext_ln703_60_fu_4824_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_58_fu_4804_p1.read()) + sc_bigint<18>(sext_ln703_60_fu_4824_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_181_fu_25588_p2() {
    add_ln703_181_fu_25588_p2 = (!add_ln703_175_reg_35326.read().is_01() || !add_ln703_180_reg_35331.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_175_reg_35326.read()) + sc_biguint<18>(add_ln703_180_reg_35331.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_183_fu_5127_p2() {
    add_ln703_183_fu_5127_p2 = (!trunc_ln708_181_fu_4856_p4.read().is_01() || !trunc_ln708_179_fu_4834_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_181_fu_4856_p4.read()) + sc_biguint<18>(trunc_ln708_179_fu_4834_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_184_fu_5133_p2() {
    add_ln703_184_fu_5133_p2 = (!trunc_ln708_186_fu_4948_p4.read().is_01() || !trunc_ln708_185_fu_4939_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_186_fu_4948_p4.read()) + sc_biguint<18>(trunc_ln708_185_fu_4939_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_185_fu_5139_p2() {
    add_ln703_185_fu_5139_p2 = (!trunc_ln708_183_fu_4878_p4.read().is_01() || !add_ln703_184_fu_5133_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_183_fu_4878_p4.read()) + sc_biguint<18>(add_ln703_184_fu_5133_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_186_fu_5145_p2() {
    add_ln703_186_fu_5145_p2 = (!add_ln703_183_fu_5127_p2.read().is_01() || !add_ln703_185_fu_5139_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_183_fu_5127_p2.read()) + sc_biguint<18>(add_ln703_185_fu_5139_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_187_fu_5151_p2() {
    add_ln703_187_fu_5151_p2 = (!trunc_ln708_190_fu_5007_p4.read().is_01() || !trunc_ln708_189_fu_4998_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_190_fu_5007_p4.read()) + sc_biguint<18>(trunc_ln708_189_fu_4998_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_188_fu_5157_p2() {
    add_ln703_188_fu_5157_p2 = (!trunc_ln708_193_fu_5034_p4.read().is_01() || !trunc_ln708_192_fu_5025_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_193_fu_5034_p4.read()) + sc_biguint<18>(trunc_ln708_192_fu_5025_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_189_fu_5163_p2() {
    add_ln703_189_fu_5163_p2 = (!trunc_ln708_191_fu_5016_p4.read().is_01() || !add_ln703_188_fu_5157_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_191_fu_5016_p4.read()) + sc_biguint<18>(add_ln703_188_fu_5157_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_190_fu_25604_p2() {
    add_ln703_190_fu_25604_p2 = (!add_ln703_187_reg_35351.read().is_01() || !add_ln703_189_reg_35356.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_187_reg_35351.read()) + sc_biguint<18>(add_ln703_189_reg_35356.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_191_fu_25608_p2() {
    add_ln703_191_fu_25608_p2 = (!add_ln703_186_reg_35346.read().is_01() || !add_ln703_190_fu_25604_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_186_reg_35346.read()) + sc_biguint<18>(add_ln703_190_fu_25604_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_192_fu_5169_p2() {
    add_ln703_192_fu_5169_p2 = (!trunc_ln708_196_fu_5095_p4.read().is_01() || !trunc_ln708_195_fu_5052_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_196_fu_5095_p4.read()) + sc_biguint<18>(trunc_ln708_195_fu_5052_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_193_fu_5175_p2() {
    add_ln703_193_fu_5175_p2 = (!sext_ln708_42_fu_4874_p1.read().is_01() || !sext_ln708_41_fu_4852_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_42_fu_4874_p1.read()) + sc_bigint<18>(sext_ln708_41_fu_4852_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_194_fu_5181_p2() {
    add_ln703_194_fu_5181_p2 = (!trunc_ln708_198_fu_5118_p4.read().is_01() || !add_ln703_193_fu_5175_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_198_fu_5118_p4.read()) + sc_biguint<18>(add_ln703_193_fu_5175_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_195_fu_5187_p2() {
    add_ln703_195_fu_5187_p2 = (!add_ln703_192_fu_5169_p2.read().is_01() || !add_ln703_194_fu_5181_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_192_fu_5169_p2.read()) + sc_biguint<18>(add_ln703_194_fu_5181_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_196_fu_5193_p2() {
    add_ln703_196_fu_5193_p2 = (!sext_ln708_46_fu_5114_p1.read().is_01() || !sext_ln708_44_fu_4985_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_46_fu_5114_p1.read()) + sc_bigint<18>(sext_ln708_44_fu_4985_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_197_fu_5199_p2() {
    add_ln703_197_fu_5199_p2 = (!sext_ln708_43_fu_4935_p1.read().is_01() || !add_ln703_196_fu_5193_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_43_fu_4935_p1.read()) + sc_biguint<18>(add_ln703_196_fu_5193_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_198_fu_25613_p2() {
    add_ln703_198_fu_25613_p2 = (!sext_ln1118_212_fu_25601_p1.read().is_01() || !ap_const_lv17_1FF88.is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_212_fu_25601_p1.read()) + sc_bigint<17>(ap_const_lv17_1FF88));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_199_fu_25623_p2() {
    add_ln703_199_fu_25623_p2 = (!sext_ln708_45_fu_25598_p1.read().is_01() || !sext_ln703_61_fu_25619_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_45_fu_25598_p1.read()) + sc_bigint<18>(sext_ln703_61_fu_25619_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_200_fu_25629_p2() {
    add_ln703_200_fu_25629_p2 = (!add_ln703_197_reg_35366.read().is_01() || !add_ln703_199_fu_25623_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_197_reg_35366.read()) + sc_biguint<18>(add_ln703_199_fu_25623_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_201_fu_25634_p2() {
    add_ln703_201_fu_25634_p2 = (!add_ln703_195_reg_35361.read().is_01() || !add_ln703_200_fu_25629_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_195_reg_35361.read()) + sc_biguint<18>(add_ln703_200_fu_25629_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_203_fu_5605_p2() {
    add_ln703_203_fu_5605_p2 = (!trunc_ln708_214_fu_5453_p4.read().is_01() || !trunc_ln708_213_fu_5444_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_214_fu_5453_p4.read()) + sc_biguint<18>(trunc_ln708_213_fu_5444_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_204_fu_5611_p2() {
    add_ln703_204_fu_5611_p2 = (!sext_ln708_51_fu_5299_p1.read().is_01() || !sext_ln708_50_fu_5286_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_51_fu_5299_p1.read()) + sc_bigint<18>(sext_ln708_50_fu_5286_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_205_fu_5617_p2() {
    add_ln703_205_fu_5617_p2 = (!sext_ln708_47_fu_5214_p1.read().is_01() || !add_ln703_204_fu_5611_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_47_fu_5214_p1.read()) + sc_biguint<18>(add_ln703_204_fu_5611_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_206_fu_5623_p2() {
    add_ln703_206_fu_5623_p2 = (!add_ln703_203_fu_5605_p2.read().is_01() || !add_ln703_205_fu_5617_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_203_fu_5605_p2.read()) + sc_biguint<18>(add_ln703_205_fu_5617_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_207_fu_5629_p2() {
    add_ln703_207_fu_5629_p2 = (!sext_ln708_48_fu_5227_p1.read().is_01() || !sext_ln708_52_fu_5351_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_48_fu_5227_p1.read()) + sc_bigint<18>(sext_ln708_52_fu_5351_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_208_fu_5635_p2() {
    add_ln703_208_fu_5635_p2 = (!sext_ln1118_218_fu_5312_p1.read().is_01() || !sext_ln1118_217_fu_5266_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_218_fu_5312_p1.read()) + sc_bigint<17>(sext_ln1118_217_fu_5266_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_209_fu_5645_p2() {
    add_ln703_209_fu_5645_p2 = (!sext_ln708_49_fu_5240_p1.read().is_01() || !sext_ln703_63_fu_5641_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_49_fu_5240_p1.read()) + sc_bigint<18>(sext_ln703_63_fu_5641_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_210_fu_25645_p2() {
    add_ln703_210_fu_25645_p2 = (!add_ln703_207_reg_35376.read().is_01() || !add_ln703_209_reg_35381.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_207_reg_35376.read()) + sc_biguint<18>(add_ln703_209_reg_35381.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_211_fu_25649_p2() {
    add_ln703_211_fu_25649_p2 = (!add_ln703_206_reg_35371.read().is_01() || !add_ln703_210_fu_25645_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_206_reg_35371.read()) + sc_biguint<18>(add_ln703_210_fu_25645_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_212_fu_5651_p2() {
    add_ln703_212_fu_5651_p2 = (!sext_ln1118_233_fu_5544_p1.read().is_01() || !sext_ln1118_228_fu_5440_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_233_fu_5544_p1.read()) + sc_bigint<17>(sext_ln1118_228_fu_5440_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_213_fu_5657_p2() {
    add_ln703_213_fu_5657_p2 = (!sext_ln1118_219_fu_5325_p1.read().is_01() || !sext_ln1118_216_fu_5253_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_219_fu_5325_p1.read()) + sc_bigint<16>(sext_ln1118_216_fu_5253_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_214_fu_5667_p2() {
    add_ln703_214_fu_5667_p2 = (!sext_ln703_62_fu_5601_p1.read().is_01() || !sext_ln703_65_fu_5663_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_62_fu_5601_p1.read()) + sc_bigint<17>(sext_ln703_65_fu_5663_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_215_fu_25660_p2() {
    add_ln703_215_fu_25660_p2 = (!sext_ln703_64_fu_25654_p1.read().is_01() || !sext_ln703_66_fu_25657_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_64_fu_25654_p1.read()) + sc_bigint<18>(sext_ln703_66_fu_25657_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_216_fu_5673_p2() {
    add_ln703_216_fu_5673_p2 = (!sext_ln1118_229_fu_5490_p1.read().is_01() || !sext_ln1118_220_fu_5338_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_229_fu_5490_p1.read()) + sc_bigint<15>(sext_ln1118_220_fu_5338_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_217_fu_5683_p2() {
    add_ln703_217_fu_5683_p2 = (!sext_ln1118_226_fu_5407_p1.read().is_01() || !sext_ln703_67_fu_5679_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_226_fu_5407_p1.read()) + sc_bigint<16>(sext_ln703_67_fu_5679_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_218_fu_5689_p2() {
    add_ln703_218_fu_5689_p2 = (!sext_ln1118_227_fu_5427_p1.read().is_01() || !ap_const_lv12_ECE.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_227_fu_5427_p1.read()) + sc_bigint<12>(ap_const_lv12_ECE));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_219_fu_5699_p2() {
    add_ln703_219_fu_5699_p2 = (!sext_ln1118_238_fu_5588_p1.read().is_01() || !sext_ln703_68_fu_5695_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_238_fu_5588_p1.read()) + sc_bigint<13>(sext_ln703_68_fu_5695_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_220_fu_5709_p2() {
    add_ln703_220_fu_5709_p2 = (!add_ln703_217_fu_5683_p2.read().is_01() || !sext_ln703_69_fu_5705_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_217_fu_5683_p2.read()) + sc_bigint<16>(sext_ln703_69_fu_5705_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_221_fu_25669_p2() {
    add_ln703_221_fu_25669_p2 = (!add_ln703_215_fu_25660_p2.read().is_01() || !sext_ln703_70_fu_25666_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_215_fu_25660_p2.read()) + sc_bigint<18>(sext_ln703_70_fu_25666_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_223_fu_6053_p2() {
    add_ln703_223_fu_6053_p2 = (!trunc_ln708_221_fu_5756_p4.read().is_01() || !trunc_ln708_219_fu_5733_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_221_fu_5756_p4.read()) + sc_biguint<18>(trunc_ln708_219_fu_5733_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_224_fu_6059_p2() {
    add_ln703_224_fu_6059_p2 = (!trunc_ln708_225_fu_5796_p4.read().is_01() || !trunc_ln708_223_fu_5774_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_225_fu_5796_p4.read()) + sc_biguint<18>(trunc_ln708_223_fu_5774_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_225_fu_6065_p2() {
    add_ln703_225_fu_6065_p2 = (!trunc_ln708_222_fu_5765_p4.read().is_01() || !add_ln703_224_fu_6059_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_222_fu_5765_p4.read()) + sc_biguint<18>(add_ln703_224_fu_6059_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_226_fu_6071_p2() {
    add_ln703_226_fu_6071_p2 = (!add_ln703_223_fu_6053_p2.read().is_01() || !add_ln703_225_fu_6065_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_223_fu_6053_p2.read()) + sc_biguint<18>(add_ln703_225_fu_6065_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_227_fu_6077_p2() {
    add_ln703_227_fu_6077_p2 = (!trunc_ln708_229_fu_5840_p4.read().is_01() || !trunc_ln708_228_fu_5831_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_229_fu_5840_p4.read()) + sc_biguint<18>(trunc_ln708_228_fu_5831_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_228_fu_6083_p2() {
    add_ln703_228_fu_6083_p2 = (!trunc_ln708_235_fu_5966_p4.read().is_01() || !trunc_ln708_234_fu_5957_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_235_fu_5966_p4.read()) + sc_biguint<18>(trunc_ln708_234_fu_5957_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_229_fu_6089_p2() {
    add_ln703_229_fu_6089_p2 = (!trunc_ln708_230_fu_5849_p4.read().is_01() || !add_ln703_228_fu_6083_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_230_fu_5849_p4.read()) + sc_biguint<18>(add_ln703_228_fu_6083_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_230_fu_25681_p2() {
    add_ln703_230_fu_25681_p2 = (!add_ln703_227_reg_35406.read().is_01() || !add_ln703_229_reg_35411.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_227_reg_35406.read()) + sc_biguint<18>(add_ln703_229_reg_35411.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_231_fu_25685_p2() {
    add_ln703_231_fu_25685_p2 = (!add_ln703_226_reg_35401.read().is_01() || !add_ln703_230_fu_25681_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_226_reg_35401.read()) + sc_biguint<18>(add_ln703_230_fu_25681_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_232_fu_6095_p2() {
    add_ln703_232_fu_6095_p2 = (!sext_ln708_54_fu_5792_p1.read().is_01() || !sext_ln708_53_fu_5752_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_54_fu_5792_p1.read()) + sc_bigint<18>(sext_ln708_53_fu_5752_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_233_fu_6101_p2() {
    add_ln703_233_fu_6101_p2 = (!sext_ln708_55_fu_5827_p1.read().is_01() || !sext_ln708_58_fu_6036_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_55_fu_5827_p1.read()) + sc_bigint<18>(sext_ln708_58_fu_6036_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_234_fu_6107_p2() {
    add_ln703_234_fu_6107_p2 = (!sext_ln708_57_fu_6023_p1.read().is_01() || !add_ln703_233_fu_6101_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_57_fu_6023_p1.read()) + sc_biguint<18>(add_ln703_233_fu_6101_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_235_fu_6113_p2() {
    add_ln703_235_fu_6113_p2 = (!add_ln703_232_fu_6095_p2.read().is_01() || !add_ln703_234_fu_6107_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_232_fu_6095_p2.read()) + sc_biguint<18>(add_ln703_234_fu_6107_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_236_fu_6119_p2() {
    add_ln703_236_fu_6119_p2 = (!sext_ln1118_241_fu_5867_p1.read().is_01() || !sext_ln703_71_fu_6049_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_241_fu_5867_p1.read()) + sc_bigint<17>(sext_ln703_71_fu_6049_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_237_fu_6129_p2() {
    add_ln703_237_fu_6129_p2 = (!sext_ln708_56_fu_5899_p1.read().is_01() || !sext_ln703_72_fu_6125_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_56_fu_5899_p1.read()) + sc_bigint<18>(sext_ln703_72_fu_6125_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_238_fu_6135_p2() {
    add_ln703_238_fu_6135_p2 = (!sext_ln1118_246_fu_5953_p1.read().is_01() || !ap_const_lv15_99.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_246_fu_5953_p1.read()) + sc_biguint<15>(ap_const_lv15_99));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_239_fu_6145_p2() {
    add_ln703_239_fu_6145_p2 = (!sext_ln1118_240_fu_5814_p1.read().is_01() || !sext_ln703_73_fu_6141_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_240_fu_5814_p1.read()) + sc_bigint<16>(sext_ln703_73_fu_6141_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_240_fu_6155_p2() {
    add_ln703_240_fu_6155_p2 = (!add_ln703_237_fu_6129_p2.read().is_01() || !sext_ln703_74_fu_6151_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_237_fu_6129_p2.read()) + sc_bigint<18>(sext_ln703_74_fu_6151_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_241_fu_25690_p2() {
    add_ln703_241_fu_25690_p2 = (!add_ln703_235_reg_35416.read().is_01() || !add_ln703_240_reg_35421.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_235_reg_35416.read()) + sc_biguint<18>(add_ln703_240_reg_35421.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_243_fu_6388_p2() {
    add_ln703_243_fu_6388_p2 = (!trunc_ln708_241_fu_6183_p4.read().is_01() || !trunc_ln708_239_fu_6161_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_241_fu_6183_p4.read()) + sc_biguint<18>(trunc_ln708_239_fu_6161_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_244_fu_6394_p2() {
    add_ln703_244_fu_6394_p2 = (!trunc_ln708_245_fu_6223_p4.read().is_01() || !trunc_ln708_244_fu_6214_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_245_fu_6223_p4.read()) + sc_biguint<18>(trunc_ln708_244_fu_6214_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_245_fu_6400_p2() {
    add_ln703_245_fu_6400_p2 = (!trunc_ln708_243_fu_6205_p4.read().is_01() || !add_ln703_244_fu_6394_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_243_fu_6205_p4.read()) + sc_biguint<18>(add_ln703_244_fu_6394_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_246_fu_6406_p2() {
    add_ln703_246_fu_6406_p2 = (!add_ln703_243_fu_6388_p2.read().is_01() || !add_ln703_245_fu_6400_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_243_fu_6388_p2.read()) + sc_biguint<18>(add_ln703_245_fu_6400_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_247_fu_6412_p2() {
    add_ln703_247_fu_6412_p2 = (!trunc_ln708_248_fu_6254_p4.read().is_01() || !trunc_ln708_247_fu_6245_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_248_fu_6254_p4.read()) + sc_biguint<18>(trunc_ln708_247_fu_6245_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_248_fu_6418_p2() {
    add_ln703_248_fu_6418_p2 = (!trunc_ln708_253_fu_6326_p4.read().is_01() || !trunc_ln708_252_fu_6317_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_253_fu_6326_p4.read()) + sc_biguint<18>(trunc_ln708_252_fu_6317_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_249_fu_6424_p2() {
    add_ln703_249_fu_6424_p2 = (!trunc_ln708_249_fu_6263_p4.read().is_01() || !add_ln703_248_fu_6418_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_249_fu_6263_p4.read()) + sc_biguint<18>(add_ln703_248_fu_6418_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_250_fu_25700_p2() {
    add_ln703_250_fu_25700_p2 = (!add_ln703_247_reg_35431.read().is_01() || !add_ln703_249_reg_35436.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_247_reg_35431.read()) + sc_biguint<18>(add_ln703_249_reg_35436.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_251_fu_25704_p2() {
    add_ln703_251_fu_25704_p2 = (!add_ln703_246_reg_35426.read().is_01() || !add_ln703_250_fu_25700_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_246_reg_35426.read()) + sc_biguint<18>(add_ln703_250_fu_25700_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_252_fu_6430_p2() {
    add_ln703_252_fu_6430_p2 = (!trunc_ln708_255_fu_6344_p4.read().is_01() || !trunc_ln708_254_fu_6335_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_255_fu_6344_p4.read()) + sc_biguint<18>(trunc_ln708_254_fu_6335_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_253_fu_6436_p2() {
    add_ln703_253_fu_6436_p2 = (!sext_ln708_60_fu_6201_p1.read().is_01() || !sext_ln708_59_fu_6179_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_60_fu_6201_p1.read()) + sc_bigint<18>(sext_ln708_59_fu_6179_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_254_fu_6442_p2() {
    add_ln703_254_fu_6442_p2 = (!trunc_ln708_256_fu_6353_p4.read().is_01() || !add_ln703_253_fu_6436_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_256_fu_6353_p4.read()) + sc_biguint<18>(add_ln703_253_fu_6436_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_255_fu_6448_p2() {
    add_ln703_255_fu_6448_p2 = (!add_ln703_252_fu_6430_p2.read().is_01() || !add_ln703_254_fu_6442_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_252_fu_6430_p2.read()) + sc_biguint<18>(add_ln703_254_fu_6442_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_256_fu_6454_p2() {
    add_ln703_256_fu_6454_p2 = (!sext_ln708_63_fu_6384_p1.read().is_01() || !sext_ln708_62_fu_6371_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_63_fu_6384_p1.read()) + sc_bigint<18>(sext_ln708_62_fu_6371_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_257_fu_6460_p2() {
    add_ln703_257_fu_6460_p2 = (!sext_ln708_61_fu_6241_p1.read().is_01() || !add_ln703_256_fu_6454_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_61_fu_6241_p1.read()) + sc_biguint<18>(add_ln703_256_fu_6454_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_258_fu_6466_p2() {
    add_ln703_258_fu_6466_p2 = (!sext_ln1118_253_fu_6313_p1.read().is_01() || !ap_const_lv16_FFB5.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_253_fu_6313_p1.read()) + sc_bigint<16>(ap_const_lv16_FFB5));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_259_fu_6476_p2() {
    add_ln703_259_fu_6476_p2 = (!sext_ln1118_251_fu_6281_p1.read().is_01() || !sext_ln703_75_fu_6472_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_251_fu_6281_p1.read()) + sc_bigint<17>(sext_ln703_75_fu_6472_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_260_fu_6486_p2() {
    add_ln703_260_fu_6486_p2 = (!add_ln703_257_fu_6460_p2.read().is_01() || !sext_ln703_76_fu_6482_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_257_fu_6460_p2.read()) + sc_bigint<18>(sext_ln703_76_fu_6482_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_261_fu_25709_p2() {
    add_ln703_261_fu_25709_p2 = (!add_ln703_255_reg_35441.read().is_01() || !add_ln703_260_reg_35446.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_255_reg_35441.read()) + sc_biguint<18>(add_ln703_260_reg_35446.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_263_fu_6785_p2() {
    add_ln703_263_fu_6785_p2 = (!trunc_ln708_261_fu_6514_p4.read().is_01() || !trunc_ln708_260_fu_6505_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_261_fu_6514_p4.read()) + sc_biguint<18>(trunc_ln708_260_fu_6505_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_264_fu_6791_p2() {
    add_ln703_264_fu_6791_p2 = (!trunc_ln708_267_fu_6611_p4.read().is_01() || !trunc_ln708_263_fu_6532_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_267_fu_6611_p4.read()) + sc_biguint<18>(trunc_ln708_263_fu_6532_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_265_fu_6797_p2() {
    add_ln703_265_fu_6797_p2 = (!trunc_ln708_262_fu_6523_p4.read().is_01() || !add_ln703_264_fu_6791_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_262_fu_6523_p4.read()) + sc_biguint<18>(add_ln703_264_fu_6791_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_266_fu_6803_p2() {
    add_ln703_266_fu_6803_p2 = (!add_ln703_263_fu_6785_p2.read().is_01() || !add_ln703_265_fu_6797_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_263_fu_6785_p2.read()) + sc_biguint<18>(add_ln703_265_fu_6797_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_267_fu_6809_p2() {
    add_ln703_267_fu_6809_p2 = (!trunc_ln708_270_fu_6660_p4.read().is_01() || !trunc_ln708_268_fu_6620_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_270_fu_6660_p4.read()) + sc_biguint<18>(trunc_ln708_268_fu_6620_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_268_fu_6815_p2() {
    add_ln703_268_fu_6815_p2 = (!trunc_ln708_273_fu_6688_p4.read().is_01() || !trunc_ln708_272_fu_6679_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_273_fu_6688_p4.read()) + sc_biguint<18>(trunc_ln708_272_fu_6679_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_269_fu_6821_p2() {
    add_ln703_269_fu_6821_p2 = (!trunc_ln708_271_fu_6670_p4.read().is_01() || !add_ln703_268_fu_6815_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_271_fu_6670_p4.read()) + sc_biguint<18>(add_ln703_268_fu_6815_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_270_fu_25722_p2() {
    add_ln703_270_fu_25722_p2 = (!add_ln703_267_reg_35461.read().is_01() || !add_ln703_269_reg_35466.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_267_reg_35461.read()) + sc_biguint<18>(add_ln703_269_reg_35466.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_271_fu_25726_p2() {
    add_ln703_271_fu_25726_p2 = (!add_ln703_266_reg_35456.read().is_01() || !add_ln703_270_fu_25722_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_266_reg_35456.read()) + sc_biguint<18>(add_ln703_270_fu_25722_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_272_fu_6827_p2() {
    add_ln703_272_fu_6827_p2 = (!trunc_ln708_275_fu_6706_p4.read().is_01() || !trunc_ln708_274_fu_6697_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_275_fu_6706_p4.read()) + sc_biguint<18>(trunc_ln708_274_fu_6697_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_273_fu_6833_p2() {
    add_ln703_273_fu_6833_p2 = (!sext_ln708_64_fu_6501_p1.read().is_01() || !trunc_ln708_278_fu_6775_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_64_fu_6501_p1.read()) + sc_biguint<18>(trunc_ln708_278_fu_6775_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_274_fu_6839_p2() {
    add_ln703_274_fu_6839_p2 = (!trunc_ln708_277_fu_6728_p4.read().is_01() || !add_ln703_273_fu_6833_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_277_fu_6728_p4.read()) + sc_biguint<18>(add_ln703_273_fu_6833_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_275_fu_6845_p2() {
    add_ln703_275_fu_6845_p2 = (!add_ln703_272_fu_6827_p2.read().is_01() || !add_ln703_274_fu_6839_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_272_fu_6827_p2.read()) + sc_biguint<18>(add_ln703_274_fu_6839_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_276_fu_6851_p2() {
    add_ln703_276_fu_6851_p2 = (!sext_ln708_67_fu_6724_p1.read().is_01() || !sext_ln708_66_fu_6559_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_67_fu_6724_p1.read()) + sc_bigint<18>(sext_ln708_66_fu_6559_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_277_fu_25731_p2() {
    add_ln703_277_fu_25731_p2 = (!sext_ln708_65_fu_25719_p1.read().is_01() || !add_ln703_276_reg_35476.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_65_fu_25719_p1.read()) + sc_biguint<18>(add_ln703_276_reg_35476.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_278_fu_6857_p2() {
    add_ln703_278_fu_6857_p2 = (!sext_ln1118_258_fu_6638_p1.read().is_01() || !ap_const_lv16_18.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_258_fu_6638_p1.read()) + sc_biguint<16>(ap_const_lv16_18));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_279_fu_6867_p2() {
    add_ln703_279_fu_6867_p2 = (!sext_ln1118_257_fu_6607_p1.read().is_01() || !sext_ln703_77_fu_6863_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_257_fu_6607_p1.read()) + sc_bigint<17>(sext_ln703_77_fu_6863_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_280_fu_25739_p2() {
    add_ln703_280_fu_25739_p2 = (!add_ln703_277_fu_25731_p2.read().is_01() || !sext_ln703_78_fu_25736_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_277_fu_25731_p2.read()) + sc_bigint<18>(sext_ln703_78_fu_25736_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_281_fu_25745_p2() {
    add_ln703_281_fu_25745_p2 = (!add_ln703_275_reg_35471.read().is_01() || !add_ln703_280_fu_25739_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_275_reg_35471.read()) + sc_biguint<18>(add_ln703_280_fu_25739_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_283_fu_7336_p2() {
    add_ln703_283_fu_7336_p2 = (!trunc_ln708_281_fu_6965_p4.read().is_01() || !trunc_ln708_280_fu_6955_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_281_fu_6965_p4.read()) + sc_biguint<18>(trunc_ln708_280_fu_6955_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_284_fu_7342_p2() {
    add_ln703_284_fu_7342_p2 = (!trunc_ln708_289_fu_7166_p4.read().is_01() || !trunc_ln708_283_fu_6983_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_289_fu_7166_p4.read()) + sc_biguint<18>(trunc_ln708_283_fu_6983_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_285_fu_7348_p2() {
    add_ln703_285_fu_7348_p2 = (!trunc_ln708_282_fu_6974_p4.read().is_01() || !add_ln703_284_fu_7342_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_282_fu_6974_p4.read()) + sc_biguint<18>(add_ln703_284_fu_7342_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_286_fu_7354_p2() {
    add_ln703_286_fu_7354_p2 = (!add_ln703_283_fu_7336_p2.read().is_01() || !add_ln703_285_fu_7348_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_283_fu_7336_p2.read()) + sc_biguint<18>(add_ln703_285_fu_7348_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_287_fu_7360_p2() {
    add_ln703_287_fu_7360_p2 = (!trunc_ln708_294_fu_7292_p4.read().is_01() || !trunc_ln708_293_fu_7283_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_294_fu_7292_p4.read()) + sc_biguint<18>(trunc_ln708_293_fu_7283_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_288_fu_7366_p2() {
    add_ln703_288_fu_7366_p2 = (!sext_ln708_70_fu_7098_p1.read().is_01() || !sext_ln708_69_fu_7045_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_70_fu_7098_p1.read()) + sc_bigint<18>(sext_ln708_69_fu_7045_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_289_fu_7372_p2() {
    add_ln703_289_fu_7372_p2 = (!trunc_ln708_296_fu_7314_p4.read().is_01() || !add_ln703_288_fu_7366_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_296_fu_7314_p4.read()) + sc_biguint<18>(add_ln703_288_fu_7366_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_290_fu_25756_p2() {
    add_ln703_290_fu_25756_p2 = (!add_ln703_287_reg_35491.read().is_01() || !add_ln703_289_reg_35496.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_287_reg_35491.read()) + sc_biguint<18>(add_ln703_289_reg_35496.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_291_fu_25760_p2() {
    add_ln703_291_fu_25760_p2 = (!add_ln703_286_reg_35486.read().is_01() || !add_ln703_290_fu_25756_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_286_reg_35486.read()) + sc_biguint<18>(add_ln703_290_fu_25756_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_292_fu_7378_p2() {
    add_ln703_292_fu_7378_p2 = (!sext_ln708_72_fu_7223_p1.read().is_01() || !sext_ln708_71_fu_7185_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_72_fu_7223_p1.read()) + sc_bigint<18>(sext_ln708_71_fu_7185_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_293_fu_7384_p2() {
    add_ln703_293_fu_7384_p2 = (!sext_ln708_68_fu_7001_p1.read().is_01() || !sext_ln708_74_fu_7310_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_68_fu_7001_p1.read()) + sc_bigint<18>(sext_ln708_74_fu_7310_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_294_fu_7390_p2() {
    add_ln703_294_fu_7390_p2 = (!sext_ln708_73_fu_7279_p1.read().is_01() || !add_ln703_293_fu_7384_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_73_fu_7279_p1.read()) + sc_biguint<18>(add_ln703_293_fu_7384_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_295_fu_7396_p2() {
    add_ln703_295_fu_7396_p2 = (!add_ln703_292_fu_7378_p2.read().is_01() || !add_ln703_294_fu_7390_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_292_fu_7378_p2.read()) + sc_biguint<18>(add_ln703_294_fu_7390_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_296_fu_7402_p2() {
    add_ln703_296_fu_7402_p2 = (!sext_ln703_79_fu_7332_p1.read().is_01() || !sext_ln1118_281_fu_7142_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_79_fu_7332_p1.read()) + sc_bigint<17>(sext_ln1118_281_fu_7142_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_297_fu_7412_p2() {
    add_ln703_297_fu_7412_p2 = (!sext_ln1118_278_fu_7085_p1.read().is_01() || !ap_const_lv12_98.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_278_fu_7085_p1.read()) + sc_biguint<12>(ap_const_lv12_98));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_298_fu_7422_p2() {
    add_ln703_298_fu_7422_p2 = (!sext_ln1118_268_fu_6913_p1.read().is_01() || !sext_ln703_81_fu_7418_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_268_fu_6913_p1.read()) + sc_bigint<14>(sext_ln703_81_fu_7418_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_299_fu_7432_p2() {
    add_ln703_299_fu_7432_p2 = (!sext_ln703_80_fu_7408_p1.read().is_01() || !sext_ln703_82_fu_7428_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_80_fu_7408_p1.read()) + sc_bigint<18>(sext_ln703_82_fu_7428_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_300_fu_25765_p2() {
    add_ln703_300_fu_25765_p2 = (!add_ln703_295_reg_35501.read().is_01() || !add_ln703_299_reg_35506.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_295_reg_35501.read()) + sc_biguint<18>(add_ln703_299_reg_35506.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_302_fu_7674_p2() {
    add_ln703_302_fu_7674_p2 = (!trunc_ln708_301_fu_7480_p4.read().is_01() || !trunc_ln708_300_fu_7471_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_301_fu_7480_p4.read()) + sc_biguint<18>(trunc_ln708_300_fu_7471_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_303_fu_7680_p2() {
    add_ln703_303_fu_7680_p2 = (!trunc_ln708_306_fu_7533_p4.read().is_01() || !trunc_ln708_305_fu_7524_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_306_fu_7533_p4.read()) + sc_biguint<18>(trunc_ln708_305_fu_7524_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_304_fu_7686_p2() {
    add_ln703_304_fu_7686_p2 = (!trunc_ln708_302_fu_7489_p4.read().is_01() || !add_ln703_303_fu_7680_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_302_fu_7489_p4.read()) + sc_biguint<18>(add_ln703_303_fu_7680_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_305_fu_7692_p2() {
    add_ln703_305_fu_7692_p2 = (!add_ln703_302_fu_7674_p2.read().is_01() || !add_ln703_304_fu_7686_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_302_fu_7674_p2.read()) + sc_biguint<18>(add_ln703_304_fu_7686_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_306_fu_7698_p2() {
    add_ln703_306_fu_7698_p2 = (!trunc_ln708_313_fu_7616_p4.read().is_01() || !trunc_ln708_309_fu_7568_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_313_fu_7616_p4.read()) + sc_biguint<18>(trunc_ln708_309_fu_7568_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_307_fu_7704_p2() {
    add_ln703_307_fu_7704_p2 = (!sext_ln708_77_fu_7586_p1.read().is_01() || !sext_ln708_76_fu_7551_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_77_fu_7586_p1.read()) + sc_bigint<18>(sext_ln708_76_fu_7551_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_308_fu_7710_p2() {
    add_ln703_308_fu_7710_p2 = (!trunc_ln708_315_fu_7638_p4.read().is_01() || !add_ln703_307_fu_7704_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_315_fu_7638_p4.read()) + sc_biguint<18>(add_ln703_307_fu_7704_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_309_fu_25775_p2() {
    add_ln703_309_fu_25775_p2 = (!add_ln703_306_reg_35516.read().is_01() || !add_ln703_308_reg_35521.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_306_reg_35516.read()) + sc_biguint<18>(add_ln703_308_reg_35521.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_310_fu_25779_p2() {
    add_ln703_310_fu_25779_p2 = (!add_ln703_305_reg_35511.read().is_01() || !add_ln703_309_fu_25775_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_305_reg_35511.read()) + sc_biguint<18>(add_ln703_309_fu_25775_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_311_fu_7716_p2() {
    add_ln703_311_fu_7716_p2 = (!sext_ln708_79_fu_7634_p1.read().is_01() || !sext_ln708_78_fu_7599_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_79_fu_7634_p1.read()) + sc_bigint<18>(sext_ln708_78_fu_7599_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_312_fu_7722_p2() {
    add_ln703_312_fu_7722_p2 = (!sext_ln1118_290_fu_7507_p1.read().is_01() || !sext_ln1118_288_fu_7454_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_290_fu_7507_p1.read()) + sc_bigint<17>(sext_ln1118_288_fu_7454_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_313_fu_7732_p2() {
    add_ln703_313_fu_7732_p2 = (!sext_ln708_80_fu_7656_p1.read().is_01() || !sext_ln703_84_fu_7728_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_80_fu_7656_p1.read()) + sc_bigint<18>(sext_ln703_84_fu_7728_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_314_fu_7738_p2() {
    add_ln703_314_fu_7738_p2 = (!add_ln703_311_fu_7716_p2.read().is_01() || !add_ln703_313_fu_7732_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_311_fu_7716_p2.read()) + sc_biguint<18>(add_ln703_313_fu_7732_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_315_fu_7744_p2() {
    add_ln703_315_fu_7744_p2 = (!sext_ln1118_289_fu_7467_p1.read().is_01() || !sext_ln1118_291_fu_7564_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_289_fu_7467_p1.read()) + sc_bigint<17>(sext_ln1118_291_fu_7564_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_316_fu_7754_p2() {
    add_ln703_316_fu_7754_p2 = (!sext_ln708_75_fu_7520_p1.read().is_01() || !sext_ln703_85_fu_7750_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_75_fu_7520_p1.read()) + sc_bigint<18>(sext_ln703_85_fu_7750_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_317_fu_7760_p2() {
    add_ln703_317_fu_7760_p2 = (!sext_ln703_83_fu_7670_p1.read().is_01() || !ap_const_lv16_FFEA.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_83_fu_7670_p1.read()) + sc_bigint<16>(ap_const_lv16_FFEA));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_318_fu_7770_p2() {
    add_ln703_318_fu_7770_p2 = (!sext_ln1118_292_fu_7612_p1.read().is_01() || !sext_ln703_86_fu_7766_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_292_fu_7612_p1.read()) + sc_bigint<17>(sext_ln703_86_fu_7766_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_319_fu_7780_p2() {
    add_ln703_319_fu_7780_p2 = (!add_ln703_316_fu_7754_p2.read().is_01() || !sext_ln703_87_fu_7776_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_316_fu_7754_p2.read()) + sc_bigint<18>(sext_ln703_87_fu_7776_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_320_fu_25784_p2() {
    add_ln703_320_fu_25784_p2 = (!add_ln703_314_reg_35526.read().is_01() || !add_ln703_319_reg_35531.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_314_reg_35526.read()) + sc_biguint<18>(add_ln703_319_reg_35531.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_322_fu_8067_p2() {
    add_ln703_322_fu_8067_p2 = (!trunc_ln708_320_fu_7808_p4.read().is_01() || !trunc_ln708_318_fu_7786_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_320_fu_7808_p4.read()) + sc_biguint<18>(trunc_ln708_318_fu_7786_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_323_fu_8073_p2() {
    add_ln703_323_fu_8073_p2 = (!trunc_ln708_323_fu_7835_p4.read().is_01() || !trunc_ln708_322_fu_7826_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_323_fu_7835_p4.read()) + sc_biguint<18>(trunc_ln708_322_fu_7826_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_324_fu_8079_p2() {
    add_ln703_324_fu_8079_p2 = (!trunc_ln708_321_fu_7817_p4.read().is_01() || !add_ln703_323_fu_8073_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_321_fu_7817_p4.read()) + sc_biguint<18>(add_ln703_323_fu_8073_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_325_fu_8085_p2() {
    add_ln703_325_fu_8085_p2 = (!add_ln703_322_fu_8067_p2.read().is_01() || !add_ln703_324_fu_8079_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_322_fu_8067_p2.read()) + sc_biguint<18>(add_ln703_324_fu_8079_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_326_fu_8091_p2() {
    add_ln703_326_fu_8091_p2 = (!trunc_ln708_333_fu_7964_p4.read().is_01() || !trunc_ln708_332_fu_7955_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_333_fu_7964_p4.read()) + sc_biguint<18>(trunc_ln708_332_fu_7955_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_327_fu_8097_p2() {
    add_ln703_327_fu_8097_p2 = (!sext_ln708_83_fu_7866_p1.read().is_01() || !sext_ln708_82_fu_7853_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_83_fu_7866_p1.read()) + sc_bigint<18>(sext_ln708_82_fu_7853_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_328_fu_8103_p2() {
    add_ln703_328_fu_8103_p2 = (!trunc_ln708_334_fu_8011_p4.read().is_01() || !add_ln703_327_fu_8097_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_334_fu_8011_p4.read()) + sc_biguint<18>(add_ln703_327_fu_8097_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_329_fu_25794_p2() {
    add_ln703_329_fu_25794_p2 = (!add_ln703_326_reg_35541.read().is_01() || !add_ln703_328_reg_35546.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_326_reg_35541.read()) + sc_biguint<18>(add_ln703_328_reg_35546.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_330_fu_25798_p2() {
    add_ln703_330_fu_25798_p2 = (!add_ln703_325_reg_35536.read().is_01() || !add_ln703_329_fu_25794_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_325_reg_35536.read()) + sc_biguint<18>(add_ln703_329_fu_25794_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_331_fu_8109_p2() {
    add_ln703_331_fu_8109_p2 = (!sext_ln708_85_fu_7912_p1.read().is_01() || !sext_ln708_84_fu_7879_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_85_fu_7912_p1.read()) + sc_bigint<18>(sext_ln708_84_fu_7879_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_332_fu_8115_p2() {
    add_ln703_332_fu_8115_p2 = (!sext_ln708_81_fu_7804_p1.read().is_01() || !sext_ln708_87_fu_8063_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_81_fu_7804_p1.read()) + sc_bigint<18>(sext_ln708_87_fu_8063_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_333_fu_8121_p2() {
    add_ln703_333_fu_8121_p2 = (!sext_ln708_86_fu_8030_p1.read().is_01() || !add_ln703_332_fu_8115_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_86_fu_8030_p1.read()) + sc_biguint<18>(add_ln703_332_fu_8115_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_334_fu_8127_p2() {
    add_ln703_334_fu_8127_p2 = (!add_ln703_331_fu_8109_p2.read().is_01() || !add_ln703_333_fu_8121_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_331_fu_8109_p2.read()) + sc_biguint<18>(add_ln703_333_fu_8121_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_335_fu_8133_p2() {
    add_ln703_335_fu_8133_p2 = (!sext_ln1118_295_fu_7938_p1.read().is_01() || !sext_ln1118_294_fu_7925_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_295_fu_7938_p1.read()) + sc_bigint<16>(sext_ln1118_294_fu_7925_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_336_fu_8143_p2() {
    add_ln703_336_fu_8143_p2 = (!sext_ln1118_301_fu_8043_p1.read().is_01() || !sext_ln703_88_fu_8139_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_301_fu_8043_p1.read()) + sc_bigint<17>(sext_ln703_88_fu_8139_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_337_fu_8149_p2() {
    add_ln703_337_fu_8149_p2 = (!sext_ln1118_293_fu_7899_p1.read().is_01() || !ap_const_lv13_5D.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_293_fu_7899_p1.read()) + sc_biguint<13>(ap_const_lv13_5D));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_338_fu_8159_p2() {
    add_ln703_338_fu_8159_p2 = (!sext_ln1118_296_fu_7951_p1.read().is_01() || !sext_ln703_90_fu_8155_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_296_fu_7951_p1.read()) + sc_bigint<16>(sext_ln703_90_fu_8155_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_339_fu_25809_p2() {
    add_ln703_339_fu_25809_p2 = (!sext_ln703_89_fu_25803_p1.read().is_01() || !sext_ln703_91_fu_25806_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_89_fu_25803_p1.read()) + sc_bigint<18>(sext_ln703_91_fu_25806_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_340_fu_25815_p2() {
    add_ln703_340_fu_25815_p2 = (!add_ln703_334_reg_35551.read().is_01() || !add_ln703_339_fu_25809_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_334_reg_35551.read()) + sc_biguint<18>(add_ln703_339_fu_25809_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_342_fu_8369_p2() {
    add_ln703_342_fu_8369_p2 = (!trunc_ln708_340_fu_8187_p4.read().is_01() || !trunc_ln708_339_fu_8178_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_340_fu_8187_p4.read()) + sc_biguint<18>(trunc_ln708_339_fu_8178_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_343_fu_8375_p2() {
    add_ln703_343_fu_8375_p2 = (!trunc_ln708_343_fu_8214_p4.read().is_01() || !trunc_ln708_342_fu_8205_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_343_fu_8214_p4.read()) + sc_biguint<18>(trunc_ln708_342_fu_8205_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_344_fu_8381_p2() {
    add_ln703_344_fu_8381_p2 = (!trunc_ln708_341_fu_8196_p4.read().is_01() || !add_ln703_343_fu_8375_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_341_fu_8196_p4.read()) + sc_biguint<18>(add_ln703_343_fu_8375_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_345_fu_8387_p2() {
    add_ln703_345_fu_8387_p2 = (!add_ln703_342_fu_8369_p2.read().is_01() || !add_ln703_344_fu_8381_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_342_fu_8369_p2.read()) + sc_biguint<18>(add_ln703_344_fu_8381_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_346_fu_8393_p2() {
    add_ln703_346_fu_8393_p2 = (!trunc_ln708_345_fu_8232_p4.read().is_01() || !trunc_ln708_344_fu_8223_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_345_fu_8232_p4.read()) + sc_biguint<18>(trunc_ln708_344_fu_8223_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_347_fu_8399_p2() {
    add_ln703_347_fu_8399_p2 = (!trunc_ln708_350_fu_8285_p4.read().is_01() || !trunc_ln708_348_fu_8263_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_350_fu_8285_p4.read()) + sc_biguint<18>(trunc_ln708_348_fu_8263_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_348_fu_8405_p2() {
    add_ln703_348_fu_8405_p2 = (!trunc_ln708_347_fu_8254_p4.read().is_01() || !add_ln703_347_fu_8399_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_347_fu_8254_p4.read()) + sc_biguint<18>(add_ln703_347_fu_8399_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_349_fu_25829_p2() {
    add_ln703_349_fu_25829_p2 = (!add_ln703_346_reg_35576.read().is_01() || !add_ln703_348_reg_35581.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_346_reg_35576.read()) + sc_biguint<18>(add_ln703_348_reg_35581.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_350_fu_25833_p2() {
    add_ln703_350_fu_25833_p2 = (!add_ln703_345_reg_35571.read().is_01() || !add_ln703_349_fu_25829_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_345_reg_35571.read()) + sc_biguint<18>(add_ln703_349_fu_25829_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_351_fu_8411_p2() {
    add_ln703_351_fu_8411_p2 = (!trunc_ln708_355_fu_8338_p4.read().is_01() || !trunc_ln708_354_fu_8329_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_355_fu_8338_p4.read()) + sc_biguint<18>(trunc_ln708_354_fu_8329_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_352_fu_8417_p2() {
    add_ln703_352_fu_8417_p2 = (!sext_ln708_89_fu_8281_p1.read().is_01() || !sext_ln708_88_fu_8174_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_89_fu_8281_p1.read()) + sc_bigint<18>(sext_ln708_88_fu_8174_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_353_fu_8423_p2() {
    add_ln703_353_fu_8423_p2 = (!trunc_ln708_356_fu_8347_p4.read().is_01() || !add_ln703_352_fu_8417_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_356_fu_8347_p4.read()) + sc_biguint<18>(add_ln703_352_fu_8417_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_354_fu_8429_p2() {
    add_ln703_354_fu_8429_p2 = (!add_ln703_351_fu_8411_p2.read().is_01() || !add_ln703_353_fu_8423_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_351_fu_8411_p2.read()) + sc_biguint<18>(add_ln703_353_fu_8423_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_355_fu_8435_p2() {
    add_ln703_355_fu_8435_p2 = (!sext_ln708_90_fu_8303_p1.read().is_01() || !sext_ln708_92_fu_8365_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_90_fu_8303_p1.read()) + sc_bigint<18>(sext_ln708_92_fu_8365_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_356_fu_25838_p2() {
    add_ln703_356_fu_25838_p2 = (!sext_ln708_91_fu_25826_p1.read().is_01() || !add_ln703_355_reg_35591.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_91_fu_25826_p1.read()) + sc_biguint<18>(add_ln703_355_reg_35591.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_357_fu_8441_p2() {
    add_ln703_357_fu_8441_p2 = (!sext_ln1118_303_fu_8316_p1.read().is_01() || !ap_const_lv16_16.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_303_fu_8316_p1.read()) + sc_biguint<16>(ap_const_lv16_16));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_358_fu_8451_p2() {
    add_ln703_358_fu_8451_p2 = (!sext_ln1118_302_fu_8250_p1.read().is_01() || !sext_ln703_92_fu_8447_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_302_fu_8250_p1.read()) + sc_bigint<17>(sext_ln703_92_fu_8447_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_359_fu_25846_p2() {
    add_ln703_359_fu_25846_p2 = (!add_ln703_356_fu_25838_p2.read().is_01() || !sext_ln703_93_fu_25843_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_356_fu_25838_p2.read()) + sc_bigint<18>(sext_ln703_93_fu_25843_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_360_fu_25852_p2() {
    add_ln703_360_fu_25852_p2 = (!add_ln703_354_reg_35586.read().is_01() || !add_ln703_359_fu_25846_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_354_reg_35586.read()) + sc_biguint<18>(add_ln703_359_fu_25846_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_362_fu_8679_p2() {
    add_ln703_362_fu_8679_p2 = (!trunc_ln708_360_fu_8479_p4.read().is_01() || !trunc_ln708_358_fu_8457_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_360_fu_8479_p4.read()) + sc_biguint<18>(trunc_ln708_358_fu_8457_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_363_fu_8685_p2() {
    add_ln703_363_fu_8685_p2 = (!trunc_ln708_363_fu_8506_p4.read().is_01() || !trunc_ln708_362_fu_8497_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_363_fu_8506_p4.read()) + sc_biguint<18>(trunc_ln708_362_fu_8497_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_364_fu_8691_p2() {
    add_ln703_364_fu_8691_p2 = (!trunc_ln708_361_fu_8488_p4.read().is_01() || !add_ln703_363_fu_8685_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_361_fu_8488_p4.read()) + sc_biguint<18>(add_ln703_363_fu_8685_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_365_fu_8697_p2() {
    add_ln703_365_fu_8697_p2 = (!add_ln703_362_fu_8679_p2.read().is_01() || !add_ln703_364_fu_8691_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_362_fu_8679_p2.read()) + sc_biguint<18>(add_ln703_364_fu_8691_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_366_fu_8703_p2() {
    add_ln703_366_fu_8703_p2 = (!trunc_ln708_365_fu_8524_p4.read().is_01() || !trunc_ln708_364_fu_8515_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_365_fu_8524_p4.read()) + sc_biguint<18>(trunc_ln708_364_fu_8515_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_367_fu_8709_p2() {
    add_ln703_367_fu_8709_p2 = (!trunc_ln708_371_fu_8590_p4.read().is_01() || !trunc_ln708_369_fu_8568_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_371_fu_8590_p4.read()) + sc_biguint<18>(trunc_ln708_369_fu_8568_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_368_fu_8715_p2() {
    add_ln703_368_fu_8715_p2 = (!trunc_ln708_368_fu_8559_p4.read().is_01() || !add_ln703_367_fu_8709_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_368_fu_8559_p4.read()) + sc_biguint<18>(add_ln703_367_fu_8709_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_369_fu_25863_p2() {
    add_ln703_369_fu_25863_p2 = (!add_ln703_366_reg_35606.read().is_01() || !add_ln703_368_reg_35611.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_366_reg_35606.read()) + sc_biguint<18>(add_ln703_368_reg_35611.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_370_fu_25867_p2() {
    add_ln703_370_fu_25867_p2 = (!add_ln703_365_reg_35601.read().is_01() || !add_ln703_369_fu_25863_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_365_reg_35601.read()) + sc_biguint<18>(add_ln703_369_fu_25863_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_371_fu_8721_p2() {
    add_ln703_371_fu_8721_p2 = (!trunc_ln708_373_fu_8608_p4.read().is_01() || !trunc_ln708_372_fu_8599_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_373_fu_8608_p4.read()) + sc_biguint<18>(trunc_ln708_372_fu_8599_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_372_fu_8727_p2() {
    add_ln703_372_fu_8727_p2 = (!sext_ln708_94_fu_8655_p1.read().is_01() || !sext_ln708_93_fu_8586_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_94_fu_8655_p1.read()) + sc_bigint<18>(sext_ln708_93_fu_8586_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_373_fu_8733_p2() {
    add_ln703_373_fu_8733_p2 = (!trunc_ln708_375_fu_8637_p4.read().is_01() || !add_ln703_372_fu_8727_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_375_fu_8637_p4.read()) + sc_biguint<18>(add_ln703_372_fu_8727_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_374_fu_8739_p2() {
    add_ln703_374_fu_8739_p2 = (!add_ln703_371_fu_8721_p2.read().is_01() || !add_ln703_373_fu_8733_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_371_fu_8721_p2.read()) + sc_biguint<18>(add_ln703_373_fu_8733_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_375_fu_8745_p2() {
    add_ln703_375_fu_8745_p2 = (!sext_ln1118_305_fu_8542_p1.read().is_01() || !sext_ln1118_304_fu_8475_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_305_fu_8542_p1.read()) + sc_bigint<17>(sext_ln1118_304_fu_8475_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_376_fu_8755_p2() {
    add_ln703_376_fu_8755_p2 = (!sext_ln708_95_fu_8675_p1.read().is_01() || !sext_ln703_94_fu_8751_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_95_fu_8675_p1.read()) + sc_bigint<18>(sext_ln703_94_fu_8751_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_377_fu_8761_p2() {
    add_ln703_377_fu_8761_p2 = (!sext_ln1118_307_fu_8633_p1.read().is_01() || !ap_const_lv15_AB.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_307_fu_8633_p1.read()) + sc_biguint<15>(ap_const_lv15_AB));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_378_fu_8771_p2() {
    add_ln703_378_fu_8771_p2 = (!sext_ln1118_306_fu_8555_p1.read().is_01() || !sext_ln703_95_fu_8767_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_306_fu_8555_p1.read()) + sc_bigint<17>(sext_ln703_95_fu_8767_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_379_fu_8781_p2() {
    add_ln703_379_fu_8781_p2 = (!add_ln703_376_fu_8755_p2.read().is_01() || !sext_ln703_96_fu_8777_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_376_fu_8755_p2.read()) + sc_bigint<18>(sext_ln703_96_fu_8777_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_380_fu_25872_p2() {
    add_ln703_380_fu_25872_p2 = (!add_ln703_374_reg_35616.read().is_01() || !add_ln703_379_reg_35621.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_374_reg_35616.read()) + sc_biguint<18>(add_ln703_379_reg_35621.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_382_fu_9060_p2() {
    add_ln703_382_fu_9060_p2 = (!trunc_ln708_379_fu_8796_p4.read().is_01() || !trunc_ln708_378_fu_8787_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_379_fu_8796_p4.read()) + sc_biguint<18>(trunc_ln708_378_fu_8787_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_383_fu_9066_p2() {
    add_ln703_383_fu_9066_p2 = (!trunc_ln708_384_fu_8874_p4.read().is_01() || !trunc_ln708_382_fu_8827_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_384_fu_8874_p4.read()) + sc_biguint<18>(trunc_ln708_382_fu_8827_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_384_fu_9072_p2() {
    add_ln703_384_fu_9072_p2 = (!trunc_ln708_380_fu_8805_p4.read().is_01() || !add_ln703_383_fu_9066_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_380_fu_8805_p4.read()) + sc_biguint<18>(add_ln703_383_fu_9066_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_385_fu_9078_p2() {
    add_ln703_385_fu_9078_p2 = (!add_ln703_382_fu_9060_p2.read().is_01() || !add_ln703_384_fu_9072_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_382_fu_9060_p2.read()) + sc_biguint<18>(add_ln703_384_fu_9072_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_386_fu_9084_p2() {
    add_ln703_386_fu_9084_p2 = (!trunc_ln708_386_fu_8892_p4.read().is_01() || !trunc_ln708_385_fu_8883_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_386_fu_8892_p4.read()) + sc_biguint<18>(trunc_ln708_385_fu_8883_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_387_fu_9090_p2() {
    add_ln703_387_fu_9090_p2 = (!trunc_ln708_391_fu_8978_p4.read().is_01() || !trunc_ln708_389_fu_8956_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_391_fu_8978_p4.read()) + sc_biguint<18>(trunc_ln708_389_fu_8956_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_388_fu_9096_p2() {
    add_ln703_388_fu_9096_p2 = (!trunc_ln708_388_fu_8946_p4.read().is_01() || !add_ln703_387_fu_9090_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_388_fu_8946_p4.read()) + sc_biguint<18>(add_ln703_387_fu_9090_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_389_fu_25885_p2() {
    add_ln703_389_fu_25885_p2 = (!add_ln703_386_reg_35636.read().is_01() || !add_ln703_388_reg_35641.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_386_reg_35636.read()) + sc_biguint<18>(add_ln703_388_reg_35641.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_390_fu_25889_p2() {
    add_ln703_390_fu_25889_p2 = (!add_ln703_385_reg_35631.read().is_01() || !add_ln703_389_fu_25885_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_385_reg_35631.read()) + sc_biguint<18>(add_ln703_389_fu_25885_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_391_fu_9102_p2() {
    add_ln703_391_fu_9102_p2 = (!trunc_ln708_393_fu_9011_p4.read().is_01() || !trunc_ln708_392_fu_9001_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_393_fu_9011_p4.read()) + sc_biguint<18>(trunc_ln708_392_fu_9001_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_392_fu_9108_p2() {
    add_ln703_392_fu_9108_p2 = (!trunc_ln708_397_fu_9051_p4.read().is_01() || !trunc_ln708_396_fu_9042_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_397_fu_9051_p4.read()) + sc_biguint<18>(trunc_ln708_396_fu_9042_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_393_fu_9114_p2() {
    add_ln703_393_fu_9114_p2 = (!trunc_ln708_394_fu_9020_p4.read().is_01() || !add_ln703_392_fu_9108_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_394_fu_9020_p4.read()) + sc_biguint<18>(add_ln703_392_fu_9108_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_394_fu_9120_p2() {
    add_ln703_394_fu_9120_p2 = (!add_ln703_391_fu_9102_p2.read().is_01() || !add_ln703_393_fu_9114_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_391_fu_9102_p2.read()) + sc_biguint<18>(add_ln703_393_fu_9114_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_395_fu_9126_p2() {
    add_ln703_395_fu_9126_p2 = (!sext_ln708_96_fu_8823_p1.read().is_01() || !sext_ln708_98_fu_8974_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_96_fu_8823_p1.read()) + sc_bigint<18>(sext_ln708_98_fu_8974_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_396_fu_25894_p2() {
    add_ln703_396_fu_25894_p2 = (!sext_ln708_97_fu_25882_p1.read().is_01() || !add_ln703_395_reg_35651.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_97_fu_25882_p1.read()) + sc_biguint<18>(add_ln703_395_reg_35651.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_397_fu_9132_p2() {
    add_ln703_397_fu_9132_p2 = (!sext_ln1118_310_fu_8910_p1.read().is_01() || !ap_const_lv16_1B.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_310_fu_8910_p1.read()) + sc_biguint<16>(ap_const_lv16_1B));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_398_fu_9142_p2() {
    add_ln703_398_fu_9142_p2 = (!sext_ln1118_312_fu_9038_p1.read().is_01() || !sext_ln703_97_fu_9138_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_312_fu_9038_p1.read()) + sc_bigint<17>(sext_ln703_97_fu_9138_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_399_fu_25902_p2() {
    add_ln703_399_fu_25902_p2 = (!add_ln703_396_fu_25894_p2.read().is_01() || !sext_ln703_98_fu_25899_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_396_fu_25894_p2.read()) + sc_bigint<18>(sext_ln703_98_fu_25899_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_400_fu_25908_p2() {
    add_ln703_400_fu_25908_p2 = (!add_ln703_394_reg_35646.read().is_01() || !add_ln703_399_fu_25902_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_394_reg_35646.read()) + sc_biguint<18>(add_ln703_399_fu_25902_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_402_fu_9400_p2() {
    add_ln703_402_fu_9400_p2 = (!trunc_ln708_400_fu_9170_p4.read().is_01() || !trunc_ln708_399_fu_9161_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_400_fu_9170_p4.read()) + sc_biguint<18>(trunc_ln708_399_fu_9161_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_403_fu_9406_p2() {
    add_ln703_403_fu_9406_p2 = (!trunc_ln708_403_fu_9197_p4.read().is_01() || !trunc_ln708_402_fu_9188_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_403_fu_9197_p4.read()) + sc_biguint<18>(trunc_ln708_402_fu_9188_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_404_fu_9412_p2() {
    add_ln703_404_fu_9412_p2 = (!trunc_ln708_401_fu_9179_p4.read().is_01() || !add_ln703_403_fu_9406_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_401_fu_9179_p4.read()) + sc_biguint<18>(add_ln703_403_fu_9406_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_405_fu_9418_p2() {
    add_ln703_405_fu_9418_p2 = (!add_ln703_402_fu_9400_p2.read().is_01() || !add_ln703_404_fu_9412_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_402_fu_9400_p2.read()) + sc_biguint<18>(add_ln703_404_fu_9412_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_406_fu_9424_p2() {
    add_ln703_406_fu_9424_p2 = (!trunc_ln708_405_fu_9229_p4.read().is_01() || !trunc_ln708_404_fu_9206_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_405_fu_9229_p4.read()) + sc_biguint<18>(trunc_ln708_404_fu_9206_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_407_fu_9430_p2() {
    add_ln703_407_fu_9430_p2 = (!trunc_ln708_413_fu_9347_p4.read().is_01() || !trunc_ln708_408_fu_9261_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_413_fu_9347_p4.read()) + sc_biguint<18>(trunc_ln708_408_fu_9261_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_408_fu_9436_p2() {
    add_ln703_408_fu_9436_p2 = (!trunc_ln708_407_fu_9252_p4.read().is_01() || !add_ln703_407_fu_9430_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_407_fu_9252_p4.read()) + sc_biguint<18>(add_ln703_407_fu_9430_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_409_fu_25919_p2() {
    add_ln703_409_fu_25919_p2 = (!add_ln703_406_reg_35666.read().is_01() || !add_ln703_408_reg_35671.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_406_reg_35666.read()) + sc_biguint<18>(add_ln703_408_reg_35671.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_410_fu_25923_p2() {
    add_ln703_410_fu_25923_p2 = (!add_ln703_405_reg_35661.read().is_01() || !add_ln703_409_fu_25919_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_405_reg_35661.read()) + sc_biguint<18>(add_ln703_409_fu_25919_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_411_fu_9442_p2() {
    add_ln703_411_fu_9442_p2 = (!trunc_ln708_417_fu_9391_p4.read().is_01() || !trunc_ln708_415_fu_9369_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_417_fu_9391_p4.read()) + sc_biguint<18>(trunc_ln708_415_fu_9369_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_412_fu_9448_p2() {
    add_ln703_412_fu_9448_p2 = (!sext_ln708_101_fu_9279_p1.read().is_01() || !sext_ln708_100_fu_9248_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_101_fu_9279_p1.read()) + sc_bigint<18>(sext_ln708_100_fu_9248_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_413_fu_9454_p2() {
    add_ln703_413_fu_9454_p2 = (!sext_ln708_99_fu_9157_p1.read().is_01() || !add_ln703_412_fu_9448_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_99_fu_9157_p1.read()) + sc_biguint<18>(add_ln703_412_fu_9448_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_414_fu_9460_p2() {
    add_ln703_414_fu_9460_p2 = (!add_ln703_411_fu_9442_p2.read().is_01() || !add_ln703_413_fu_9454_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_411_fu_9442_p2.read()) + sc_biguint<18>(add_ln703_413_fu_9454_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_415_fu_9466_p2() {
    add_ln703_415_fu_9466_p2 = (!sext_ln1118_317_fu_9387_p1.read().is_01() || !sext_ln1118_316_fu_9365_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_317_fu_9387_p1.read()) + sc_bigint<17>(sext_ln1118_316_fu_9365_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_416_fu_9476_p2() {
    add_ln703_416_fu_9476_p2 = (!sext_ln708_102_fu_9343_p1.read().is_01() || !sext_ln703_99_fu_9472_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_102_fu_9343_p1.read()) + sc_bigint<18>(sext_ln703_99_fu_9472_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_417_fu_9482_p2() {
    add_ln703_417_fu_9482_p2 = (!sext_ln1118_315_fu_9330_p1.read().is_01() || !ap_const_lv14_1D.is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_315_fu_9330_p1.read()) + sc_biguint<14>(ap_const_lv14_1D));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_418_fu_9492_p2() {
    add_ln703_418_fu_9492_p2 = (!sext_ln1118_313_fu_9292_p1.read().is_01() || !sext_ln703_100_fu_9488_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_313_fu_9292_p1.read()) + sc_bigint<16>(sext_ln703_100_fu_9488_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_419_fu_9502_p2() {
    add_ln703_419_fu_9502_p2 = (!add_ln703_416_fu_9476_p2.read().is_01() || !sext_ln703_101_fu_9498_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_416_fu_9476_p2.read()) + sc_bigint<18>(sext_ln703_101_fu_9498_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_420_fu_25928_p2() {
    add_ln703_420_fu_25928_p2 = (!add_ln703_414_reg_35676.read().is_01() || !add_ln703_419_reg_35681.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_414_reg_35676.read()) + sc_biguint<18>(add_ln703_419_reg_35681.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_422_fu_9772_p2() {
    add_ln703_422_fu_9772_p2 = (!trunc_ln708_422_fu_9575_p4.read().is_01() || !trunc_ln708_420_fu_9553_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_422_fu_9575_p4.read()) + sc_biguint<18>(trunc_ln708_420_fu_9553_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_423_fu_9778_p2() {
    add_ln703_423_fu_9778_p2 = (!trunc_ln708_426_fu_9615_p4.read().is_01() || !trunc_ln708_425_fu_9606_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_426_fu_9615_p4.read()) + sc_biguint<18>(trunc_ln708_425_fu_9606_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_424_fu_9784_p2() {
    add_ln703_424_fu_9784_p2 = (!trunc_ln708_424_fu_9597_p4.read().is_01() || !add_ln703_423_fu_9778_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_424_fu_9597_p4.read()) + sc_biguint<18>(add_ln703_423_fu_9778_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_425_fu_9790_p2() {
    add_ln703_425_fu_9790_p2 = (!add_ln703_422_fu_9772_p2.read().is_01() || !add_ln703_424_fu_9784_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_422_fu_9772_p2.read()) + sc_biguint<18>(add_ln703_424_fu_9784_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_426_fu_9796_p2() {
    add_ln703_426_fu_9796_p2 = (!trunc_ln708_431_fu_9697_p4.read().is_01() || !trunc_ln708_428_fu_9637_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_431_fu_9697_p4.read()) + sc_biguint<18>(trunc_ln708_428_fu_9637_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_427_fu_9802_p2() {
    add_ln703_427_fu_9802_p2 = (!trunc_ln708_436_fu_9750_p4.read().is_01() || !trunc_ln708_434_fu_9728_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_436_fu_9750_p4.read()) + sc_biguint<18>(trunc_ln708_434_fu_9728_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_428_fu_9808_p2() {
    add_ln703_428_fu_9808_p2 = (!trunc_ln708_433_fu_9719_p4.read().is_01() || !add_ln703_427_fu_9802_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_433_fu_9719_p4.read()) + sc_biguint<18>(add_ln703_427_fu_9802_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_429_fu_25938_p2() {
    add_ln703_429_fu_25938_p2 = (!add_ln703_426_reg_35691.read().is_01() || !add_ln703_428_reg_35696.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_426_reg_35691.read()) + sc_biguint<18>(add_ln703_428_reg_35696.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_430_fu_25942_p2() {
    add_ln703_430_fu_25942_p2 = (!add_ln703_425_reg_35686.read().is_01() || !add_ln703_429_fu_25938_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_425_reg_35686.read()) + sc_biguint<18>(add_ln703_429_fu_25938_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_431_fu_9814_p2() {
    add_ln703_431_fu_9814_p2 = (!sext_ln708_104_fu_9593_p1.read().is_01() || !sext_ln708_103_fu_9571_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_104_fu_9593_p1.read()) + sc_bigint<18>(sext_ln708_103_fu_9571_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_432_fu_9820_p2() {
    add_ln703_432_fu_9820_p2 = (!sext_ln708_107_fu_9746_p1.read().is_01() || !sext_ln708_106_fu_9715_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_107_fu_9746_p1.read()) + sc_bigint<18>(sext_ln708_106_fu_9715_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_433_fu_9826_p2() {
    add_ln703_433_fu_9826_p2 = (!sext_ln708_105_fu_9633_p1.read().is_01() || !add_ln703_432_fu_9820_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_105_fu_9633_p1.read()) + sc_biguint<18>(add_ln703_432_fu_9820_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_434_fu_9832_p2() {
    add_ln703_434_fu_9832_p2 = (!add_ln703_431_fu_9814_p2.read().is_01() || !add_ln703_433_fu_9826_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_431_fu_9814_p2.read()) + sc_biguint<18>(add_ln703_433_fu_9826_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_435_fu_9838_p2() {
    add_ln703_435_fu_9838_p2 = (!sext_ln1118_323_fu_9693_p1.read().is_01() || !sext_ln1118_322_fu_9680_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_323_fu_9693_p1.read()) + sc_bigint<17>(sext_ln1118_322_fu_9680_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_436_fu_9848_p2() {
    add_ln703_436_fu_9848_p2 = (!sext_ln708_108_fu_9768_p1.read().is_01() || !sext_ln703_102_fu_9844_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_108_fu_9768_p1.read()) + sc_bigint<18>(sext_ln703_102_fu_9844_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_437_fu_9854_p2() {
    add_ln703_437_fu_9854_p2 = (!sext_ln1118_319_fu_9536_p1.read().is_01() || !ap_const_lv11_2B.is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_319_fu_9536_p1.read()) + sc_biguint<11>(ap_const_lv11_2B));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_438_fu_9864_p2() {
    add_ln703_438_fu_9864_p2 = (!sext_ln1118_320_fu_9549_p1.read().is_01() || !sext_ln703_103_fu_9860_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_320_fu_9549_p1.read()) + sc_bigint<16>(sext_ln703_103_fu_9860_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_439_fu_9874_p2() {
    add_ln703_439_fu_9874_p2 = (!add_ln703_436_fu_9848_p2.read().is_01() || !sext_ln703_104_fu_9870_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_436_fu_9848_p2.read()) + sc_bigint<18>(sext_ln703_104_fu_9870_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_440_fu_25947_p2() {
    add_ln703_440_fu_25947_p2 = (!add_ln703_434_reg_35701.read().is_01() || !add_ln703_439_reg_35706.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_434_reg_35701.read()) + sc_biguint<18>(add_ln703_439_reg_35706.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_442_fu_10155_p2() {
    add_ln703_442_fu_10155_p2 = (!trunc_ln708_440_fu_9936_p4.read().is_01() || !trunc_ln708_358_fu_8457_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_440_fu_9936_p4.read()) + sc_biguint<18>(trunc_ln708_358_fu_8457_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_443_fu_10161_p2() {
    add_ln703_443_fu_10161_p2 = (!trunc_ln708_444_fu_9976_p4.read().is_01() || !trunc_ln708_442_fu_9954_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_444_fu_9976_p4.read()) + sc_biguint<18>(trunc_ln708_442_fu_9954_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_444_fu_10167_p2() {
    add_ln703_444_fu_10167_p2 = (!trunc_ln708_441_fu_9945_p4.read().is_01() || !add_ln703_443_fu_10161_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_441_fu_9945_p4.read()) + sc_biguint<18>(add_ln703_443_fu_10161_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_445_fu_10173_p2() {
    add_ln703_445_fu_10173_p2 = (!add_ln703_442_fu_10155_p2.read().is_01() || !add_ln703_444_fu_10167_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_442_fu_10155_p2.read()) + sc_biguint<18>(add_ln703_444_fu_10167_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_446_fu_10179_p2() {
    add_ln703_446_fu_10179_p2 = (!trunc_ln708_451_fu_10097_p4.read().is_01() || !trunc_ln708_445_fu_9985_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_451_fu_10097_p4.read()) + sc_biguint<18>(trunc_ln708_445_fu_9985_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_447_fu_10185_p2() {
    add_ln703_447_fu_10185_p2 = (!trunc_ln708_454_fu_10124_p4.read().is_01() || !trunc_ln708_453_fu_10115_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_454_fu_10124_p4.read()) + sc_biguint<18>(trunc_ln708_453_fu_10115_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_448_fu_10191_p2() {
    add_ln703_448_fu_10191_p2 = (!trunc_ln708_452_fu_10106_p4.read().is_01() || !add_ln703_447_fu_10185_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_452_fu_10106_p4.read()) + sc_biguint<18>(add_ln703_447_fu_10185_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_449_fu_25957_p2() {
    add_ln703_449_fu_25957_p2 = (!add_ln703_446_reg_35716.read().is_01() || !add_ln703_448_reg_35721.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_446_reg_35716.read()) + sc_biguint<18>(add_ln703_448_reg_35721.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_450_fu_25961_p2() {
    add_ln703_450_fu_25961_p2 = (!add_ln703_445_reg_35711.read().is_01() || !add_ln703_449_fu_25957_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_445_reg_35711.read()) + sc_biguint<18>(add_ln703_449_fu_25957_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_451_fu_10197_p2() {
    add_ln703_451_fu_10197_p2 = (!sext_ln708_109_fu_9932_p1.read().is_01() || !trunc_ln708_456_fu_10146_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_109_fu_9932_p1.read()) + sc_biguint<18>(trunc_ln708_456_fu_10146_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_452_fu_10203_p2() {
    add_ln703_452_fu_10203_p2 = (!sext_ln708_112_fu_10093_p1.read().is_01() || !sext_ln708_111_fu_10035_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_112_fu_10093_p1.read()) + sc_bigint<18>(sext_ln708_111_fu_10035_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_453_fu_10209_p2() {
    add_ln703_453_fu_10209_p2 = (!sext_ln708_110_fu_9972_p1.read().is_01() || !add_ln703_452_fu_10203_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_110_fu_9972_p1.read()) + sc_biguint<18>(add_ln703_452_fu_10203_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_454_fu_10215_p2() {
    add_ln703_454_fu_10215_p2 = (!add_ln703_451_fu_10197_p2.read().is_01() || !add_ln703_453_fu_10209_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_451_fu_10197_p2.read()) + sc_biguint<18>(add_ln703_453_fu_10209_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_455_fu_10221_p2() {
    add_ln703_455_fu_10221_p2 = (!sext_ln1118_331_fu_10080_p1.read().is_01() || !sext_ln1118_325_fu_9900_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_331_fu_10080_p1.read()) + sc_bigint<16>(sext_ln1118_325_fu_9900_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_456_fu_10231_p2() {
    add_ln703_456_fu_10231_p2 = (!sext_ln708_113_fu_10142_p1.read().is_01() || !sext_ln703_105_fu_10227_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_113_fu_10142_p1.read()) + sc_bigint<18>(sext_ln703_105_fu_10227_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_457_fu_10237_p2() {
    add_ln703_457_fu_10237_p2 = (!sext_ln1118_330_fu_10067_p1.read().is_01() || !ap_const_lv13_74.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_330_fu_10067_p1.read()) + sc_biguint<13>(ap_const_lv13_74));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_458_fu_10247_p2() {
    add_ln703_458_fu_10247_p2 = (!sext_ln1118_328_fu_10022_p1.read().is_01() || !sext_ln703_106_fu_10243_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_328_fu_10022_p1.read()) + sc_bigint<15>(sext_ln703_106_fu_10243_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_459_fu_10257_p2() {
    add_ln703_459_fu_10257_p2 = (!add_ln703_456_fu_10231_p2.read().is_01() || !sext_ln703_107_fu_10253_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_456_fu_10231_p2.read()) + sc_bigint<18>(sext_ln703_107_fu_10253_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_460_fu_25966_p2() {
    add_ln703_460_fu_25966_p2 = (!add_ln703_454_reg_35726.read().is_01() || !add_ln703_459_reg_35731.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_454_reg_35726.read()) + sc_biguint<18>(add_ln703_459_reg_35731.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_462_fu_10471_p2() {
    add_ln703_462_fu_10471_p2 = (!trunc_ln708_458_fu_10272_p4.read().is_01() || !trunc_ln708_457_fu_10263_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_458_fu_10272_p4.read()) + sc_biguint<18>(trunc_ln708_457_fu_10263_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_463_fu_10477_p2() {
    add_ln703_463_fu_10477_p2 = (!trunc_ln708_461_fu_10299_p4.read().is_01() || !trunc_ln708_460_fu_10290_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_461_fu_10299_p4.read()) + sc_biguint<18>(trunc_ln708_460_fu_10290_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_464_fu_10483_p2() {
    add_ln703_464_fu_10483_p2 = (!trunc_ln708_459_fu_10281_p4.read().is_01() || !add_ln703_463_fu_10477_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_459_fu_10281_p4.read()) + sc_biguint<18>(add_ln703_463_fu_10477_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_465_fu_10489_p2() {
    add_ln703_465_fu_10489_p2 = (!add_ln703_462_fu_10471_p2.read().is_01() || !add_ln703_464_fu_10483_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_462_fu_10471_p2.read()) + sc_biguint<18>(add_ln703_464_fu_10483_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_466_fu_10495_p2() {
    add_ln703_466_fu_10495_p2 = (!trunc_ln708_463_fu_10317_p4.read().is_01() || !trunc_ln708_462_fu_10308_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_463_fu_10317_p4.read()) + sc_biguint<18>(trunc_ln708_462_fu_10308_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_467_fu_10501_p2() {
    add_ln703_467_fu_10501_p2 = (!trunc_ln708_467_fu_10357_p4.read().is_01() || !trunc_ln708_466_fu_10348_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_467_fu_10357_p4.read()) + sc_biguint<18>(trunc_ln708_466_fu_10348_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_468_fu_10507_p2() {
    add_ln703_468_fu_10507_p2 = (!trunc_ln708_464_fu_10326_p4.read().is_01() || !add_ln703_467_fu_10501_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_464_fu_10326_p4.read()) + sc_biguint<18>(add_ln703_467_fu_10501_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_469_fu_25976_p2() {
    add_ln703_469_fu_25976_p2 = (!add_ln703_466_reg_35741.read().is_01() || !add_ln703_468_reg_35746.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_466_reg_35741.read()) + sc_biguint<18>(add_ln703_468_reg_35746.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_470_fu_25980_p2() {
    add_ln703_470_fu_25980_p2 = (!add_ln703_465_reg_35736.read().is_01() || !add_ln703_469_fu_25976_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_465_reg_35736.read()) + sc_biguint<18>(add_ln703_469_fu_25976_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_471_fu_10513_p2() {
    add_ln703_471_fu_10513_p2 = (!trunc_ln708_469_fu_10375_p4.read().is_01() || !trunc_ln708_468_fu_10366_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_469_fu_10375_p4.read()) + sc_biguint<18>(trunc_ln708_468_fu_10366_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_472_fu_10519_p2() {
    add_ln703_472_fu_10519_p2 = (!trunc_ln708_472_fu_10402_p4.read().is_01() || !trunc_ln708_471_fu_10393_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_472_fu_10402_p4.read()) + sc_biguint<18>(trunc_ln708_471_fu_10393_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_473_fu_10525_p2() {
    add_ln703_473_fu_10525_p2 = (!trunc_ln708_470_fu_10384_p4.read().is_01() || !add_ln703_472_fu_10519_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_470_fu_10384_p4.read()) + sc_biguint<18>(add_ln703_472_fu_10519_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_474_fu_10531_p2() {
    add_ln703_474_fu_10531_p2 = (!add_ln703_471_fu_10513_p2.read().is_01() || !add_ln703_473_fu_10525_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_471_fu_10513_p2.read()) + sc_biguint<18>(add_ln703_473_fu_10525_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_475_fu_10537_p2() {
    add_ln703_475_fu_10537_p2 = (!sext_ln708_114_fu_10458_p1.read().is_01() || !trunc_ln708_475_fu_10462_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_114_fu_10458_p1.read()) + sc_biguint<18>(trunc_ln708_475_fu_10462_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_476_fu_10543_p2() {
    add_ln703_476_fu_10543_p2 = (!trunc_ln708_473_fu_10411_p4.read().is_01() || !add_ln703_475_fu_10537_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_473_fu_10411_p4.read()) + sc_biguint<18>(add_ln703_475_fu_10537_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_477_fu_10549_p2() {
    add_ln703_477_fu_10549_p2 = (!sext_ln1118_293_fu_7899_p1.read().is_01() || !ap_const_lv13_1F80.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_293_fu_7899_p1.read()) + sc_bigint<13>(ap_const_lv13_1F80));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_478_fu_10559_p2() {
    add_ln703_478_fu_10559_p2 = (!sext_ln1118_332_fu_10344_p1.read().is_01() || !sext_ln703_108_fu_10555_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_332_fu_10344_p1.read()) + sc_bigint<17>(sext_ln703_108_fu_10555_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_479_fu_10569_p2() {
    add_ln703_479_fu_10569_p2 = (!add_ln703_476_fu_10543_p2.read().is_01() || !sext_ln703_109_fu_10565_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_476_fu_10543_p2.read()) + sc_bigint<18>(sext_ln703_109_fu_10565_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_480_fu_25985_p2() {
    add_ln703_480_fu_25985_p2 = (!add_ln703_474_reg_35751.read().is_01() || !add_ln703_479_reg_35756.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_474_reg_35751.read()) + sc_biguint<18>(add_ln703_479_reg_35756.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_482_fu_10832_p2() {
    add_ln703_482_fu_10832_p2 = (!trunc_ln708_479_fu_10629_p4.read().is_01() || !trunc_ln708_478_fu_10620_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_479_fu_10629_p4.read()) + sc_biguint<18>(trunc_ln708_478_fu_10620_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_483_fu_10838_p2() {
    add_ln703_483_fu_10838_p2 = (!trunc_ln708_485_fu_10695_p4.read().is_01() || !trunc_ln708_484_fu_10686_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_485_fu_10695_p4.read()) + sc_biguint<18>(trunc_ln708_484_fu_10686_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_484_fu_10844_p2() {
    add_ln703_484_fu_10844_p2 = (!trunc_ln708_480_fu_10638_p4.read().is_01() || !add_ln703_483_fu_10838_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_480_fu_10638_p4.read()) + sc_biguint<18>(add_ln703_483_fu_10838_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_485_fu_10850_p2() {
    add_ln703_485_fu_10850_p2 = (!add_ln703_482_fu_10832_p2.read().is_01() || !add_ln703_484_fu_10844_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_482_fu_10832_p2.read()) + sc_biguint<18>(add_ln703_484_fu_10844_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_486_fu_10856_p2() {
    add_ln703_486_fu_10856_p2 = (!trunc_ln708_488_fu_10726_p4.read().is_01() || !trunc_ln708_487_fu_10717_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_488_fu_10726_p4.read()) + sc_biguint<18>(trunc_ln708_487_fu_10717_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_487_fu_10862_p2() {
    add_ln703_487_fu_10862_p2 = (!sext_ln708_115_fu_10584_p1.read().is_01() || !trunc_ln708_494_fu_10823_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_115_fu_10584_p1.read()) + sc_biguint<18>(trunc_ln708_494_fu_10823_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_488_fu_10868_p2() {
    add_ln703_488_fu_10868_p2 = (!trunc_ln708_491_fu_10788_p4.read().is_01() || !add_ln703_487_fu_10862_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_491_fu_10788_p4.read()) + sc_biguint<18>(add_ln703_487_fu_10862_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_489_fu_25995_p2() {
    add_ln703_489_fu_25995_p2 = (!add_ln703_486_reg_35766.read().is_01() || !add_ln703_488_reg_35771.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_486_reg_35766.read()) + sc_biguint<18>(add_ln703_488_reg_35771.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_490_fu_25999_p2() {
    add_ln703_490_fu_25999_p2 = (!add_ln703_485_reg_35761.read().is_01() || !add_ln703_489_fu_25995_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_485_reg_35761.read()) + sc_biguint<18>(add_ln703_489_fu_25995_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_491_fu_10874_p2() {
    add_ln703_491_fu_10874_p2 = (!sext_ln708_118_fu_10744_p1.read().is_01() || !sext_ln708_117_fu_10656_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_118_fu_10744_p1.read()) + sc_bigint<18>(sext_ln708_117_fu_10656_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_492_fu_10880_p2() {
    add_ln703_492_fu_10880_p2 = (!sext_ln708_120_fu_10819_p1.read().is_01() || !sext_ln708_86_fu_8030_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_120_fu_10819_p1.read()) + sc_bigint<18>(sext_ln708_86_fu_8030_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_493_fu_10886_p2() {
    add_ln703_493_fu_10886_p2 = (!sext_ln708_119_fu_10806_p1.read().is_01() || !add_ln703_492_fu_10880_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_119_fu_10806_p1.read()) + sc_biguint<18>(add_ln703_492_fu_10880_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_494_fu_10892_p2() {
    add_ln703_494_fu_10892_p2 = (!add_ln703_491_fu_10874_p2.read().is_01() || !add_ln703_493_fu_10886_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_491_fu_10874_p2.read()) + sc_biguint<18>(add_ln703_493_fu_10886_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_495_fu_10898_p2() {
    add_ln703_495_fu_10898_p2 = (!sext_ln1118_338_fu_10713_p1.read().is_01() || !sext_ln1118_337_fu_10682_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_338_fu_10713_p1.read()) + sc_bigint<17>(sext_ln1118_337_fu_10682_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_496_fu_10908_p2() {
    add_ln703_496_fu_10908_p2 = (!sext_ln708_116_fu_10616_p1.read().is_01() || !sext_ln703_110_fu_10904_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_116_fu_10616_p1.read()) + sc_bigint<18>(sext_ln703_110_fu_10904_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_497_fu_10914_p2() {
    add_ln703_497_fu_10914_p2 = (!sext_ln1118_342_fu_10784_p1.read().is_01() || !ap_const_lv15_32.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_342_fu_10784_p1.read()) + sc_biguint<15>(ap_const_lv15_32));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_498_fu_10924_p2() {
    add_ln703_498_fu_10924_p2 = (!sext_ln1118_336_fu_10669_p1.read().is_01() || !sext_ln703_111_fu_10920_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_336_fu_10669_p1.read()) + sc_bigint<16>(sext_ln703_111_fu_10920_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_499_fu_10934_p2() {
    add_ln703_499_fu_10934_p2 = (!add_ln703_496_fu_10908_p2.read().is_01() || !sext_ln703_112_fu_10930_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_496_fu_10908_p2.read()) + sc_bigint<18>(sext_ln703_112_fu_10930_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_500_fu_26004_p2() {
    add_ln703_500_fu_26004_p2 = (!add_ln703_494_reg_35776.read().is_01() || !add_ln703_499_reg_35781.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_494_reg_35776.read()) + sc_biguint<18>(add_ln703_499_reg_35781.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_502_fu_10954_p2() {
    add_ln703_502_fu_10954_p2 = (!sext_ln703_fu_10950_p1.read().is_01() || !ap_const_lv12_EE2.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_fu_10950_p1.read()) + sc_bigint<12>(ap_const_lv12_EE2));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_503_fu_11216_p2() {
    add_ln703_503_fu_11216_p2 = (!trunc_ln708_500_fu_11019_p4.read().is_01() || !trunc_ln708_496_fu_10964_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_500_fu_11019_p4.read()) + sc_biguint<18>(trunc_ln708_496_fu_10964_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_504_fu_11222_p2() {
    add_ln703_504_fu_11222_p2 = (!trunc_ln708_505_fu_11095_p4.read().is_01() || !trunc_ln708_504_fu_11086_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_505_fu_11095_p4.read()) + sc_biguint<18>(trunc_ln708_504_fu_11086_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_505_fu_11228_p2() {
    add_ln703_505_fu_11228_p2 = (!trunc_ln708_503_fu_11077_p4.read().is_01() || !add_ln703_504_fu_11222_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_503_fu_11077_p4.read()) + sc_biguint<18>(add_ln703_504_fu_11222_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_506_fu_11234_p2() {
    add_ln703_506_fu_11234_p2 = (!add_ln703_503_fu_11216_p2.read().is_01() || !add_ln703_505_fu_11228_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_503_fu_11216_p2.read()) + sc_biguint<18>(add_ln703_505_fu_11228_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_507_fu_11240_p2() {
    add_ln703_507_fu_11240_p2 = (!trunc_ln708_510_fu_11171_p4.read().is_01() || !trunc_ln708_506_fu_11104_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_510_fu_11171_p4.read()) + sc_biguint<18>(trunc_ln708_506_fu_11104_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_508_fu_11246_p2() {
    add_ln703_508_fu_11246_p2 = (!trunc_ln708_513_fu_11198_p4.read().is_01() || !trunc_ln708_512_fu_11189_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_513_fu_11198_p4.read()) + sc_biguint<18>(trunc_ln708_512_fu_11189_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_509_fu_11252_p2() {
    add_ln703_509_fu_11252_p2 = (!trunc_ln708_511_fu_11180_p4.read().is_01() || !add_ln703_508_fu_11246_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_511_fu_11180_p4.read()) + sc_biguint<18>(add_ln703_508_fu_11246_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_510_fu_26014_p2() {
    add_ln703_510_fu_26014_p2 = (!add_ln703_507_reg_35791.read().is_01() || !add_ln703_509_reg_35796.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_507_reg_35791.read()) + sc_biguint<18>(add_ln703_509_reg_35796.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_511_fu_26018_p2() {
    add_ln703_511_fu_26018_p2 = (!add_ln703_506_reg_35786.read().is_01() || !add_ln703_510_fu_26014_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_506_reg_35786.read()) + sc_biguint<18>(add_ln703_510_fu_26014_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_512_fu_11258_p2() {
    add_ln703_512_fu_11258_p2 = (!sext_ln708_122_fu_11073_p1.read().is_01() || !trunc_ln708_514_fu_11207_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_122_fu_11073_p1.read()) + sc_biguint<18>(trunc_ln708_514_fu_11207_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_513_fu_11264_p2() {
    add_ln703_513_fu_11264_p2 = (!sext_ln1118_348_fu_11060_p1.read().is_01() || !sext_ln1118_345_fu_11015_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_348_fu_11060_p1.read()) + sc_bigint<17>(sext_ln1118_345_fu_11015_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_514_fu_11274_p2() {
    add_ln703_514_fu_11274_p2 = (!sext_ln708_121_fu_10982_p1.read().is_01() || !sext_ln703_113_fu_11270_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_121_fu_10982_p1.read()) + sc_bigint<18>(sext_ln703_113_fu_11270_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_515_fu_11280_p2() {
    add_ln703_515_fu_11280_p2 = (!add_ln703_512_fu_11258_p2.read().is_01() || !add_ln703_514_fu_11274_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_512_fu_11258_p2.read()) + sc_biguint<18>(add_ln703_514_fu_11274_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_516_fu_11286_p2() {
    add_ln703_516_fu_11286_p2 = (!sext_ln1118_350_fu_11135_p1.read().is_01() || !sext_ln1118_349_fu_11122_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_350_fu_11135_p1.read()) + sc_bigint<17>(sext_ln1118_349_fu_11122_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_517_fu_11296_p2() {
    add_ln703_517_fu_11296_p2 = (!sext_ln1118_343_fu_10960_p1.read().is_01() || !sext_ln1118_344_fu_11002_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_343_fu_10960_p1.read()) + sc_bigint<14>(sext_ln1118_344_fu_11002_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_518_fu_11306_p2() {
    add_ln703_518_fu_11306_p2 = (!sext_ln1118_352_fu_11167_p1.read().is_01() || !sext_ln703_115_fu_11302_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_352_fu_11167_p1.read()) + sc_bigint<16>(sext_ln703_115_fu_11302_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_519_fu_11316_p2() {
    add_ln703_519_fu_11316_p2 = (!sext_ln703_114_fu_11292_p1.read().is_01() || !sext_ln703_116_fu_11312_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_114_fu_11292_p1.read()) + sc_bigint<18>(sext_ln703_116_fu_11312_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_520_fu_26023_p2() {
    add_ln703_520_fu_26023_p2 = (!add_ln703_515_reg_35801.read().is_01() || !add_ln703_519_reg_35806.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_515_reg_35801.read()) + sc_biguint<18>(add_ln703_519_reg_35806.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_522_fu_11581_p2() {
    add_ln703_522_fu_11581_p2 = (!trunc_ln708_519_fu_11370_p4.read().is_01() || !trunc_ln708_515_fu_11322_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_519_fu_11370_p4.read()) + sc_biguint<18>(trunc_ln708_515_fu_11322_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_523_fu_11587_p2() {
    add_ln703_523_fu_11587_p2 = (!trunc_ln708_525_fu_11479_p4.read().is_01() || !trunc_ln708_524_fu_11452_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_525_fu_11479_p4.read()) + sc_biguint<18>(trunc_ln708_524_fu_11452_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_524_fu_11593_p2() {
    add_ln703_524_fu_11593_p2 = (!trunc_ln708_523_fu_11443_p4.read().is_01() || !add_ln703_523_fu_11587_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_523_fu_11443_p4.read()) + sc_biguint<18>(add_ln703_523_fu_11587_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_525_fu_11599_p2() {
    add_ln703_525_fu_11599_p2 = (!add_ln703_522_fu_11581_p2.read().is_01() || !add_ln703_524_fu_11593_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_522_fu_11581_p2.read()) + sc_biguint<18>(add_ln703_524_fu_11593_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_526_fu_11605_p2() {
    add_ln703_526_fu_11605_p2 = (!trunc_ln708_527_fu_11498_p4.read().is_01() || !trunc_ln708_526_fu_11489_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_527_fu_11498_p4.read()) + sc_biguint<18>(trunc_ln708_526_fu_11489_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_527_fu_11611_p2() {
    add_ln703_527_fu_11611_p2 = (!trunc_ln708_530_fu_11525_p4.read().is_01() || !trunc_ln708_529_fu_11516_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_530_fu_11525_p4.read()) + sc_biguint<18>(trunc_ln708_529_fu_11516_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_528_fu_11617_p2() {
    add_ln703_528_fu_11617_p2 = (!trunc_ln708_528_fu_11507_p4.read().is_01() || !add_ln703_527_fu_11611_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_528_fu_11507_p4.read()) + sc_biguint<18>(add_ln703_527_fu_11611_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_529_fu_26033_p2() {
    add_ln703_529_fu_26033_p2 = (!add_ln703_526_reg_35816.read().is_01() || !add_ln703_528_reg_35821.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_526_reg_35816.read()) + sc_biguint<18>(add_ln703_528_reg_35821.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_530_fu_26037_p2() {
    add_ln703_530_fu_26037_p2 = (!add_ln703_525_reg_35811.read().is_01() || !add_ln703_529_fu_26033_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_525_reg_35811.read()) + sc_biguint<18>(add_ln703_529_fu_26033_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_531_fu_11623_p2() {
    add_ln703_531_fu_11623_p2 = (!trunc_ln708_532_fu_11543_p4.read().is_01() || !trunc_ln708_531_fu_11534_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_532_fu_11543_p4.read()) + sc_biguint<18>(trunc_ln708_531_fu_11534_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_532_fu_11629_p2() {
    add_ln703_532_fu_11629_p2 = (!sext_ln708_124_fu_11353_p1.read().is_01() || !sext_ln708_123_fu_11340_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_124_fu_11353_p1.read()) + sc_bigint<18>(sext_ln708_123_fu_11340_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_533_fu_11635_p2() {
    add_ln703_533_fu_11635_p2 = (!trunc_ln708_534_fu_11572_p4.read().is_01() || !add_ln703_532_fu_11629_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_534_fu_11572_p4.read()) + sc_biguint<18>(add_ln703_532_fu_11629_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_534_fu_11641_p2() {
    add_ln703_534_fu_11641_p2 = (!add_ln703_531_fu_11623_p2.read().is_01() || !add_ln703_533_fu_11635_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_531_fu_11623_p2.read()) + sc_biguint<18>(add_ln703_533_fu_11635_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_535_fu_11647_p2() {
    add_ln703_535_fu_11647_p2 = (!sext_ln708_127_fu_11439_p1.read().is_01() || !sext_ln708_126_fu_11426_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_127_fu_11439_p1.read()) + sc_bigint<18>(sext_ln708_126_fu_11426_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_536_fu_11653_p2() {
    add_ln703_536_fu_11653_p2 = (!sext_ln708_125_fu_11366_p1.read().is_01() || !add_ln703_535_fu_11647_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_125_fu_11366_p1.read()) + sc_biguint<18>(add_ln703_535_fu_11647_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_537_fu_11659_p2() {
    add_ln703_537_fu_11659_p2 = (!sext_ln1118_356_fu_11568_p1.read().is_01() || !ap_const_lv15_7E92.is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_356_fu_11568_p1.read()) + sc_bigint<15>(ap_const_lv15_7E92));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_538_fu_11669_p2() {
    add_ln703_538_fu_11669_p2 = (!sext_ln1118_354_fu_11413_p1.read().is_01() || !sext_ln703_117_fu_11665_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_354_fu_11413_p1.read()) + sc_bigint<16>(sext_ln703_117_fu_11665_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_539_fu_11679_p2() {
    add_ln703_539_fu_11679_p2 = (!add_ln703_536_fu_11653_p2.read().is_01() || !sext_ln703_118_fu_11675_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_536_fu_11653_p2.read()) + sc_bigint<18>(sext_ln703_118_fu_11675_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_540_fu_26042_p2() {
    add_ln703_540_fu_26042_p2 = (!add_ln703_534_reg_35826.read().is_01() || !add_ln703_539_reg_35831.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_534_reg_35826.read()) + sc_biguint<18>(add_ln703_539_reg_35831.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_542_fu_11940_p2() {
    add_ln703_542_fu_11940_p2 = (!trunc_ln708_537_fu_11707_p4.read().is_01() || !trunc_ln708_536_fu_11698_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_537_fu_11707_p4.read()) + sc_biguint<18>(trunc_ln708_536_fu_11698_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_543_fu_11946_p2() {
    add_ln703_543_fu_11946_p2 = (!trunc_ln708_544_fu_11821_p4.read().is_01() || !trunc_ln708_539_fu_11760_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_544_fu_11821_p4.read()) + sc_biguint<18>(trunc_ln708_539_fu_11760_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_544_fu_11952_p2() {
    add_ln703_544_fu_11952_p2 = (!trunc_ln708_538_fu_11750_p4.read().is_01() || !add_ln703_543_fu_11946_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_538_fu_11750_p4.read()) + sc_biguint<18>(add_ln703_543_fu_11946_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_545_fu_11958_p2() {
    add_ln703_545_fu_11958_p2 = (!add_ln703_542_fu_11940_p2.read().is_01() || !add_ln703_544_fu_11952_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_542_fu_11940_p2.read()) + sc_biguint<18>(add_ln703_544_fu_11952_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_546_fu_11964_p2() {
    add_ln703_546_fu_11964_p2 = (!trunc_ln708_550_fu_11887_p4.read().is_01() || !trunc_ln708_546_fu_11843_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_550_fu_11887_p4.read()) + sc_biguint<18>(trunc_ln708_546_fu_11843_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_547_fu_11970_p2() {
    add_ln703_547_fu_11970_p2 = (!sext_ln708_128_fu_11694_p1.read().is_01() || !trunc_ln708_554_fu_11931_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_128_fu_11694_p1.read()) + sc_biguint<18>(trunc_ln708_554_fu_11931_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_548_fu_11976_p2() {
    add_ln703_548_fu_11976_p2 = (!trunc_ln708_551_fu_11896_p4.read().is_01() || !add_ln703_547_fu_11970_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_551_fu_11896_p4.read()) + sc_biguint<18>(add_ln703_547_fu_11970_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_549_fu_26055_p2() {
    add_ln703_549_fu_26055_p2 = (!add_ln703_546_reg_35846.read().is_01() || !add_ln703_548_reg_35851.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_546_reg_35846.read()) + sc_biguint<18>(add_ln703_548_reg_35851.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_550_fu_26059_p2() {
    add_ln703_550_fu_26059_p2 = (!add_ln703_545_reg_35841.read().is_01() || !add_ln703_549_fu_26055_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_545_reg_35841.read()) + sc_biguint<18>(add_ln703_549_fu_26055_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_551_fu_11982_p2() {
    add_ln703_551_fu_11982_p2 = (!sext_ln708_131_fu_11804_p1.read().is_01() || !sext_ln708_129_fu_11778_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_131_fu_11804_p1.read()) + sc_bigint<18>(sext_ln708_129_fu_11778_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_552_fu_11988_p2() {
    add_ln703_552_fu_11988_p2 = (!sext_ln708_134_fu_11861_p1.read().is_01() || !sext_ln708_133_fu_11839_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_134_fu_11861_p1.read()) + sc_bigint<18>(sext_ln708_133_fu_11839_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_553_fu_11994_p2() {
    add_ln703_553_fu_11994_p2 = (!sext_ln708_132_fu_11817_p1.read().is_01() || !add_ln703_552_fu_11988_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_132_fu_11817_p1.read()) + sc_biguint<18>(add_ln703_552_fu_11988_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_554_fu_12000_p2() {
    add_ln703_554_fu_12000_p2 = (!add_ln703_551_fu_11982_p2.read().is_01() || !add_ln703_553_fu_11994_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_551_fu_11982_p2.read()) + sc_biguint<18>(add_ln703_553_fu_11994_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_555_fu_12006_p2() {
    add_ln703_555_fu_12006_p2 = (!sext_ln708_130_fu_11791_p1.read().is_01() || !sext_ln708_136_fu_11883_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_130_fu_11791_p1.read()) + sc_bigint<18>(sext_ln708_136_fu_11883_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_556_fu_26064_p2() {
    add_ln703_556_fu_26064_p2 = (!sext_ln708_135_fu_26052_p1.read().is_01() || !add_ln703_555_reg_35861.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_135_fu_26052_p1.read()) + sc_biguint<18>(add_ln703_555_reg_35861.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_557_fu_12012_p2() {
    add_ln703_557_fu_12012_p2 = (!sext_ln1118_361_fu_11927_p1.read().is_01() || !ap_const_lv16_4F.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_361_fu_11927_p1.read()) + sc_biguint<16>(ap_const_lv16_4F));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_558_fu_12022_p2() {
    add_ln703_558_fu_12022_p2 = (!sext_ln1118_360_fu_11914_p1.read().is_01() || !sext_ln703_119_fu_12018_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_360_fu_11914_p1.read()) + sc_bigint<17>(sext_ln703_119_fu_12018_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_559_fu_26072_p2() {
    add_ln703_559_fu_26072_p2 = (!add_ln703_556_fu_26064_p2.read().is_01() || !sext_ln703_120_fu_26069_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_556_fu_26064_p2.read()) + sc_bigint<18>(sext_ln703_120_fu_26069_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_560_fu_26078_p2() {
    add_ln703_560_fu_26078_p2 = (!add_ln703_554_reg_35856.read().is_01() || !add_ln703_559_fu_26072_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_554_reg_35856.read()) + sc_biguint<18>(add_ln703_559_fu_26072_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_562_fu_12301_p2() {
    add_ln703_562_fu_12301_p2 = (!trunc_ln708_558_fu_12093_p4.read().is_01() || !trunc_ln708_555_fu_12028_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_558_fu_12093_p4.read()) + sc_biguint<18>(trunc_ln708_555_fu_12028_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_563_fu_12307_p2() {
    add_ln703_563_fu_12307_p2 = (!trunc_ln708_561_fu_12120_p4.read().is_01() || !trunc_ln708_560_fu_12111_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_561_fu_12120_p4.read()) + sc_biguint<18>(trunc_ln708_560_fu_12111_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_564_fu_12313_p2() {
    add_ln703_564_fu_12313_p2 = (!trunc_ln708_559_fu_12102_p4.read().is_01() || !add_ln703_563_fu_12307_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_559_fu_12102_p4.read()) + sc_biguint<18>(add_ln703_563_fu_12307_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_565_fu_12319_p2() {
    add_ln703_565_fu_12319_p2 = (!add_ln703_562_fu_12301_p2.read().is_01() || !add_ln703_564_fu_12313_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_562_fu_12301_p2.read()) + sc_biguint<18>(add_ln703_564_fu_12313_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_566_fu_12325_p2() {
    add_ln703_566_fu_12325_p2 = (!trunc_ln708_563_fu_12138_p4.read().is_01() || !trunc_ln708_562_fu_12129_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_563_fu_12138_p4.read()) + sc_biguint<18>(trunc_ln708_562_fu_12129_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_567_fu_12331_p2() {
    add_ln703_567_fu_12331_p2 = (!trunc_ln708_570_fu_12244_p4.read().is_01() || !trunc_ln708_569_fu_12235_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_570_fu_12244_p4.read()) + sc_biguint<18>(trunc_ln708_569_fu_12235_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_568_fu_12337_p2() {
    add_ln703_568_fu_12337_p2 = (!trunc_ln708_565_fu_12161_p4.read().is_01() || !add_ln703_567_fu_12331_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_565_fu_12161_p4.read()) + sc_biguint<18>(add_ln703_567_fu_12331_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_569_fu_26089_p2() {
    add_ln703_569_fu_26089_p2 = (!add_ln703_566_reg_35876.read().is_01() || !add_ln703_568_reg_35881.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_566_reg_35876.read()) + sc_biguint<18>(add_ln703_568_reg_35881.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_570_fu_26093_p2() {
    add_ln703_570_fu_26093_p2 = (!add_ln703_565_reg_35871.read().is_01() || !add_ln703_569_fu_26089_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_565_reg_35871.read()) + sc_biguint<18>(add_ln703_569_fu_26089_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_571_fu_12343_p2() {
    add_ln703_571_fu_12343_p2 = (!sext_ln708_138_fu_12089_p1.read().is_01() || !trunc_ln708_573_fu_12279_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_138_fu_12089_p1.read()) + sc_biguint<18>(trunc_ln708_573_fu_12279_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_572_fu_12349_p2() {
    add_ln703_572_fu_12349_p2 = (!sext_ln708_137_fu_12053_p1.read().is_01() || !sext_ln708_140_fu_12297_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_137_fu_12053_p1.read()) + sc_bigint<18>(sext_ln708_140_fu_12297_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_573_fu_12355_p2() {
    add_ln703_573_fu_12355_p2 = (!sext_ln708_139_fu_12262_p1.read().is_01() || !add_ln703_572_fu_12349_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_139_fu_12262_p1.read()) + sc_biguint<18>(add_ln703_572_fu_12349_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_574_fu_12361_p2() {
    add_ln703_574_fu_12361_p2 = (!add_ln703_571_fu_12343_p2.read().is_01() || !add_ln703_573_fu_12355_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_571_fu_12343_p2.read()) + sc_biguint<18>(add_ln703_573_fu_12355_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_575_fu_12367_p2() {
    add_ln703_575_fu_12367_p2 = (!sext_ln1118_368_fu_12231_p1.read().is_01() || !sext_ln1118_366_fu_12199_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_368_fu_12231_p1.read()) + sc_bigint<16>(sext_ln1118_366_fu_12199_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_576_fu_12377_p2() {
    add_ln703_576_fu_12377_p2 = (!sext_ln1118_365_fu_12179_p1.read().is_01() || !sext_ln703_121_fu_12373_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_365_fu_12179_p1.read()) + sc_bigint<17>(sext_ln703_121_fu_12373_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_577_fu_12387_p2() {
    add_ln703_577_fu_12387_p2 = (!sext_ln1118_364_fu_12157_p1.read().is_01() || !ap_const_lv14_59.is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_364_fu_12157_p1.read()) + sc_biguint<14>(ap_const_lv14_59));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_578_fu_12397_p2() {
    add_ln703_578_fu_12397_p2 = (!sext_ln1118_369_fu_12275_p1.read().is_01() || !sext_ln703_123_fu_12393_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_369_fu_12275_p1.read()) + sc_bigint<16>(sext_ln703_123_fu_12393_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_579_fu_12407_p2() {
    add_ln703_579_fu_12407_p2 = (!sext_ln703_122_fu_12383_p1.read().is_01() || !sext_ln703_124_fu_12403_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_122_fu_12383_p1.read()) + sc_bigint<18>(sext_ln703_124_fu_12403_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_580_fu_26098_p2() {
    add_ln703_580_fu_26098_p2 = (!add_ln703_574_reg_35886.read().is_01() || !add_ln703_579_reg_35891.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_574_reg_35886.read()) + sc_biguint<18>(add_ln703_579_reg_35891.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_582_fu_12621_p2() {
    add_ln703_582_fu_12621_p2 = (!trunc_ln708_577_fu_12435_p4.read().is_01() || !trunc_ln708_576_fu_12426_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_577_fu_12435_p4.read()) + sc_biguint<18>(trunc_ln708_576_fu_12426_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_583_fu_12627_p2() {
    add_ln703_583_fu_12627_p2 = (!trunc_ln708_583_fu_12501_p4.read().is_01() || !trunc_ln708_581_fu_12479_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_583_fu_12501_p4.read()) + sc_biguint<18>(trunc_ln708_581_fu_12479_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_584_fu_12633_p2() {
    add_ln703_584_fu_12633_p2 = (!trunc_ln708_578_fu_12444_p4.read().is_01() || !add_ln703_583_fu_12627_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_578_fu_12444_p4.read()) + sc_biguint<18>(add_ln703_583_fu_12627_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_585_fu_12639_p2() {
    add_ln703_585_fu_12639_p2 = (!add_ln703_582_fu_12621_p2.read().is_01() || !add_ln703_584_fu_12633_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_582_fu_12621_p2.read()) + sc_biguint<18>(add_ln703_584_fu_12633_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_586_fu_12645_p2() {
    add_ln703_586_fu_12645_p2 = (!trunc_ln708_585_fu_12519_p4.read().is_01() || !trunc_ln708_584_fu_12510_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_585_fu_12519_p4.read()) + sc_biguint<18>(trunc_ln708_584_fu_12510_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_587_fu_12651_p2() {
    add_ln703_587_fu_12651_p2 = (!trunc_ln708_593_fu_12612_p4.read().is_01() || !trunc_ln708_591_fu_12589_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_593_fu_12612_p4.read()) + sc_biguint<18>(trunc_ln708_591_fu_12589_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_588_fu_12657_p2() {
    add_ln703_588_fu_12657_p2 = (!trunc_ln708_590_fu_12580_p4.read().is_01() || !add_ln703_587_fu_12651_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_590_fu_12580_p4.read()) + sc_biguint<18>(add_ln703_587_fu_12651_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_589_fu_26108_p2() {
    add_ln703_589_fu_26108_p2 = (!add_ln703_586_reg_35901.read().is_01() || !add_ln703_588_reg_35906.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_586_reg_35901.read()) + sc_biguint<18>(add_ln703_588_reg_35906.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_590_fu_26112_p2() {
    add_ln703_590_fu_26112_p2 = (!add_ln703_585_reg_35896.read().is_01() || !add_ln703_589_fu_26108_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_585_reg_35896.read()) + sc_biguint<18>(add_ln703_589_fu_26108_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_591_fu_12663_p2() {
    add_ln703_591_fu_12663_p2 = (!sext_ln708_141_fu_12422_p1.read().is_01() || !sext_ln708_115_fu_10584_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_141_fu_12422_p1.read()) + sc_bigint<18>(sext_ln708_115_fu_10584_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_592_fu_12669_p2() {
    add_ln703_592_fu_12669_p2 = (!sext_ln708_142_fu_12462_p1.read().is_01() || !sext_ln708_144_fu_12550_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_142_fu_12462_p1.read()) + sc_bigint<18>(sext_ln708_144_fu_12550_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_593_fu_12675_p2() {
    add_ln703_593_fu_12675_p2 = (!sext_ln708_143_fu_12537_p1.read().is_01() || !add_ln703_592_fu_12669_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_143_fu_12537_p1.read()) + sc_biguint<18>(add_ln703_592_fu_12669_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_594_fu_12681_p2() {
    add_ln703_594_fu_12681_p2 = (!add_ln703_591_fu_12663_p2.read().is_01() || !add_ln703_593_fu_12675_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_591_fu_12663_p2.read()) + sc_biguint<18>(add_ln703_593_fu_12675_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_595_fu_12687_p2() {
    add_ln703_595_fu_12687_p2 = (!sext_ln1118_370_fu_12475_p1.read().is_01() || !sext_ln1118_372_fu_12576_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_370_fu_12475_p1.read()) + sc_bigint<17>(sext_ln1118_372_fu_12576_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_596_fu_12697_p2() {
    add_ln703_596_fu_12697_p2 = (!sext_ln708_145_fu_12563_p1.read().is_01() || !sext_ln703_125_fu_12693_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_145_fu_12563_p1.read()) + sc_bigint<18>(sext_ln703_125_fu_12693_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_597_fu_12703_p2() {
    add_ln703_597_fu_12703_p2 = (!sext_ln1118_373_fu_12608_p1.read().is_01() || !ap_const_lv12_F08.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln1118_373_fu_12608_p1.read()) + sc_bigint<12>(ap_const_lv12_F08));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_598_fu_12713_p2() {
    add_ln703_598_fu_12713_p2 = (!sext_ln1118_371_fu_12497_p1.read().is_01() || !sext_ln703_126_fu_12709_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_371_fu_12497_p1.read()) + sc_bigint<15>(sext_ln703_126_fu_12709_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_599_fu_12723_p2() {
    add_ln703_599_fu_12723_p2 = (!add_ln703_596_fu_12697_p2.read().is_01() || !sext_ln703_127_fu_12719_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_596_fu_12697_p2.read()) + sc_bigint<18>(sext_ln703_127_fu_12719_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_600_fu_26117_p2() {
    add_ln703_600_fu_26117_p2 = (!add_ln703_594_reg_35911.read().is_01() || !add_ln703_599_reg_35916.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_594_reg_35911.read()) + sc_biguint<18>(add_ln703_599_reg_35916.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_602_fu_12980_p2() {
    add_ln703_602_fu_12980_p2 = (!trunc_ln708_595_fu_12738_p4.read().is_01() || !trunc_ln708_594_fu_12729_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_595_fu_12738_p4.read()) + sc_biguint<18>(trunc_ln708_594_fu_12729_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_603_fu_12986_p2() {
    add_ln703_603_fu_12986_p2 = (!trunc_ln708_598_fu_12785_p4.read().is_01() || !trunc_ln708_597_fu_12756_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_598_fu_12785_p4.read()) + sc_biguint<18>(trunc_ln708_597_fu_12756_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_604_fu_12992_p2() {
    add_ln703_604_fu_12992_p2 = (!trunc_ln708_596_fu_12747_p4.read().is_01() || !add_ln703_603_fu_12986_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_596_fu_12747_p4.read()) + sc_biguint<18>(add_ln703_603_fu_12986_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_605_fu_12998_p2() {
    add_ln703_605_fu_12998_p2 = (!add_ln703_602_fu_12980_p2.read().is_01() || !add_ln703_604_fu_12992_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_602_fu_12980_p2.read()) + sc_biguint<18>(add_ln703_604_fu_12992_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_606_fu_13004_p2() {
    add_ln703_606_fu_13004_p2 = (!trunc_ln708_600_fu_12804_p4.read().is_01() || !trunc_ln708_599_fu_12795_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_600_fu_12804_p4.read()) + sc_biguint<18>(trunc_ln708_599_fu_12795_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_607_fu_13010_p2() {
    add_ln703_607_fu_13010_p2 = (!trunc_ln708_604_fu_12844_p4.read().is_01() || !trunc_ln708_603_fu_12835_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_604_fu_12844_p4.read()) + sc_biguint<18>(trunc_ln708_603_fu_12835_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_608_fu_13016_p2() {
    add_ln703_608_fu_13016_p2 = (!trunc_ln708_601_fu_12813_p4.read().is_01() || !add_ln703_607_fu_13010_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_601_fu_12813_p4.read()) + sc_biguint<18>(add_ln703_607_fu_13010_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_609_fu_26127_p2() {
    add_ln703_609_fu_26127_p2 = (!add_ln703_606_reg_35926.read().is_01() || !add_ln703_608_reg_35931.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_606_reg_35926.read()) + sc_biguint<18>(add_ln703_608_reg_35931.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_610_fu_26131_p2() {
    add_ln703_610_fu_26131_p2 = (!add_ln703_605_reg_35921.read().is_01() || !add_ln703_609_fu_26127_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_605_reg_35921.read()) + sc_biguint<18>(add_ln703_609_fu_26127_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_611_fu_13022_p2() {
    add_ln703_611_fu_13022_p2 = (!trunc_ln708_607_fu_12875_p4.read().is_01() || !trunc_ln708_606_fu_12866_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_607_fu_12875_p4.read()) + sc_biguint<18>(trunc_ln708_606_fu_12866_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_612_fu_13028_p2() {
    add_ln703_612_fu_13028_p2 = (!trunc_ln708_611_fu_12922_p4.read().is_01() || !trunc_ln708_610_fu_12913_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_611_fu_12922_p4.read()) + sc_biguint<18>(trunc_ln708_610_fu_12913_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_613_fu_13034_p2() {
    add_ln703_613_fu_13034_p2 = (!trunc_ln708_609_fu_12904_p4.read().is_01() || !add_ln703_612_fu_13028_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_609_fu_12904_p4.read()) + sc_biguint<18>(add_ln703_612_fu_13028_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_614_fu_13040_p2() {
    add_ln703_614_fu_13040_p2 = (!add_ln703_611_fu_13022_p2.read().is_01() || !add_ln703_613_fu_13034_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_611_fu_13022_p2.read()) + sc_biguint<18>(add_ln703_613_fu_13034_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_615_fu_13046_p2() {
    add_ln703_615_fu_13046_p2 = (!sext_ln708_148_fu_12976_p1.read().is_01() || !sext_ln708_147_fu_12862_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_148_fu_12976_p1.read()) + sc_bigint<18>(sext_ln708_147_fu_12862_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_616_fu_13052_p2() {
    add_ln703_616_fu_13052_p2 = (!sext_ln708_146_fu_12831_p1.read().is_01() || !add_ln703_615_fu_13046_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_146_fu_12831_p1.read()) + sc_biguint<18>(add_ln703_615_fu_13046_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_617_fu_13058_p2() {
    add_ln703_617_fu_13058_p2 = (!sext_ln1118_377_fu_12963_p1.read().is_01() || !ap_const_lv13_1FA6.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_377_fu_12963_p1.read()) + sc_bigint<13>(ap_const_lv13_1FA6));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_618_fu_13068_p2() {
    add_ln703_618_fu_13068_p2 = (!sext_ln1118_374_fu_12900_p1.read().is_01() || !sext_ln703_128_fu_13064_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_374_fu_12900_p1.read()) + sc_bigint<14>(sext_ln703_128_fu_13064_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_619_fu_13078_p2() {
    add_ln703_619_fu_13078_p2 = (!add_ln703_616_fu_13052_p2.read().is_01() || !sext_ln703_129_fu_13074_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_616_fu_13052_p2.read()) + sc_bigint<18>(sext_ln703_129_fu_13074_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_620_fu_26136_p2() {
    add_ln703_620_fu_26136_p2 = (!add_ln703_614_reg_35936.read().is_01() || !add_ln703_619_reg_35941.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_614_reg_35936.read()) + sc_biguint<18>(add_ln703_619_reg_35941.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_622_fu_13386_p2() {
    add_ln703_622_fu_13386_p2 = (!trunc_ln708_618_fu_13132_p4.read().is_01() || !trunc_ln708_616_fu_13110_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_618_fu_13132_p4.read()) + sc_biguint<18>(trunc_ln708_616_fu_13110_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_623_fu_13392_p2() {
    add_ln703_623_fu_13392_p2 = (!trunc_ln708_627_fu_13305_p4.read().is_01() || !trunc_ln708_506_fu_11104_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_627_fu_13305_p4.read()) + sc_biguint<18>(trunc_ln708_506_fu_11104_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_624_fu_13398_p2() {
    add_ln703_624_fu_13398_p2 = (!trunc_ln708_624_fu_13251_p4.read().is_01() || !add_ln703_623_fu_13392_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_624_fu_13251_p4.read()) + sc_biguint<18>(add_ln703_623_fu_13392_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_625_fu_13404_p2() {
    add_ln703_625_fu_13404_p2 = (!add_ln703_622_fu_13386_p2.read().is_01() || !add_ln703_624_fu_13398_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_622_fu_13386_p2.read()) + sc_biguint<18>(add_ln703_624_fu_13398_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_626_fu_13410_p2() {
    add_ln703_626_fu_13410_p2 = (!trunc_ln708_629_fu_13323_p4.read().is_01() || !trunc_ln708_628_fu_13314_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_629_fu_13323_p4.read()) + sc_biguint<18>(trunc_ln708_628_fu_13314_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_627_fu_13416_p2() {
    add_ln703_627_fu_13416_p2 = (!sext_ln708_150_fu_13177_p1.read().is_01() || !sext_ln708_149_fu_13128_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_150_fu_13177_p1.read()) + sc_bigint<18>(sext_ln708_149_fu_13128_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_628_fu_13422_p2() {
    add_ln703_628_fu_13422_p2 = (!trunc_ln708_631_fu_13364_p4.read().is_01() || !add_ln703_627_fu_13416_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_631_fu_13364_p4.read()) + sc_biguint<18>(add_ln703_627_fu_13416_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_629_fu_26146_p2() {
    add_ln703_629_fu_26146_p2 = (!add_ln703_626_reg_35951.read().is_01() || !add_ln703_628_reg_35956.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_626_reg_35951.read()) + sc_biguint<18>(add_ln703_628_reg_35956.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_630_fu_26150_p2() {
    add_ln703_630_fu_26150_p2 = (!add_ln703_625_reg_35946.read().is_01() || !add_ln703_629_fu_26146_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_625_reg_35946.read()) + sc_biguint<18>(add_ln703_629_fu_26146_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_631_fu_13428_p2() {
    add_ln703_631_fu_13428_p2 = (!sext_ln708_152_fu_13247_p1.read().is_01() || !sext_ln708_151_fu_13234_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_152_fu_13247_p1.read()) + sc_bigint<18>(sext_ln708_151_fu_13234_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_632_fu_13434_p2() {
    add_ln703_632_fu_13434_p2 = (!sext_ln1118_384_fu_13269_p1.read().is_01() || !sext_ln1118_378_fu_13093_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_384_fu_13269_p1.read()) + sc_bigint<17>(sext_ln1118_378_fu_13093_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_633_fu_13444_p2() {
    add_ln703_633_fu_13444_p2 = (!sext_ln708_153_fu_13301_p1.read().is_01() || !sext_ln703_131_fu_13440_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_153_fu_13301_p1.read()) + sc_bigint<18>(sext_ln703_131_fu_13440_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_634_fu_13450_p2() {
    add_ln703_634_fu_13450_p2 = (!add_ln703_631_fu_13428_p2.read().is_01() || !add_ln703_633_fu_13444_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_631_fu_13428_p2.read()) + sc_biguint<18>(add_ln703_633_fu_13444_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_635_fu_13456_p2() {
    add_ln703_635_fu_13456_p2 = (!sext_ln1118_379_fu_13106_p1.read().is_01() || !sext_ln1118_380_fu_13157_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_379_fu_13106_p1.read()) + sc_bigint<16>(sext_ln1118_380_fu_13157_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_636_fu_13466_p2() {
    add_ln703_636_fu_13466_p2 = (!sext_ln703_130_fu_13382_p1.read().is_01() || !sext_ln703_132_fu_13462_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_130_fu_13382_p1.read()) + sc_bigint<17>(sext_ln703_132_fu_13462_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_637_fu_13472_p2() {
    add_ln703_637_fu_13472_p2 = (!sext_ln1118_383_fu_13221_p1.read().is_01() || !ap_const_lv13_1FE6.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_383_fu_13221_p1.read()) + sc_bigint<13>(ap_const_lv13_1FE6));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_638_fu_13482_p2() {
    add_ln703_638_fu_13482_p2 = (!sext_ln1118_387_fu_13360_p1.read().is_01() || !sext_ln703_134_fu_13478_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_387_fu_13360_p1.read()) + sc_bigint<15>(sext_ln703_134_fu_13478_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_639_fu_26161_p2() {
    add_ln703_639_fu_26161_p2 = (!sext_ln703_133_fu_26155_p1.read().is_01() || !sext_ln703_135_fu_26158_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln703_133_fu_26155_p1.read()) + sc_bigint<18>(sext_ln703_135_fu_26158_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_640_fu_26167_p2() {
    add_ln703_640_fu_26167_p2 = (!add_ln703_634_reg_35961.read().is_01() || !add_ln703_639_fu_26161_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_634_reg_35961.read()) + sc_biguint<18>(add_ln703_639_fu_26161_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_642_fu_13725_p2() {
    add_ln703_642_fu_13725_p2 = (!trunc_ln708_635_fu_13510_p4.read().is_01() || !trunc_ln708_633_fu_13488_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_635_fu_13510_p4.read()) + sc_biguint<18>(trunc_ln708_633_fu_13488_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_643_fu_13731_p2() {
    add_ln703_643_fu_13731_p2 = (!trunc_ln708_638_fu_13568_p4.read().is_01() || !trunc_ln708_637_fu_13558_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_638_fu_13568_p4.read()) + sc_biguint<18>(trunc_ln708_637_fu_13558_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_644_fu_13737_p2() {
    add_ln703_644_fu_13737_p2 = (!trunc_ln708_636_fu_13519_p4.read().is_01() || !add_ln703_643_fu_13731_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_636_fu_13519_p4.read()) + sc_biguint<18>(add_ln703_643_fu_13731_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_645_fu_13743_p2() {
    add_ln703_645_fu_13743_p2 = (!add_ln703_642_fu_13725_p2.read().is_01() || !add_ln703_644_fu_13737_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_642_fu_13725_p2.read()) + sc_biguint<18>(add_ln703_644_fu_13737_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_646_fu_13749_p2() {
    add_ln703_646_fu_13749_p2 = (!trunc_ln708_641_fu_13595_p4.read().is_01() || !trunc_ln708_640_fu_13586_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_641_fu_13595_p4.read()) + sc_biguint<18>(trunc_ln708_640_fu_13586_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_647_fu_13755_p2() {
    add_ln703_647_fu_13755_p2 = (!trunc_ln708_644_fu_13622_p4.read().is_01() || !trunc_ln708_643_fu_13613_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_644_fu_13622_p4.read()) + sc_biguint<18>(trunc_ln708_643_fu_13613_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_648_fu_13761_p2() {
    add_ln703_648_fu_13761_p2 = (!trunc_ln708_642_fu_13604_p4.read().is_01() || !add_ln703_647_fu_13755_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_642_fu_13604_p4.read()) + sc_biguint<18>(add_ln703_647_fu_13755_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_649_fu_26181_p2() {
    add_ln703_649_fu_26181_p2 = (!add_ln703_646_reg_35986.read().is_01() || !add_ln703_648_reg_35991.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_646_reg_35986.read()) + sc_biguint<18>(add_ln703_648_reg_35991.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_64_fu_2729_p2() {
    add_ln703_64_fu_2729_p2 = (!trunc_ln708_65_fu_2186_p4.read().is_01() || !trunc_ln708_64_fu_2165_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_65_fu_2186_p4.read()) + sc_biguint<18>(trunc_ln708_64_fu_2165_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_650_fu_26185_p2() {
    add_ln703_650_fu_26185_p2 = (!add_ln703_645_reg_35981.read().is_01() || !add_ln703_649_fu_26181_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_645_reg_35981.read()) + sc_biguint<18>(add_ln703_649_fu_26181_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_651_fu_13767_p2() {
    add_ln703_651_fu_13767_p2 = (!trunc_ln708_647_fu_13672_p4.read().is_01() || !trunc_ln708_645_fu_13631_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_647_fu_13672_p4.read()) + sc_biguint<18>(trunc_ln708_645_fu_13631_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_652_fu_13773_p2() {
    add_ln703_652_fu_13773_p2 = (!sext_ln708_154_fu_13506_p1.read().is_01() || !trunc_ln708_649_fu_13690_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_154_fu_13506_p1.read()) + sc_biguint<18>(trunc_ln708_649_fu_13690_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_653_fu_13779_p2() {
    add_ln703_653_fu_13779_p2 = (!trunc_ln708_648_fu_13681_p4.read().is_01() || !add_ln703_652_fu_13773_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_648_fu_13681_p4.read()) + sc_biguint<18>(add_ln703_652_fu_13773_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_654_fu_13785_p2() {
    add_ln703_654_fu_13785_p2 = (!add_ln703_651_fu_13767_p2.read().is_01() || !add_ln703_653_fu_13779_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_651_fu_13767_p2.read()) + sc_biguint<18>(add_ln703_653_fu_13779_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_655_fu_13791_p2() {
    add_ln703_655_fu_13791_p2 = (!sext_ln703_136_fu_13721_p1.read().is_01() || !sext_ln1118_391_fu_13668_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_136_fu_13721_p1.read()) + sc_bigint<17>(sext_ln1118_391_fu_13668_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_656_fu_26193_p2() {
    add_ln703_656_fu_26193_p2 = (!sext_ln708_155_fu_26178_p1.read().is_01() || !sext_ln703_137_fu_26190_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_155_fu_26178_p1.read()) + sc_bigint<18>(sext_ln703_137_fu_26190_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_657_fu_13797_p2() {
    add_ln703_657_fu_13797_p2 = (!sext_ln1118_392_fu_13708_p1.read().is_01() || !ap_const_lv16_FE94.is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln1118_392_fu_13708_p1.read()) + sc_bigint<16>(ap_const_lv16_FE94));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_658_fu_13807_p2() {
    add_ln703_658_fu_13807_p2 = (!sext_ln1118_188_fu_4189_p1.read().is_01() || !sext_ln703_138_fu_13803_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_188_fu_4189_p1.read()) + sc_bigint<17>(sext_ln703_138_fu_13803_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_659_fu_26202_p2() {
    add_ln703_659_fu_26202_p2 = (!add_ln703_656_fu_26193_p2.read().is_01() || !sext_ln703_139_fu_26199_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_656_fu_26193_p2.read()) + sc_bigint<18>(sext_ln703_139_fu_26199_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_65_fu_2735_p2() {
    add_ln703_65_fu_2735_p2 = (!trunc_ln708_63_fu_2132_p4.read().is_01() || !add_ln703_64_fu_2729_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_63_fu_2132_p4.read()) + sc_biguint<18>(add_ln703_64_fu_2729_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_660_fu_26208_p2() {
    add_ln703_660_fu_26208_p2 = (!add_ln703_654_reg_35996.read().is_01() || !add_ln703_659_fu_26202_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_654_reg_35996.read()) + sc_biguint<18>(add_ln703_659_fu_26202_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_662_fu_14067_p2() {
    add_ln703_662_fu_14067_p2 = (!trunc_ln708_654_fu_13835_p4.read().is_01() || !trunc_ln708_653_fu_13826_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_654_fu_13835_p4.read()) + sc_biguint<18>(trunc_ln708_653_fu_13826_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_663_fu_14073_p2() {
    add_ln703_663_fu_14073_p2 = (!trunc_ln708_657_fu_13862_p4.read().is_01() || !trunc_ln708_656_fu_13853_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_657_fu_13862_p4.read()) + sc_biguint<18>(trunc_ln708_656_fu_13853_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_664_fu_14079_p2() {
    add_ln703_664_fu_14079_p2 = (!trunc_ln708_655_fu_13844_p4.read().is_01() || !add_ln703_663_fu_14073_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_655_fu_13844_p4.read()) + sc_biguint<18>(add_ln703_663_fu_14073_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_665_fu_14085_p2() {
    add_ln703_665_fu_14085_p2 = (!add_ln703_662_fu_14067_p2.read().is_01() || !add_ln703_664_fu_14079_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_662_fu_14067_p2.read()) + sc_biguint<18>(add_ln703_664_fu_14079_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_666_fu_14091_p2() {
    add_ln703_666_fu_14091_p2 = (!trunc_ln708_662_fu_13946_p4.read().is_01() || !trunc_ln708_658_fu_13871_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_662_fu_13946_p4.read()) + sc_biguint<18>(trunc_ln708_658_fu_13871_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_667_fu_14097_p2() {
    add_ln703_667_fu_14097_p2 = (!trunc_ln708_667_fu_14018_p4.read().is_01() || !trunc_ln708_666_fu_14009_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_667_fu_14018_p4.read()) + sc_biguint<18>(trunc_ln708_666_fu_14009_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_668_fu_14103_p2() {
    add_ln703_668_fu_14103_p2 = (!trunc_ln708_665_fu_14000_p4.read().is_01() || !add_ln703_667_fu_14097_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_665_fu_14000_p4.read()) + sc_biguint<18>(add_ln703_667_fu_14097_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_669_fu_26225_p2() {
    add_ln703_669_fu_26225_p2 = (!add_ln703_666_reg_36026.read().is_01() || !add_ln703_668_reg_36031.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_666_reg_36026.read()) + sc_biguint<18>(add_ln703_668_reg_36031.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_66_fu_2741_p2() {
    add_ln703_66_fu_2741_p2 = (!add_ln703_fu_2723_p2.read().is_01() || !add_ln703_65_fu_2735_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_fu_2723_p2.read()) + sc_biguint<18>(add_ln703_65_fu_2735_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_670_fu_26229_p2() {
    add_ln703_670_fu_26229_p2 = (!add_ln703_665_reg_36021.read().is_01() || !add_ln703_669_fu_26225_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_665_reg_36021.read()) + sc_biguint<18>(add_ln703_669_fu_26225_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_671_fu_14109_p2() {
    add_ln703_671_fu_14109_p2 = (!trunc_ln708_670_fu_14049_p4.read().is_01() || !trunc_ln708_668_fu_14027_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_670_fu_14049_p4.read()) + sc_biguint<18>(trunc_ln708_668_fu_14027_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_672_fu_14115_p2() {
    add_ln703_672_fu_14115_p2 = (!sext_ln708_160_fu_13964_p1.read().is_01() || !sext_ln708_159_fu_13942_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_160_fu_13964_p1.read()) + sc_bigint<18>(sext_ln708_159_fu_13942_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_673_fu_14121_p2() {
    add_ln703_673_fu_14121_p2 = (!sext_ln708_158_fu_13898_p1.read().is_01() || !add_ln703_672_fu_14115_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_158_fu_13898_p1.read()) + sc_biguint<18>(add_ln703_672_fu_14115_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_674_fu_14127_p2() {
    add_ln703_674_fu_14127_p2 = (!add_ln703_671_fu_14109_p2.read().is_01() || !add_ln703_673_fu_14121_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_671_fu_14109_p2.read()) + sc_biguint<18>(add_ln703_673_fu_14121_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_675_fu_14133_p2() {
    add_ln703_675_fu_14133_p2 = (!sext_ln708_156_fu_13822_p1.read().is_01() || !sext_ln708_162_fu_14045_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_156_fu_13822_p1.read()) + sc_bigint<18>(sext_ln708_162_fu_14045_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_676_fu_14139_p2() {
    add_ln703_676_fu_14139_p2 = (!sext_ln708_161_fu_13996_p1.read().is_01() || !add_ln703_675_fu_14133_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_161_fu_13996_p1.read()) + sc_biguint<18>(add_ln703_675_fu_14133_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_677_fu_26234_p2() {
    add_ln703_677_fu_26234_p2 = (!sext_ln703_140_fu_26222_p1.read().is_01() || !ap_const_lv17_1FFA7.is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln703_140_fu_26222_p1.read()) + sc_bigint<17>(ap_const_lv17_1FFA7));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_678_fu_26244_p2() {
    add_ln703_678_fu_26244_p2 = (!sext_ln708_157_fu_26219_p1.read().is_01() || !sext_ln703_141_fu_26240_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_157_fu_26219_p1.read()) + sc_bigint<18>(sext_ln703_141_fu_26240_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_679_fu_26250_p2() {
    add_ln703_679_fu_26250_p2 = (!add_ln703_676_reg_36041.read().is_01() || !add_ln703_678_fu_26244_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_676_reg_36041.read()) + sc_biguint<18>(add_ln703_678_fu_26244_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_67_fu_2747_p2() {
    add_ln703_67_fu_2747_p2 = (!trunc_ln708_72_fu_2458_p4.read().is_01() || !trunc_ln708_71_fu_2429_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_72_fu_2458_p4.read()) + sc_biguint<18>(trunc_ln708_71_fu_2429_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_680_fu_26255_p2() {
    add_ln703_680_fu_26255_p2 = (!add_ln703_674_reg_36036.read().is_01() || !add_ln703_679_fu_26250_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_674_reg_36036.read()) + sc_biguint<18>(add_ln703_679_fu_26250_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_682_fu_14389_p2() {
    add_ln703_682_fu_14389_p2 = (!trunc_ln708_676_fu_14233_p4.read().is_01() || !trunc_ln708_673_fu_14158_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_676_fu_14233_p4.read()) + sc_biguint<18>(trunc_ln708_673_fu_14158_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_683_fu_14395_p2() {
    add_ln703_683_fu_14395_p2 = (!trunc_ln708_679_fu_14260_p4.read().is_01() || !trunc_ln708_678_fu_14251_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_679_fu_14260_p4.read()) + sc_biguint<18>(trunc_ln708_678_fu_14251_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_684_fu_14401_p2() {
    add_ln703_684_fu_14401_p2 = (!trunc_ln708_677_fu_14242_p4.read().is_01() || !add_ln703_683_fu_14395_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_677_fu_14242_p4.read()) + sc_biguint<18>(add_ln703_683_fu_14395_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_685_fu_14407_p2() {
    add_ln703_685_fu_14407_p2 = (!add_ln703_682_fu_14389_p2.read().is_01() || !add_ln703_684_fu_14401_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_682_fu_14389_p2.read()) + sc_biguint<18>(add_ln703_684_fu_14401_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_686_fu_14413_p2() {
    add_ln703_686_fu_14413_p2 = (!trunc_ln708_682_fu_14291_p4.read().is_01() || !trunc_ln708_680_fu_14269_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_682_fu_14291_p4.read()) + sc_biguint<18>(trunc_ln708_680_fu_14269_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_687_fu_14419_p2() {
    add_ln703_687_fu_14419_p2 = (!trunc_ln708_686_fu_14331_p4.read().is_01() || !trunc_ln708_685_fu_14322_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_686_fu_14331_p4.read()) + sc_biguint<18>(trunc_ln708_685_fu_14322_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_688_fu_14425_p2() {
    add_ln703_688_fu_14425_p2 = (!trunc_ln708_684_fu_14313_p4.read().is_01() || !add_ln703_687_fu_14419_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_684_fu_14313_p4.read()) + sc_biguint<18>(add_ln703_687_fu_14419_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_689_fu_26266_p2() {
    add_ln703_689_fu_26266_p2 = (!add_ln703_686_reg_36051.read().is_01() || !add_ln703_688_reg_36056.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_686_reg_36051.read()) + sc_biguint<18>(add_ln703_688_reg_36056.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_68_fu_2753_p2() {
    add_ln703_68_fu_2753_p2 = (!trunc_ln708_78_fu_2648_p4.read().is_01() || !trunc_ln708_77_fu_2619_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_78_fu_2648_p4.read()) + sc_biguint<18>(trunc_ln708_77_fu_2619_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_690_fu_26270_p2() {
    add_ln703_690_fu_26270_p2 = (!add_ln703_685_reg_36046.read().is_01() || !add_ln703_689_fu_26266_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_685_reg_36046.read()) + sc_biguint<18>(add_ln703_689_fu_26266_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_691_fu_14431_p2() {
    add_ln703_691_fu_14431_p2 = (!trunc_ln708_688_fu_14349_p4.read().is_01() || !trunc_ln708_687_fu_14340_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_688_fu_14349_p4.read()) + sc_biguint<18>(trunc_ln708_687_fu_14340_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_692_fu_14437_p2() {
    add_ln703_692_fu_14437_p2 = (!sext_ln708_163_fu_14229_p1.read().is_01() || !trunc_ln708_691_fu_14380_p4.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_163_fu_14229_p1.read()) + sc_biguint<18>(trunc_ln708_691_fu_14380_p4.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_693_fu_14443_p2() {
    add_ln703_693_fu_14443_p2 = (!trunc_ln708_689_fu_14358_p4.read().is_01() || !add_ln703_692_fu_14437_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_689_fu_14358_p4.read()) + sc_biguint<18>(add_ln703_692_fu_14437_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_694_fu_14449_p2() {
    add_ln703_694_fu_14449_p2 = (!add_ln703_691_fu_14431_p2.read().is_01() || !add_ln703_693_fu_14443_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_691_fu_14431_p2.read()) + sc_biguint<18>(add_ln703_693_fu_14443_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_695_fu_14455_p2() {
    add_ln703_695_fu_14455_p2 = (!sext_ln708_166_fu_14376_p1.read().is_01() || !sext_ln708_165_fu_14309_p1.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_166_fu_14376_p1.read()) + sc_bigint<18>(sext_ln708_165_fu_14309_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_696_fu_14461_p2() {
    add_ln703_696_fu_14461_p2 = (!sext_ln708_164_fu_14287_p1.read().is_01() || !add_ln703_695_fu_14455_p2.read().is_01())? sc_lv<18>(): (sc_bigint<18>(sext_ln708_164_fu_14287_p1.read()) + sc_biguint<18>(add_ln703_695_fu_14455_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_697_fu_14467_p2() {
    add_ln703_697_fu_14467_p2 = (!sext_ln1118_397_fu_14177_p1.read().is_01() || !ap_const_lv14_3FAD.is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_397_fu_14177_p1.read()) + sc_bigint<14>(ap_const_lv14_3FAD));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_698_fu_14477_p2() {
    add_ln703_698_fu_14477_p2 = (!sext_ln1118_396_fu_14154_p1.read().is_01() || !sext_ln703_142_fu_14473_p1.read().is_01())? sc_lv<17>(): (sc_bigint<17>(sext_ln1118_396_fu_14154_p1.read()) + sc_bigint<17>(sext_ln703_142_fu_14473_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_699_fu_14487_p2() {
    add_ln703_699_fu_14487_p2 = (!add_ln703_696_fu_14461_p2.read().is_01() || !sext_ln703_143_fu_14483_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_696_fu_14461_p2.read()) + sc_bigint<18>(sext_ln703_143_fu_14483_p1.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_69_fu_2759_p2() {
    add_ln703_69_fu_2759_p2 = (!trunc_ln708_76_fu_2586_p4.read().is_01() || !add_ln703_68_fu_2753_p2.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_76_fu_2586_p4.read()) + sc_biguint<18>(add_ln703_68_fu_2753_p2.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_700_fu_26275_p2() {
    add_ln703_700_fu_26275_p2 = (!add_ln703_694_reg_36061.read().is_01() || !add_ln703_699_reg_36066.read().is_01())? sc_lv<18>(): (sc_biguint<18>(add_ln703_694_reg_36061.read()) + sc_biguint<18>(add_ln703_699_reg_36066.read()));
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_add_ln703_702_fu_14718_p2() {
    add_ln703_702_fu_14718_p2 = (!trunc_ln708_694_fu_14515_p4.read().is_01() || !trunc_ln708_693_fu_14506_p4.read().is_01())? sc_lv<18>(): (sc_biguint<18>(trunc_ln708_694_fu_14515_p4.read()) + sc_biguint<18>(trunc_ln708_693_fu_14506_p4.read()));
}

}

