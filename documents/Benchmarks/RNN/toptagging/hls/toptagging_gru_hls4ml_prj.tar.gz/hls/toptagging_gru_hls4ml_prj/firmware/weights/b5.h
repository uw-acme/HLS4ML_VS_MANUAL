//Numpy array shape [1]
//Min 0.052419248968
//Max 0.052419248968
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[1];
#else
model_default_t b5[1] = {0.0524192490};
#endif

#endif
