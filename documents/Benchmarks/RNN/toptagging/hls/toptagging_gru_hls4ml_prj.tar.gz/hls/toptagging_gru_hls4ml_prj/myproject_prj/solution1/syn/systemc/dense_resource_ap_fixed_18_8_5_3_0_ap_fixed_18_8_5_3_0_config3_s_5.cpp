#include "dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_246_fu_28747_p0() {
    mul_ln1118_246_fu_28747_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_246_fu_28747_p1() {
    mul_ln1118_246_fu_28747_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE93);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_247_fu_28754_p0() {
    mul_ln1118_247_fu_28754_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_247_fu_28754_p1() {
    mul_ln1118_247_fu_28754_p1 =  (sc_lv<12>) (ap_const_lv28_4F6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_248_fu_28761_p0() {
    mul_ln1118_248_fu_28761_p0 =  (sc_lv<18>) (sext_ln1118_63_fu_2199_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_248_fu_28761_p1() {
    mul_ln1118_248_fu_28761_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF63);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_249_fu_28768_p0() {
    mul_ln1118_249_fu_28768_p0 =  (sc_lv<18>) (sext_ln1118_70_fu_2240_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_249_fu_28768_p1() {
    mul_ln1118_249_fu_28768_p1 =  (sc_lv<9>) (ap_const_lv27_B8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_250_fu_28775_p0() {
    mul_ln1118_250_fu_28775_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_250_fu_28775_p1() {
    mul_ln1118_250_fu_28775_p1 =  (sc_lv<10>) (ap_const_lv28_174);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_251_fu_28782_p0() {
    mul_ln1118_251_fu_28782_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_251_fu_28782_p1() {
    mul_ln1118_251_fu_28782_p1 =  (sc_lv<10>) (ap_const_lv28_1BA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_252_fu_28789_p0() {
    mul_ln1118_252_fu_28789_p0 =  (sc_lv<18>) (sext_ln1118_98_fu_2421_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_252_fu_28789_p1() {
    mul_ln1118_252_fu_28789_p1 =  (sc_lv<7>) (ap_const_lv25_2B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_253_fu_28796_p0() {
    mul_ln1118_253_fu_28796_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_253_fu_28796_p1() {
    mul_ln1118_253_fu_28796_p1 =  (sc_lv<10>) (ap_const_lv28_106);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_254_fu_28803_p0() {
    mul_ln1118_254_fu_28803_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_254_fu_28803_p1() {
    mul_ln1118_254_fu_28803_p1 =  (sc_lv<10>) (ap_const_lv28_172);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_255_fu_28810_p0() {
    mul_ln1118_255_fu_28810_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_255_fu_28810_p1() {
    mul_ln1118_255_fu_28810_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFED3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_256_fu_28817_p0() {
    mul_ln1118_256_fu_28817_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_256_fu_28817_p1() {
    mul_ln1118_256_fu_28817_p1 =  (sc_lv<10>) (ap_const_lv28_16A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_257_fu_28824_p0() {
    mul_ln1118_257_fu_28824_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_257_fu_28824_p1() {
    mul_ln1118_257_fu_28824_p1 =  (sc_lv<10>) (ap_const_lv28_170);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_258_fu_28831_p0() {
    mul_ln1118_258_fu_28831_p0 =  (sc_lv<18>) (sext_ln1118_137_fu_2644_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_258_fu_28831_p1() {
    mul_ln1118_258_fu_28831_p1 =  (sc_lv<9>) (ap_const_lv27_EC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_259_fu_28838_p0() {
    mul_ln1118_259_fu_28838_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_259_fu_28838_p1() {
    mul_ln1118_259_fu_28838_p1 =  (sc_lv<10>) (ap_const_lv28_137);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_260_fu_28845_p0() {
    mul_ln1118_260_fu_28845_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_260_fu_28845_p1() {
    mul_ln1118_260_fu_28845_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD84);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_261_fu_28852_p0() {
    mul_ln1118_261_fu_28852_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_261_fu_28852_p1() {
    mul_ln1118_261_fu_28852_p1 =  (sc_lv<10>) (ap_const_lv28_186);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_262_fu_28859_p0() {
    mul_ln1118_262_fu_28859_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_262_fu_28859_p1() {
    mul_ln1118_262_fu_28859_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD05);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_263_fu_28866_p0() {
    mul_ln1118_263_fu_28866_p0 =  (sc_lv<18>) (sext_ln1118_67_fu_2215_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_263_fu_28866_p1() {
    mul_ln1118_263_fu_28866_p1 =  (sc_lv<8>) (ap_const_lv26_52);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_264_fu_28873_p0() {
    mul_ln1118_264_fu_28873_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_264_fu_28873_p1() {
    mul_ln1118_264_fu_28873_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF55);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_265_fu_28880_p0() {
    mul_ln1118_265_fu_28880_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_265_fu_28880_p1() {
    mul_ln1118_265_fu_28880_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF0E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_266_fu_28887_p0() {
    mul_ln1118_266_fu_28887_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_266_fu_28887_p1() {
    mul_ln1118_266_fu_28887_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC1B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_267_fu_28894_p0() {
    mul_ln1118_267_fu_28894_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_267_fu_28894_p1() {
    mul_ln1118_267_fu_28894_p1 =  (sc_lv<11>) (ap_const_lv28_25D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_268_fu_28901_p0() {
    mul_ln1118_268_fu_28901_p0 =  (sc_lv<18>) (sext_ln1118_137_fu_2644_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_268_fu_28901_p1() {
    mul_ln1118_268_fu_28901_p1 =  (sc_lv<9>) (ap_const_lv27_F2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_269_fu_28908_p0() {
    mul_ln1118_269_fu_28908_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_269_fu_28908_p1() {
    mul_ln1118_269_fu_28908_p1 =  (sc_lv<10>) (ap_const_lv28_12D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_270_fu_28915_p0() {
    mul_ln1118_270_fu_28915_p0 =  (sc_lv<18>) (sext_ln1118_147_fu_2706_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_270_fu_28915_p1() {
    mul_ln1118_270_fu_28915_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF89);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_271_fu_28922_p0() {
    mul_ln1118_271_fu_28922_p0 =  (sc_lv<18>) (sext_ln1118_46_fu_2095_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_271_fu_28922_p1() {
    mul_ln1118_271_fu_28922_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFDB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_272_fu_28929_p0() {
    mul_ln1118_272_fu_28929_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_272_fu_28929_p1() {
    mul_ln1118_272_fu_28929_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB7C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_273_fu_28936_p0() {
    mul_ln1118_273_fu_28936_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_273_fu_28936_p1() {
    mul_ln1118_273_fu_28936_p1 =  (sc_lv<10>) (ap_const_lv28_188);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_274_fu_28943_p0() {
    mul_ln1118_274_fu_28943_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_274_fu_28943_p1() {
    mul_ln1118_274_fu_28943_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC95);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_275_fu_28950_p0() {
    mul_ln1118_275_fu_28950_p0 =  (sc_lv<18>) (sext_ln1118_67_fu_2215_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_275_fu_28950_p1() {
    mul_ln1118_275_fu_28950_p1 =  (sc_lv<8>) (ap_const_lv26_68);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_276_fu_28957_p0() {
    mul_ln1118_276_fu_28957_p0 =  (sc_lv<18>) (sext_ln1118_71_fu_2244_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_276_fu_28957_p1() {
    mul_ln1118_276_fu_28957_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF95);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_277_fu_28964_p0() {
    mul_ln1118_277_fu_28964_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_277_fu_28964_p1() {
    mul_ln1118_277_fu_28964_p1 =  (sc_lv<10>) (ap_const_lv28_1D8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_278_fu_28971_p0() {
    mul_ln1118_278_fu_28971_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_278_fu_28971_p1() {
    mul_ln1118_278_fu_28971_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEB8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_279_fu_28978_p0() {
    mul_ln1118_279_fu_28978_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_279_fu_28978_p1() {
    mul_ln1118_279_fu_28978_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF0E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_280_fu_28985_p0() {
    mul_ln1118_280_fu_28985_p0 =  (sc_lv<18>) (sext_ln1118_97_fu_2417_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_280_fu_28985_p1() {
    mul_ln1118_280_fu_28985_p1 =  (sc_lv<8>) (ap_const_lv26_63);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_281_fu_28992_p0() {
    mul_ln1118_281_fu_28992_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_281_fu_28992_p1() {
    mul_ln1118_281_fu_28992_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE3F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_282_fu_28999_p0() {
    mul_ln1118_282_fu_28999_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_282_fu_28999_p1() {
    mul_ln1118_282_fu_28999_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF27);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_283_fu_29006_p0() {
    mul_ln1118_283_fu_29006_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_283_fu_29006_p1() {
    mul_ln1118_283_fu_29006_p1 =  (sc_lv<9>) (ap_const_lv27_EB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_284_fu_29013_p0() {
    mul_ln1118_284_fu_29013_p0 =  (sc_lv<18>) (sext_ln1118_116_fu_2533_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_284_fu_29013_p1() {
    mul_ln1118_284_fu_29013_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFCA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_285_fu_29020_p0() {
    mul_ln1118_285_fu_29020_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_285_fu_29020_p1() {
    mul_ln1118_285_fu_29020_p1 =  (sc_lv<13>) (ap_const_lv28_FFFF7D0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_286_fu_29027_p0() {
    mul_ln1118_286_fu_29027_p0 =  (sc_lv<18>) (sext_ln1118_130_fu_2607_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_286_fu_29027_p1() {
    mul_ln1118_286_fu_29027_p1 =  (sc_lv<9>) (ap_const_lv27_D3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_287_fu_29034_p0() {
    mul_ln1118_287_fu_29034_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_287_fu_29034_p1() {
    mul_ln1118_287_fu_29034_p1 =  (sc_lv<10>) (ap_const_lv28_1F5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_288_fu_29041_p0() {
    mul_ln1118_288_fu_29041_p0 =  (sc_lv<18>) (sext_ln1118_139_fu_2661_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_288_fu_29041_p1() {
    mul_ln1118_288_fu_29041_p1 =  (sc_lv<9>) (ap_const_lv27_AD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_289_fu_29048_p0() {
    mul_ln1118_289_fu_29048_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_289_fu_29048_p1() {
    mul_ln1118_289_fu_29048_p1 =  (sc_lv<10>) (ap_const_lv28_115);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_290_fu_29055_p0() {
    mul_ln1118_290_fu_29055_p0 =  (sc_lv<18>) (sext_ln1118_44_fu_2087_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_290_fu_29055_p1() {
    mul_ln1118_290_fu_29055_p1 =  (sc_lv<8>) (ap_const_lv26_76);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_291_fu_29062_p0() {
    mul_ln1118_291_fu_29062_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_291_fu_29062_p1() {
    mul_ln1118_291_fu_29062_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC71);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_292_fu_29069_p0() {
    mul_ln1118_292_fu_29069_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_292_fu_29069_p1() {
    mul_ln1118_292_fu_29069_p1 =  (sc_lv<11>) (ap_const_lv28_209);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_293_fu_29076_p0() {
    mul_ln1118_293_fu_29076_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_293_fu_29076_p1() {
    mul_ln1118_293_fu_29076_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB05);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_294_fu_29083_p0() {
    mul_ln1118_294_fu_29083_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_294_fu_29083_p1() {
    mul_ln1118_294_fu_29083_p1 =  (sc_lv<11>) (ap_const_lv28_375);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_295_fu_29090_p0() {
    mul_ln1118_295_fu_29090_p0 =  (sc_lv<18>) (sext_ln1118_70_fu_2240_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_295_fu_29090_p1() {
    mul_ln1118_295_fu_29090_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF75);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_296_fu_29097_p0() {
    mul_ln1118_296_fu_29097_p0 =  (sc_lv<18>) (sext_ln1118_78_fu_2310_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_296_fu_29097_p1() {
    mul_ln1118_296_fu_29097_p1 =  (sc_lv<9>) (ap_const_lv27_92);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_297_fu_29104_p0() {
    mul_ln1118_297_fu_29104_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_297_fu_29104_p1() {
    mul_ln1118_297_fu_29104_p1 =  (sc_lv<9>) (ap_const_lv27_AA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_298_fu_29111_p0() {
    mul_ln1118_298_fu_29111_p0 =  (sc_lv<18>) (sext_ln1118_96_fu_2413_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_298_fu_29111_p1() {
    mul_ln1118_298_fu_29111_p1 =  (sc_lv<9>) (ap_const_lv27_DB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_299_fu_29118_p0() {
    mul_ln1118_299_fu_29118_p0 =  (sc_lv<18>) (sext_ln1118_102_fu_2446_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_299_fu_29118_p1() {
    mul_ln1118_299_fu_29118_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFDD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_300_fu_29125_p0() {
    mul_ln1118_300_fu_29125_p0 =  (sc_lv<18>) (sext_ln1118_106_fu_2471_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_300_fu_29125_p1() {
    mul_ln1118_300_fu_29125_p1 =  (sc_lv<7>) (ap_const_lv25_2C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_301_fu_29132_p0() {
    mul_ln1118_301_fu_29132_p0 =  (sc_lv<18>) (sext_ln1118_113_fu_2512_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_301_fu_29132_p1() {
    mul_ln1118_301_fu_29132_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_302_fu_29139_p0() {
    mul_ln1118_302_fu_29139_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_302_fu_29139_p1() {
    mul_ln1118_302_fu_29139_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE5C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_303_fu_29146_p0() {
    mul_ln1118_303_fu_29146_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_303_fu_29146_p1() {
    mul_ln1118_303_fu_29146_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEE2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_304_fu_29153_p0() {
    mul_ln1118_304_fu_29153_p0 =  (sc_lv<18>) (sext_ln1118_137_fu_2644_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_304_fu_29153_p1() {
    mul_ln1118_304_fu_29153_p1 =  (sc_lv<9>) (ap_const_lv27_99);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_305_fu_29160_p0() {
    mul_ln1118_305_fu_29160_p0 =  (sc_lv<18>) (sext_ln1118_143_fu_2677_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_305_fu_29160_p1() {
    mul_ln1118_305_fu_29160_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF8B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_306_fu_29167_p0() {
    mul_ln1118_306_fu_29167_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_306_fu_29167_p1() {
    mul_ln1118_306_fu_29167_p1 =  (sc_lv<9>) (ap_const_lv27_9B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_307_fu_29174_p0() {
    mul_ln1118_307_fu_29174_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_307_fu_29174_p1() {
    mul_ln1118_307_fu_29174_p1 =  (sc_lv<11>) (ap_const_lv28_25D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_308_fu_29181_p0() {
    mul_ln1118_308_fu_29181_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_308_fu_29181_p1() {
    mul_ln1118_308_fu_29181_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDD0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_309_fu_29188_p0() {
    mul_ln1118_309_fu_29188_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_309_fu_29188_p1() {
    mul_ln1118_309_fu_29188_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB92);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_310_fu_29195_p0() {
    mul_ln1118_310_fu_29195_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_310_fu_29195_p1() {
    mul_ln1118_310_fu_29195_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFAF3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_311_fu_29202_p0() {
    mul_ln1118_311_fu_29202_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_311_fu_29202_p1() {
    mul_ln1118_311_fu_29202_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB30);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_312_fu_29209_p0() {
    mul_ln1118_312_fu_29209_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_312_fu_29209_p1() {
    mul_ln1118_312_fu_29209_p1 =  (sc_lv<11>) (ap_const_lv28_207);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_313_fu_29216_p0() {
    mul_ln1118_313_fu_29216_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_313_fu_29216_p1() {
    mul_ln1118_313_fu_29216_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCBD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_314_fu_29223_p0() {
    mul_ln1118_314_fu_29223_p0 =  (sc_lv<18>) (sext_ln1118_85_fu_2351_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_314_fu_29223_p1() {
    mul_ln1118_314_fu_29223_p1 =  (sc_lv<7>) (ap_const_lv25_2C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_315_fu_29230_p0() {
    mul_ln1118_315_fu_29230_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_315_fu_29230_p1() {
    mul_ln1118_315_fu_29230_p1 =  (sc_lv<10>) (ap_const_lv28_14A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_316_fu_29237_p0() {
    mul_ln1118_316_fu_29237_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_316_fu_29237_p1() {
    mul_ln1118_316_fu_29237_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC24);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_317_fu_29244_p0() {
    mul_ln1118_317_fu_29244_p0 =  (sc_lv<18>) (sext_ln1118_100_fu_2438_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_317_fu_29244_p1() {
    mul_ln1118_317_fu_29244_p1 =  (sc_lv<9>) (ap_const_lv27_ED);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_318_fu_29251_p0() {
    mul_ln1118_318_fu_29251_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_318_fu_29251_p1() {
    mul_ln1118_318_fu_29251_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFA3F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_319_fu_29258_p0() {
    mul_ln1118_319_fu_29258_p0 =  (sc_lv<18>) (sext_ln1118_111_fu_2504_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_319_fu_29258_p1() {
    mul_ln1118_319_fu_29258_p1 =  (sc_lv<8>) (ap_const_lv26_4E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_320_fu_29265_p0() {
    mul_ln1118_320_fu_29265_p0 =  (sc_lv<18>) (sext_ln1118_116_fu_2533_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_320_fu_29265_p1() {
    mul_ln1118_320_fu_29265_p1 =  (sc_lv<7>) (ap_const_lv25_34);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_321_fu_29272_p0() {
    mul_ln1118_321_fu_29272_p0 =  (sc_lv<18>) (sext_ln1118_123_fu_2570_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_321_fu_29272_p1() {
    mul_ln1118_321_fu_29272_p1 =  (sc_lv<9>) (ap_const_lv27_8B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_322_fu_29279_p0() {
    mul_ln1118_322_fu_29279_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_322_fu_29279_p1() {
    mul_ln1118_322_fu_29279_p1 =  (sc_lv<11>) (ap_const_lv28_335);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_323_fu_29286_p0() {
    mul_ln1118_323_fu_29286_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_323_fu_29286_p1() {
    mul_ln1118_323_fu_29286_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_324_fu_29293_p0() {
    mul_ln1118_324_fu_29293_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_324_fu_29293_p1() {
    mul_ln1118_324_fu_29293_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD0C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_325_fu_29300_p0() {
    mul_ln1118_325_fu_29300_p0 =  (sc_lv<18>) (sext_ln1118_146_fu_2702_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_325_fu_29300_p1() {
    mul_ln1118_325_fu_29300_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF0E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_326_fu_29307_p0() {
    mul_ln1118_326_fu_29307_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_326_fu_29307_p1() {
    mul_ln1118_326_fu_29307_p1 =  (sc_lv<11>) (ap_const_lv28_262);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_327_fu_29314_p0() {
    mul_ln1118_327_fu_29314_p0 =  (sc_lv<18>) (sext_ln1118_44_fu_2087_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_327_fu_29314_p1() {
    mul_ln1118_327_fu_29314_p1 =  (sc_lv<8>) (ap_const_lv26_59);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_328_fu_29321_p0() {
    mul_ln1118_328_fu_29321_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_328_fu_29321_p1() {
    mul_ln1118_328_fu_29321_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD02);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_329_fu_29328_p0() {
    mul_ln1118_329_fu_29328_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_329_fu_29328_p1() {
    mul_ln1118_329_fu_29328_p1 =  (sc_lv<11>) (ap_const_lv28_2D1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_330_fu_29335_p0() {
    mul_ln1118_330_fu_29335_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_330_fu_29335_p1() {
    mul_ln1118_330_fu_29335_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC0B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_331_fu_29342_p0() {
    mul_ln1118_331_fu_29342_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_331_fu_29342_p1() {
    mul_ln1118_331_fu_29342_p1 =  (sc_lv<10>) (ap_const_lv28_15E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_332_fu_29349_p0() {
    mul_ln1118_332_fu_29349_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_332_fu_29349_p1() {
    mul_ln1118_332_fu_29349_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE8A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_333_fu_29356_p0() {
    mul_ln1118_333_fu_29356_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_333_fu_29356_p1() {
    mul_ln1118_333_fu_29356_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFED3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_334_fu_29363_p0() {
    mul_ln1118_334_fu_29363_p0 =  (sc_lv<18>) (sext_ln1118_87_fu_2359_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_334_fu_29363_p1() {
    mul_ln1118_334_fu_29363_p1 =  (sc_lv<8>) (ap_const_lv26_47);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_335_fu_29370_p0() {
    mul_ln1118_335_fu_29370_p0 =  (sc_lv<18>) (sext_ln1118_93_fu_2392_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_335_fu_29370_p1() {
    mul_ln1118_335_fu_29370_p1 =  (sc_lv<8>) (ap_const_lv26_5F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_336_fu_29377_p0() {
    mul_ln1118_336_fu_29377_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_336_fu_29377_p1() {
    mul_ln1118_336_fu_29377_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEDF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_337_fu_29384_p0() {
    mul_ln1118_337_fu_29384_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_337_fu_29384_p1() {
    mul_ln1118_337_fu_29384_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEEC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_338_fu_29391_p0() {
    mul_ln1118_338_fu_29391_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_338_fu_29391_p1() {
    mul_ln1118_338_fu_29391_p1 =  (sc_lv<9>) (ap_const_lv27_A5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_339_fu_29398_p0() {
    mul_ln1118_339_fu_29398_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_339_fu_29398_p1() {
    mul_ln1118_339_fu_29398_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE7B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_340_fu_29405_p0() {
    mul_ln1118_340_fu_29405_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_340_fu_29405_p1() {
    mul_ln1118_340_fu_29405_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFECD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_341_fu_29412_p0() {
    mul_ln1118_341_fu_29412_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_341_fu_29412_p1() {
    mul_ln1118_341_fu_29412_p1 =  (sc_lv<11>) (ap_const_lv28_364);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_342_fu_29419_p0() {
    mul_ln1118_342_fu_29419_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_342_fu_29419_p1() {
    mul_ln1118_342_fu_29419_p1 =  (sc_lv<10>) (ap_const_lv28_1A7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_343_fu_29426_p0() {
    mul_ln1118_343_fu_29426_p0 =  (sc_lv<18>) (sext_ln1118_139_fu_2661_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_343_fu_29426_p1() {
    mul_ln1118_343_fu_29426_p1 =  (sc_lv<9>) (ap_const_lv27_D6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_344_fu_29433_p0() {
    mul_ln1118_344_fu_29433_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_344_fu_29433_p1() {
    mul_ln1118_344_fu_29433_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD67);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_345_fu_29440_p0() {
    mul_ln1118_345_fu_29440_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_345_fu_29440_p1() {
    mul_ln1118_345_fu_29440_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE43);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_346_fu_29447_p0() {
    mul_ln1118_346_fu_29447_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_346_fu_29447_p1() {
    mul_ln1118_346_fu_29447_p1 =  (sc_lv<10>) (ap_const_lv28_133);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_347_fu_29454_p0() {
    mul_ln1118_347_fu_29454_p0 =  (sc_lv<18>) (sext_ln1118_55_fu_2149_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_347_fu_29454_p1() {
    mul_ln1118_347_fu_29454_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFAF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_348_fu_29461_p0() {
    mul_ln1118_348_fu_29461_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_348_fu_29461_p1() {
    mul_ln1118_348_fu_29461_p1 =  (sc_lv<12>) (ap_const_lv28_44C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_349_fu_29468_p0() {
    mul_ln1118_349_fu_29468_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_349_fu_29468_p1() {
    mul_ln1118_349_fu_29468_p1 =  (sc_lv<11>) (ap_const_lv28_2EC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_350_fu_29475_p0() {
    mul_ln1118_350_fu_29475_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_350_fu_29475_p1() {
    mul_ln1118_350_fu_29475_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCD0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_351_fu_29482_p0() {
    mul_ln1118_351_fu_29482_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_351_fu_29482_p1() {
    mul_ln1118_351_fu_29482_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCF0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_352_fu_29489_p0() {
    mul_ln1118_352_fu_29489_p0 =  (sc_lv<18>) (sext_ln1118_89_fu_2376_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_352_fu_29489_p1() {
    mul_ln1118_352_fu_29489_p1 =  (sc_lv<7>) (ap_const_lv25_2B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_353_fu_29496_p0() {
    mul_ln1118_353_fu_29496_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_353_fu_29496_p1() {
    mul_ln1118_353_fu_29496_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDC5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_354_fu_29503_p0() {
    mul_ln1118_354_fu_29503_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_354_fu_29503_p1() {
    mul_ln1118_354_fu_29503_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF3F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_355_fu_29510_p0() {
    mul_ln1118_355_fu_29510_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_355_fu_29510_p1() {
    mul_ln1118_355_fu_29510_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE3E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_356_fu_29517_p0() {
    mul_ln1118_356_fu_29517_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_356_fu_29517_p1() {
    mul_ln1118_356_fu_29517_p1 =  (sc_lv<10>) (ap_const_lv28_111);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_357_fu_29524_p0() {
    mul_ln1118_357_fu_29524_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_357_fu_29524_p1() {
    mul_ln1118_357_fu_29524_p1 =  (sc_lv<10>) (ap_const_lv28_194);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_358_fu_29531_p0() {
    mul_ln1118_358_fu_29531_p0 =  (sc_lv<18>) (sext_ln1118_134_fu_2632_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_358_fu_29531_p1() {
    mul_ln1118_358_fu_29531_p1 =  (sc_lv<8>) (ap_const_lv26_52);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_359_fu_29538_p0() {
    mul_ln1118_359_fu_29538_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_359_fu_29538_p1() {
    mul_ln1118_359_fu_29538_p1 =  (sc_lv<10>) (ap_const_lv28_12F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_360_fu_29545_p0() {
    mul_ln1118_360_fu_29545_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_360_fu_29545_p1() {
    mul_ln1118_360_fu_29545_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFBC1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_361_fu_29552_p0() {
    mul_ln1118_361_fu_29552_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_361_fu_29552_p1() {
    mul_ln1118_361_fu_29552_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF24);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_362_fu_29559_p0() {
    mul_ln1118_362_fu_29559_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_362_fu_29559_p1() {
    mul_ln1118_362_fu_29559_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE74);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_363_fu_29566_p0() {
    mul_ln1118_363_fu_29566_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_363_fu_29566_p1() {
    mul_ln1118_363_fu_29566_p1 =  (sc_lv<11>) (ap_const_lv28_327);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_364_fu_29573_p0() {
    mul_ln1118_364_fu_29573_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_364_fu_29573_p1() {
    mul_ln1118_364_fu_29573_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC76);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_365_fu_29580_p0() {
    mul_ln1118_365_fu_29580_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_365_fu_29580_p1() {
    mul_ln1118_365_fu_29580_p1 =  (sc_lv<12>) (ap_const_lv28_52D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_366_fu_29587_p0() {
    mul_ln1118_366_fu_29587_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_366_fu_29587_p1() {
    mul_ln1118_366_fu_29587_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE5E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_367_fu_29594_p0() {
    mul_ln1118_367_fu_29594_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_367_fu_29594_p1() {
    mul_ln1118_367_fu_29594_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE1D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_368_fu_29601_p0() {
    mul_ln1118_368_fu_29601_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_368_fu_29601_p1() {
    mul_ln1118_368_fu_29601_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF5E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_369_fu_29608_p0() {
    mul_ln1118_369_fu_29608_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_369_fu_29608_p1() {
    mul_ln1118_369_fu_29608_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE6E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_370_fu_29615_p0() {
    mul_ln1118_370_fu_29615_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_370_fu_29615_p1() {
    mul_ln1118_370_fu_29615_p1 =  (sc_lv<10>) (ap_const_lv28_1B7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_371_fu_29622_p0() {
    mul_ln1118_371_fu_29622_p0 =  (sc_lv<18>) (sext_ln1118_100_fu_2438_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_371_fu_29622_p1() {
    mul_ln1118_371_fu_29622_p1 =  (sc_lv<9>) (ap_const_lv27_91);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_372_fu_29629_p0() {
    mul_ln1118_372_fu_29629_p0 =  (sc_lv<18>) (sext_ln1118_106_fu_2471_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_372_fu_29629_p1() {
    mul_ln1118_372_fu_29629_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_373_fu_29636_p0() {
    mul_ln1118_373_fu_29636_p0 =  (sc_lv<18>) (sext_ln1118_117_fu_2537_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_373_fu_29636_p1() {
    mul_ln1118_373_fu_29636_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF8B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_374_fu_29643_p0() {
    mul_ln1118_374_fu_29643_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_374_fu_29643_p1() {
    mul_ln1118_374_fu_29643_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFAFF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_375_fu_29650_p0() {
    mul_ln1118_375_fu_29650_p0 =  (sc_lv<18>) (sext_ln1118_129_fu_2603_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_375_fu_29650_p1() {
    mul_ln1118_375_fu_29650_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFA7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_376_fu_29657_p0() {
    mul_ln1118_376_fu_29657_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_376_fu_29657_p1() {
    mul_ln1118_376_fu_29657_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCF4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_377_fu_29664_p0() {
    mul_ln1118_377_fu_29664_p0 =  (sc_lv<18>) (sext_ln1118_143_fu_2677_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_377_fu_29664_p1() {
    mul_ln1118_377_fu_29664_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFA5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_378_fu_29671_p0() {
    mul_ln1118_378_fu_29671_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_378_fu_29671_p1() {
    mul_ln1118_378_fu_29671_p1 =  (sc_lv<10>) (ap_const_lv28_177);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_379_fu_29678_p0() {
    mul_ln1118_379_fu_29678_p0 =  (sc_lv<18>) (sext_ln1118_46_fu_2095_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_379_fu_29678_p1() {
    mul_ln1118_379_fu_29678_p1 =  (sc_lv<7>) (ap_const_lv25_26);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_380_fu_29685_p0() {
    mul_ln1118_380_fu_29685_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_380_fu_29685_p1() {
    mul_ln1118_380_fu_29685_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCD0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_381_fu_29692_p0() {
    mul_ln1118_381_fu_29692_p0 =  (sc_lv<18>) (sext_ln1118_58_fu_2161_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_381_fu_29692_p1() {
    mul_ln1118_381_fu_29692_p1 =  (sc_lv<9>) (ap_const_lv27_D4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_382_fu_29699_p0() {
    mul_ln1118_382_fu_29699_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_382_fu_29699_p1() {
    mul_ln1118_382_fu_29699_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCFD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_383_fu_29706_p0() {
    mul_ln1118_383_fu_29706_p0 =  (sc_lv<18>) (sext_ln1118_63_fu_2199_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_383_fu_29706_p1() {
    mul_ln1118_383_fu_29706_p1 =  (sc_lv<9>) (ap_const_lv27_E4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_384_fu_29713_p0() {
    mul_ln1118_384_fu_29713_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_384_fu_29713_p1() {
    mul_ln1118_384_fu_29713_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEE9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_385_fu_29720_p0() {
    mul_ln1118_385_fu_29720_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_385_fu_29720_p1() {
    mul_ln1118_385_fu_29720_p1 =  (sc_lv<12>) (ap_const_lv28_5AD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_386_fu_29727_p0() {
    mul_ln1118_386_fu_29727_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_386_fu_29727_p1() {
    mul_ln1118_386_fu_29727_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEE7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_387_fu_29734_p0() {
    mul_ln1118_387_fu_29734_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_387_fu_29734_p1() {
    mul_ln1118_387_fu_29734_p1 =  (sc_lv<9>) (ap_const_lv27_D8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_388_fu_29741_p0() {
    mul_ln1118_388_fu_29741_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_388_fu_29741_p1() {
    mul_ln1118_388_fu_29741_p1 =  (sc_lv<12>) (ap_const_lv28_469);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_389_fu_29748_p0() {
    mul_ln1118_389_fu_29748_p0 =  (sc_lv<18>) (sext_ln1118_108_fu_2479_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_389_fu_29748_p1() {
    mul_ln1118_389_fu_29748_p1 =  (sc_lv<8>) (ap_const_lv26_4C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_390_fu_29755_p0() {
    mul_ln1118_390_fu_29755_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_390_fu_29755_p1() {
    mul_ln1118_390_fu_29755_p1 =  (sc_lv<10>) (ap_const_lv28_129);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_391_fu_29762_p0() {
    mul_ln1118_391_fu_29762_p0 =  (sc_lv<18>) (sext_ln1118_120_fu_2549_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_391_fu_29762_p1() {
    mul_ln1118_391_fu_29762_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF51);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_392_fu_29769_p0() {
    mul_ln1118_392_fu_29769_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_392_fu_29769_p1() {
    mul_ln1118_392_fu_29769_p1 =  (sc_lv<13>) (ap_const_lv28_FFFF6C5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_393_fu_29776_p0() {
    mul_ln1118_393_fu_29776_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_393_fu_29776_p1() {
    mul_ln1118_393_fu_29776_p1 =  (sc_lv<10>) (ap_const_lv28_117);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_394_fu_29783_p0() {
    mul_ln1118_394_fu_29783_p0 =  (sc_lv<18>) (sext_ln1118_137_fu_2644_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_394_fu_29783_p1() {
    mul_ln1118_394_fu_29783_p1 =  (sc_lv<9>) (ap_const_lv27_96);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_395_fu_29790_p0() {
    mul_ln1118_395_fu_29790_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_395_fu_29790_p1() {
    mul_ln1118_395_fu_29790_p1 =  (sc_lv<10>) (ap_const_lv28_12C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_396_fu_29797_p0() {
    mul_ln1118_396_fu_29797_p0 =  (sc_lv<18>) (sext_ln1118_146_fu_2702_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_396_fu_29797_p1() {
    mul_ln1118_396_fu_29797_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF74);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_397_fu_29804_p0() {
    mul_ln1118_397_fu_29804_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_397_fu_29804_p1() {
    mul_ln1118_397_fu_29804_p1 =  (sc_lv<11>) (ap_const_lv28_2F6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_398_fu_29811_p0() {
    mul_ln1118_398_fu_29811_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_398_fu_29811_p1() {
    mul_ln1118_398_fu_29811_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC0C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_399_fu_29818_p0() {
    mul_ln1118_399_fu_29818_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_399_fu_29818_p1() {
    mul_ln1118_399_fu_29818_p1 =  (sc_lv<10>) (ap_const_lv28_1E4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_400_fu_29825_p0() {
    mul_ln1118_400_fu_29825_p0 =  (sc_lv<18>) (sext_ln1118_70_fu_2240_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_400_fu_29825_p1() {
    mul_ln1118_400_fu_29825_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF5E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_401_fu_29832_p0() {
    mul_ln1118_401_fu_29832_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_401_fu_29832_p1() {
    mul_ln1118_401_fu_29832_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE4F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_402_fu_29839_p0() {
    mul_ln1118_402_fu_29839_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_402_fu_29839_p1() {
    mul_ln1118_402_fu_29839_p1 =  (sc_lv<10>) (ap_const_lv28_167);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_403_fu_29846_p0() {
    mul_ln1118_403_fu_29846_p0 =  (sc_lv<18>) (sext_ln1118_96_fu_2413_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_403_fu_29846_p1() {
    mul_ln1118_403_fu_29846_p1 =  (sc_lv<9>) (ap_const_lv27_BC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_404_fu_29853_p0() {
    mul_ln1118_404_fu_29853_p0 =  (sc_lv<18>) (sext_ln1118_106_fu_2471_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_404_fu_29853_p1() {
    mul_ln1118_404_fu_29853_p1 =  (sc_lv<7>) (ap_const_lv25_3B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_405_fu_29860_p0() {
    mul_ln1118_405_fu_29860_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_405_fu_29860_p1() {
    mul_ln1118_405_fu_29860_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF22);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_406_fu_29867_p0() {
    mul_ln1118_406_fu_29867_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_406_fu_29867_p1() {
    mul_ln1118_406_fu_29867_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_407_fu_29874_p0() {
    mul_ln1118_407_fu_29874_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_407_fu_29874_p1() {
    mul_ln1118_407_fu_29874_p1 =  (sc_lv<10>) (ap_const_lv28_1E3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_408_fu_29881_p0() {
    mul_ln1118_408_fu_29881_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_408_fu_29881_p1() {
    mul_ln1118_408_fu_29881_p1 =  (sc_lv<10>) (ap_const_lv28_185);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_409_fu_29888_p0() {
    mul_ln1118_409_fu_29888_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_409_fu_29888_p1() {
    mul_ln1118_409_fu_29888_p1 =  (sc_lv<11>) (ap_const_lv28_264);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_410_fu_29895_p0() {
    mul_ln1118_410_fu_29895_p0 =  (sc_lv<18>) (sext_ln1118_139_fu_2661_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_410_fu_29895_p1() {
    mul_ln1118_410_fu_29895_p1 =  (sc_lv<9>) (ap_const_lv27_C1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_411_fu_29902_p0() {
    mul_ln1118_411_fu_29902_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_411_fu_29902_p1() {
    mul_ln1118_411_fu_29902_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEF2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_412_fu_29909_p0() {
    mul_ln1118_412_fu_29909_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_412_fu_29909_p1() {
    mul_ln1118_412_fu_29909_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDD6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_413_fu_29916_p0() {
    mul_ln1118_413_fu_29916_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_413_fu_29916_p1() {
    mul_ln1118_413_fu_29916_p1 =  (sc_lv<10>) (ap_const_lv28_148);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_414_fu_29923_p0() {
    mul_ln1118_414_fu_29923_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_414_fu_29923_p1() {
    mul_ln1118_414_fu_29923_p1 =  (sc_lv<10>) (ap_const_lv28_1C5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_415_fu_29930_p0() {
    mul_ln1118_415_fu_29930_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_415_fu_29930_p1() {
    mul_ln1118_415_fu_29930_p1 =  (sc_lv<10>) (ap_const_lv28_111);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_416_fu_29937_p0() {
    mul_ln1118_416_fu_29937_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_416_fu_29937_p1() {
    mul_ln1118_416_fu_29937_p1 =  (sc_lv<11>) (ap_const_lv28_38C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_417_fu_29944_p0() {
    mul_ln1118_417_fu_29944_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_417_fu_29944_p1() {
    mul_ln1118_417_fu_29944_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDDA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_418_fu_29951_p0() {
    mul_ln1118_418_fu_29951_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_418_fu_29951_p1() {
    mul_ln1118_418_fu_29951_p1 =  (sc_lv<10>) (ap_const_lv28_163);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_419_fu_29958_p0() {
    mul_ln1118_419_fu_29958_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_419_fu_29958_p1() {
    mul_ln1118_419_fu_29958_p1 =  (sc_lv<11>) (ap_const_lv28_215);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_420_fu_29965_p0() {
    mul_ln1118_420_fu_29965_p0 =  (sc_lv<18>) (sext_ln1118_87_fu_2359_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_420_fu_29965_p1() {
    mul_ln1118_420_fu_29965_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF8C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_421_fu_29972_p0() {
    mul_ln1118_421_fu_29972_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_421_fu_29972_p1() {
    mul_ln1118_421_fu_29972_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD95);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_422_fu_29979_p0() {
    mul_ln1118_422_fu_29979_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_422_fu_29979_p1() {
    mul_ln1118_422_fu_29979_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD9C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_423_fu_29986_p0() {
    mul_ln1118_423_fu_29986_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_423_fu_29986_p1() {
    mul_ln1118_423_fu_29986_p1 =  (sc_lv<11>) (ap_const_lv28_22D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_424_fu_29993_p0() {
    mul_ln1118_424_fu_29993_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_424_fu_29993_p1() {
    mul_ln1118_424_fu_29993_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD3E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_425_fu_30000_p0() {
    mul_ln1118_425_fu_30000_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_425_fu_30000_p1() {
    mul_ln1118_425_fu_30000_p1 =  (sc_lv<12>) (ap_const_lv28_41D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_426_fu_30007_p0() {
    mul_ln1118_426_fu_30007_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_426_fu_30007_p1() {
    mul_ln1118_426_fu_30007_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEF7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_427_fu_30014_p0() {
    mul_ln1118_427_fu_30014_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_427_fu_30014_p1() {
    mul_ln1118_427_fu_30014_p1 =  (sc_lv<10>) (ap_const_lv28_1CA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_428_fu_30021_p0() {
    mul_ln1118_428_fu_30021_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_428_fu_30021_p1() {
    mul_ln1118_428_fu_30021_p1 =  (sc_lv<11>) (ap_const_lv28_217);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_429_fu_30028_p0() {
    mul_ln1118_429_fu_30028_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_429_fu_30028_p1() {
    mul_ln1118_429_fu_30028_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFAA6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_430_fu_30035_p0() {
    mul_ln1118_430_fu_30035_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_430_fu_30035_p1() {
    mul_ln1118_430_fu_30035_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF74);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_431_fu_30042_p0() {
    mul_ln1118_431_fu_30042_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_431_fu_30042_p1() {
    mul_ln1118_431_fu_30042_p1 =  (sc_lv<10>) (ap_const_lv28_18B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_432_fu_30049_p0() {
    mul_ln1118_432_fu_30049_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_432_fu_30049_p1() {
    mul_ln1118_432_fu_30049_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE52);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_433_fu_30056_p0() {
    mul_ln1118_433_fu_30056_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_433_fu_30056_p1() {
    mul_ln1118_433_fu_30056_p1 =  (sc_lv<12>) (ap_const_lv28_5CF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_434_fu_30063_p0() {
    mul_ln1118_434_fu_30063_p0 =  (sc_lv<18>) (sext_ln1118_63_fu_2199_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_434_fu_30063_p1() {
    mul_ln1118_434_fu_30063_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF69);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_435_fu_30070_p0() {
    mul_ln1118_435_fu_30070_p0 =  (sc_lv<18>) (sext_ln1118_69_fu_2236_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_435_fu_30070_p1() {
    mul_ln1118_435_fu_30070_p1 =  (sc_lv<6>) (ap_const_lv24_FFFFEA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_436_fu_30077_p0() {
    mul_ln1118_436_fu_30077_p0 =  (sc_lv<18>) (sext_ln1118_77_fu_2306_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_436_fu_30077_p1() {
    mul_ln1118_436_fu_30077_p1 =  (sc_lv<8>) (ap_const_lv26_7A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_437_fu_30084_p0() {
    mul_ln1118_437_fu_30084_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_437_fu_30084_p1() {
    mul_ln1118_437_fu_30084_p1 =  (sc_lv<10>) (ap_const_lv28_1D4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_438_fu_30091_p0() {
    mul_ln1118_438_fu_30091_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_438_fu_30091_p1() {
    mul_ln1118_438_fu_30091_p1 =  (sc_lv<10>) (ap_const_lv28_1CA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_439_fu_30098_p0() {
    mul_ln1118_439_fu_30098_p0 =  (sc_lv<18>) (sext_ln1118_97_fu_2417_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_439_fu_30098_p1() {
    mul_ln1118_439_fu_30098_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFA7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_440_fu_30105_p0() {
    mul_ln1118_440_fu_30105_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_440_fu_30105_p1() {
    mul_ln1118_440_fu_30105_p1 =  (sc_lv<11>) (ap_const_lv28_22C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_441_fu_30112_p0() {
    mul_ln1118_441_fu_30112_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_441_fu_30112_p1() {
    mul_ln1118_441_fu_30112_p1 =  (sc_lv<10>) (ap_const_lv28_1F4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_442_fu_30119_p0() {
    mul_ln1118_442_fu_30119_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_442_fu_30119_p1() {
    mul_ln1118_442_fu_30119_p1 =  (sc_lv<9>) (ap_const_lv27_C4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_443_fu_30126_p0() {
    mul_ln1118_443_fu_30126_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_443_fu_30126_p1() {
    mul_ln1118_443_fu_30126_p1 =  (sc_lv<11>) (ap_const_lv28_2CB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_444_fu_30133_p0() {
    mul_ln1118_444_fu_30133_p0 =  (sc_lv<18>) (sext_ln1118_130_fu_2607_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_444_fu_30133_p1() {
    mul_ln1118_444_fu_30133_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF74);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_445_fu_30140_p0() {
    mul_ln1118_445_fu_30140_p0 =  (sc_lv<18>) (sext_ln1118_139_fu_2661_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_445_fu_30140_p1() {
    mul_ln1118_445_fu_30140_p1 =  (sc_lv<9>) (ap_const_lv27_99);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_446_fu_30147_p0() {
    mul_ln1118_446_fu_30147_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_446_fu_30147_p1() {
    mul_ln1118_446_fu_30147_p1 =  (sc_lv<11>) (ap_const_lv28_353);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_447_fu_30154_p0() {
    mul_ln1118_447_fu_30154_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_447_fu_30154_p1() {
    mul_ln1118_447_fu_30154_p1 =  (sc_lv<10>) (ap_const_lv28_127);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_448_fu_30161_p0() {
    mul_ln1118_448_fu_30161_p0 =  (sc_lv<18>) (sext_ln1118_52_fu_2128_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_448_fu_30161_p1() {
    mul_ln1118_448_fu_30161_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFAB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_449_fu_10986_p0() {
    mul_ln1118_449_fu_10986_p0 = sext_ln1118_56_fu_2153_p0.read();
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_449_fu_10986_p2() {
    mul_ln1118_449_fu_10986_p2 = (!mul_ln1118_449_fu_10986_p0.read().is_01() || !ap_const_lv23_B.is_01())? sc_lv<23>(): sc_bigint<18>(mul_ln1118_449_fu_10986_p0.read()) * sc_biguint<23>(ap_const_lv23_B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_450_fu_30168_p0() {
    mul_ln1118_450_fu_30168_p0 =  (sc_lv<18>) (sext_ln1118_59_fu_2174_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_450_fu_30168_p1() {
    mul_ln1118_450_fu_30168_p1 =  (sc_lv<8>) (ap_const_lv26_68);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_451_fu_30175_p0() {
    mul_ln1118_451_fu_30175_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_451_fu_30175_p1() {
    mul_ln1118_451_fu_30175_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD3C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_452_fu_30182_p0() {
    mul_ln1118_452_fu_30182_p0 =  (sc_lv<18>) (sext_ln1118_78_fu_2310_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_452_fu_30182_p1() {
    mul_ln1118_452_fu_30182_p1 =  (sc_lv<9>) (ap_const_lv27_94);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_453_fu_30189_p0() {
    mul_ln1118_453_fu_30189_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_453_fu_30189_p1() {
    mul_ln1118_453_fu_30189_p1 =  (sc_lv<13>) (ap_const_lv28_FFFF735);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_454_fu_30196_p0() {
    mul_ln1118_454_fu_30196_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_454_fu_30196_p1() {
    mul_ln1118_454_fu_30196_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD8C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_455_fu_30203_p0() {
    mul_ln1118_455_fu_30203_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_455_fu_30203_p1() {
    mul_ln1118_455_fu_30203_p1 =  (sc_lv<10>) (ap_const_lv28_1A8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_456_fu_30210_p0() {
    mul_ln1118_456_fu_30210_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_456_fu_30210_p1() {
    mul_ln1118_456_fu_30210_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD2C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_457_fu_30217_p0() {
    mul_ln1118_457_fu_30217_p0 =  (sc_lv<18>) (sext_ln1118_108_fu_2479_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_457_fu_30217_p1() {
    mul_ln1118_457_fu_30217_p1 =  (sc_lv<8>) (ap_const_lv26_4A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_458_fu_30224_p0() {
    mul_ln1118_458_fu_30224_p0 =  (sc_lv<18>) (sext_ln1118_111_fu_2504_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_458_fu_30224_p1() {
    mul_ln1118_458_fu_30224_p1 =  (sc_lv<8>) (ap_const_lv26_75);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_459_fu_30231_p0() {
    mul_ln1118_459_fu_30231_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_459_fu_30231_p1() {
    mul_ln1118_459_fu_30231_p1 =  (sc_lv<13>) (ap_const_lv28_FFFF690);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_460_fu_30238_p0() {
    mul_ln1118_460_fu_30238_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_460_fu_30238_p1() {
    mul_ln1118_460_fu_30238_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE1B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_461_fu_30245_p0() {
    mul_ln1118_461_fu_30245_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_461_fu_30245_p1() {
    mul_ln1118_461_fu_30245_p1 =  (sc_lv<12>) (ap_const_lv28_43F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_462_fu_30252_p0() {
    mul_ln1118_462_fu_30252_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_462_fu_30252_p1() {
    mul_ln1118_462_fu_30252_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC53);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_463_fu_30259_p0() {
    mul_ln1118_463_fu_30259_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_463_fu_30259_p1() {
    mul_ln1118_463_fu_30259_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_464_fu_30266_p0() {
    mul_ln1118_464_fu_30266_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_464_fu_30266_p1() {
    mul_ln1118_464_fu_30266_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC91);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_465_fu_30273_p0() {
    mul_ln1118_465_fu_30273_p0 =  (sc_lv<18>) (sext_ln1118_47_fu_2099_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_465_fu_30273_p1() {
    mul_ln1118_465_fu_30273_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF13);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_466_fu_30280_p0() {
    mul_ln1118_466_fu_30280_p0 =  (sc_lv<18>) (sext_ln1118_51_fu_2124_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_466_fu_30280_p1() {
    mul_ln1118_466_fu_30280_p1 =  (sc_lv<9>) (ap_const_lv27_F1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_467_fu_30287_p0() {
    mul_ln1118_467_fu_30287_p0 =  (sc_lv<18>) (sext_ln1118_58_fu_2161_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_467_fu_30287_p1() {
    mul_ln1118_467_fu_30287_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF07);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_468_fu_30294_p0() {
    mul_ln1118_468_fu_30294_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_468_fu_30294_p1() {
    mul_ln1118_468_fu_30294_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC4E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_469_fu_30301_p0() {
    mul_ln1118_469_fu_30301_p0 =  (sc_lv<18>) (sext_ln1118_70_fu_2240_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_469_fu_30301_p1() {
    mul_ln1118_469_fu_30301_p1 =  (sc_lv<9>) (ap_const_lv27_A3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_470_fu_30308_p0() {
    mul_ln1118_470_fu_30308_p0 =  (sc_lv<18>) (sext_ln1118_78_fu_2310_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_470_fu_30308_p1() {
    mul_ln1118_470_fu_30308_p1 =  (sc_lv<9>) (ap_const_lv27_DD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_471_fu_30315_p0() {
    mul_ln1118_471_fu_30315_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_471_fu_30315_p1() {
    mul_ln1118_471_fu_30315_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD36);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_472_fu_30322_p0() {
    mul_ln1118_472_fu_30322_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_472_fu_30322_p1() {
    mul_ln1118_472_fu_30322_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD7B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_473_fu_30329_p0() {
    mul_ln1118_473_fu_30329_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_473_fu_30329_p1() {
    mul_ln1118_473_fu_30329_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD9A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_474_fu_30336_p0() {
    mul_ln1118_474_fu_30336_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_474_fu_30336_p1() {
    mul_ln1118_474_fu_30336_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD36);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_475_fu_30343_p0() {
    mul_ln1118_475_fu_30343_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_475_fu_30343_p1() {
    mul_ln1118_475_fu_30343_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEAA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_476_fu_30350_p0() {
    mul_ln1118_476_fu_30350_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_476_fu_30350_p1() {
    mul_ln1118_476_fu_30350_p1 =  (sc_lv<12>) (ap_const_lv28_48E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_477_fu_30357_p0() {
    mul_ln1118_477_fu_30357_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_477_fu_30357_p1() {
    mul_ln1118_477_fu_30357_p1 =  (sc_lv<10>) (ap_const_lv28_1FA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_478_fu_30364_p0() {
    mul_ln1118_478_fu_30364_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_478_fu_30364_p1() {
    mul_ln1118_478_fu_30364_p1 =  (sc_lv<11>) (ap_const_lv28_321);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_479_fu_30371_p0() {
    mul_ln1118_479_fu_30371_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_479_fu_30371_p1() {
    mul_ln1118_479_fu_30371_p1 =  (sc_lv<10>) (ap_const_lv28_149);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_480_fu_30378_p0() {
    mul_ln1118_480_fu_30378_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_480_fu_30378_p1() {
    mul_ln1118_480_fu_30378_p1 =  (sc_lv<11>) (ap_const_lv28_251);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_481_fu_30385_p0() {
    mul_ln1118_481_fu_30385_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_481_fu_30385_p1() {
    mul_ln1118_481_fu_30385_p1 =  (sc_lv<9>) (ap_const_lv27_8E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_482_fu_30392_p0() {
    mul_ln1118_482_fu_30392_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_482_fu_30392_p1() {
    mul_ln1118_482_fu_30392_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE37);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_483_fu_30399_p0() {
    mul_ln1118_483_fu_30399_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_483_fu_30399_p1() {
    mul_ln1118_483_fu_30399_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE19);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_484_fu_30406_p0() {
    mul_ln1118_484_fu_30406_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_484_fu_30406_p1() {
    mul_ln1118_484_fu_30406_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC82);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_485_fu_30413_p0() {
    mul_ln1118_485_fu_30413_p0 =  (sc_lv<18>) (sext_ln1118_63_fu_2199_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_485_fu_30413_p1() {
    mul_ln1118_485_fu_30413_p1 =  (sc_lv<9>) (ap_const_lv27_A5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_486_fu_30420_p0() {
    mul_ln1118_486_fu_30420_p0 =  (sc_lv<18>) (sext_ln1118_72_fu_2248_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_486_fu_30420_p1() {
    mul_ln1118_486_fu_30420_p1 =  (sc_lv<7>) (ap_const_lv25_3D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_487_fu_30427_p0() {
    mul_ln1118_487_fu_30427_p0 =  (sc_lv<18>) (sext_ln1118_78_fu_2310_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_487_fu_30427_p1() {
    mul_ln1118_487_fu_30427_p1 =  (sc_lv<9>) (ap_const_lv27_A1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_488_fu_30434_p0() {
    mul_ln1118_488_fu_30434_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_488_fu_30434_p1() {
    mul_ln1118_488_fu_30434_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF4A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_489_fu_30441_p0() {
    mul_ln1118_489_fu_30441_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_489_fu_30441_p1() {
    mul_ln1118_489_fu_30441_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDB7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_490_fu_30448_p0() {
    mul_ln1118_490_fu_30448_p0 =  (sc_lv<18>) (sext_ln1118_96_fu_2413_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_490_fu_30448_p1() {
    mul_ln1118_490_fu_30448_p1 =  (sc_lv<9>) (ap_const_lv27_C5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_491_fu_30455_p0() {
    mul_ln1118_491_fu_30455_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_491_fu_30455_p1() {
    mul_ln1118_491_fu_30455_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD09);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_492_fu_30462_p0() {
    mul_ln1118_492_fu_30462_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_492_fu_30462_p1() {
    mul_ln1118_492_fu_30462_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF0C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_493_fu_30469_p0() {
    mul_ln1118_493_fu_30469_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_493_fu_30469_p1() {
    mul_ln1118_493_fu_30469_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF0E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_494_fu_30476_p0() {
    mul_ln1118_494_fu_30476_p0 =  (sc_lv<18>) (sext_ln1118_120_fu_2549_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_494_fu_30476_p1() {
    mul_ln1118_494_fu_30476_p1 =  (sc_lv<9>) (ap_const_lv27_B5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_495_fu_30483_p0() {
    mul_ln1118_495_fu_30483_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_495_fu_30483_p1() {
    mul_ln1118_495_fu_30483_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD7A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_496_fu_30490_p0() {
    mul_ln1118_496_fu_30490_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_496_fu_30490_p1() {
    mul_ln1118_496_fu_30490_p1 =  (sc_lv<11>) (ap_const_lv28_385);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_497_fu_30497_p0() {
    mul_ln1118_497_fu_30497_p0 =  (sc_lv<18>) (sext_ln1118_135_fu_2636_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_497_fu_30497_p1() {
    mul_ln1118_497_fu_30497_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFCF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_498_fu_30504_p0() {
    mul_ln1118_498_fu_30504_p0 =  (sc_lv<18>) (sext_ln1118_141_fu_2669_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_498_fu_30504_p1() {
    mul_ln1118_498_fu_30504_p1 =  (sc_lv<7>) (ap_const_lv25_33);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_499_fu_30511_p0() {
    mul_ln1118_499_fu_30511_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_499_fu_30511_p1() {
    mul_ln1118_499_fu_30511_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDD1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_500_fu_30518_p0() {
    mul_ln1118_500_fu_30518_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_500_fu_30518_p1() {
    mul_ln1118_500_fu_30518_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEBB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_501_fu_30525_p0() {
    mul_ln1118_501_fu_30525_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_501_fu_30525_p1() {
    mul_ln1118_501_fu_30525_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEE9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_502_fu_30532_p0() {
    mul_ln1118_502_fu_30532_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_502_fu_30532_p1() {
    mul_ln1118_502_fu_30532_p1 =  (sc_lv<12>) (ap_const_lv28_5D6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_503_fu_30539_p0() {
    mul_ln1118_503_fu_30539_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_503_fu_30539_p1() {
    mul_ln1118_503_fu_30539_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE81);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_504_fu_30546_p0() {
    mul_ln1118_504_fu_30546_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_504_fu_30546_p1() {
    mul_ln1118_504_fu_30546_p1 =  (sc_lv<10>) (ap_const_lv28_1F3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_505_fu_30553_p0() {
    mul_ln1118_505_fu_30553_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_505_fu_30553_p1() {
    mul_ln1118_505_fu_30553_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDF7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_506_fu_30560_p0() {
    mul_ln1118_506_fu_30560_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_506_fu_30560_p1() {
    mul_ln1118_506_fu_30560_p1 =  (sc_lv<11>) (ap_const_lv28_22B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_507_fu_30567_p0() {
    mul_ln1118_507_fu_30567_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_507_fu_30567_p1() {
    mul_ln1118_507_fu_30567_p1 =  (sc_lv<11>) (ap_const_lv28_257);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_508_fu_30574_p0() {
    mul_ln1118_508_fu_30574_p0 =  (sc_lv<18>) (sext_ln1118_103_fu_2450_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_508_fu_30574_p1() {
    mul_ln1118_508_fu_30574_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF8C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_509_fu_30581_p0() {
    mul_ln1118_509_fu_30581_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_509_fu_30581_p1() {
    mul_ln1118_509_fu_30581_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC84);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_510_fu_30588_p0() {
    mul_ln1118_510_fu_30588_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_510_fu_30588_p1() {
    mul_ln1118_510_fu_30588_p1 =  (sc_lv<12>) (ap_const_lv28_61C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_511_fu_30595_p0() {
    mul_ln1118_511_fu_30595_p0 =  (sc_lv<18>) (sext_ln1118_130_fu_2607_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_511_fu_30595_p1() {
    mul_ln1118_511_fu_30595_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF18);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_512_fu_30602_p0() {
    mul_ln1118_512_fu_30602_p0 =  (sc_lv<18>) (sext_ln1118_135_fu_2636_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_512_fu_30602_p1() {
    mul_ln1118_512_fu_30602_p1 =  (sc_lv<7>) (ap_const_lv25_2C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_513_fu_30609_p0() {
    mul_ln1118_513_fu_30609_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_513_fu_30609_p1() {
    mul_ln1118_513_fu_30609_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE39);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_514_fu_30616_p0() {
    mul_ln1118_514_fu_30616_p0 =  (sc_lv<18>) (sext_ln1118_146_fu_2702_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_514_fu_30616_p1() {
    mul_ln1118_514_fu_30616_p1 =  (sc_lv<9>) (ap_const_lv27_F3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_515_fu_30623_p0() {
    mul_ln1118_515_fu_30623_p0 =  (sc_lv<18>) (sext_ln1118_47_fu_2099_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_515_fu_30623_p1() {
    mul_ln1118_515_fu_30623_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF09);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_516_fu_30630_p0() {
    mul_ln1118_516_fu_30630_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_516_fu_30630_p1() {
    mul_ln1118_516_fu_30630_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDF5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_517_fu_30637_p0() {
    mul_ln1118_517_fu_30637_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_517_fu_30637_p1() {
    mul_ln1118_517_fu_30637_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDEE);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_518_fu_30644_p0() {
    mul_ln1118_518_fu_30644_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_518_fu_30644_p1() {
    mul_ln1118_518_fu_30644_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE77);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_519_fu_30651_p0() {
    mul_ln1118_519_fu_30651_p0 =  (sc_lv<18>) (sext_ln1118_67_fu_2215_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_519_fu_30651_p1() {
    mul_ln1118_519_fu_30651_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF97);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_520_fu_30658_p0() {
    mul_ln1118_520_fu_30658_p0 =  (sc_lv<18>) (sext_ln1118_72_fu_2248_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_520_fu_30658_p1() {
    mul_ln1118_520_fu_30658_p1 =  (sc_lv<7>) (ap_const_lv25_2F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_521_fu_30665_p0() {
    mul_ln1118_521_fu_30665_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_521_fu_30665_p1() {
    mul_ln1118_521_fu_30665_p1 =  (sc_lv<10>) (ap_const_lv28_153);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_522_fu_30672_p0() {
    mul_ln1118_522_fu_30672_p0 =  (sc_lv<18>) (sext_ln1118_86_fu_2355_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_522_fu_30672_p1() {
    mul_ln1118_522_fu_30672_p1 =  (sc_lv<6>) (ap_const_lv24_FFFFE7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_523_fu_30679_p0() {
    mul_ln1118_523_fu_30679_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_523_fu_30679_p1() {
    mul_ln1118_523_fu_30679_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE9D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_524_fu_30686_p0() {
    mul_ln1118_524_fu_30686_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_524_fu_30686_p1() {
    mul_ln1118_524_fu_30686_p1 =  (sc_lv<10>) (ap_const_lv28_1D6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_525_fu_30693_p0() {
    mul_ln1118_525_fu_30693_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_525_fu_30693_p1() {
    mul_ln1118_525_fu_30693_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD8D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_526_fu_30700_p0() {
    mul_ln1118_526_fu_30700_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_526_fu_30700_p1() {
    mul_ln1118_526_fu_30700_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF57);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_527_fu_30707_p0() {
    mul_ln1118_527_fu_30707_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_527_fu_30707_p1() {
    mul_ln1118_527_fu_30707_p1 =  (sc_lv<9>) (ap_const_lv27_CC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_528_fu_30714_p0() {
    mul_ln1118_528_fu_30714_p0 =  (sc_lv<18>) (sext_ln1118_117_fu_2537_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_528_fu_30714_p1() {
    mul_ln1118_528_fu_30714_p1 =  (sc_lv<8>) (ap_const_lv26_66);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_529_fu_30721_p0() {
    mul_ln1118_529_fu_30721_p0 =  (sc_lv<18>) (sext_ln1118_124_fu_2574_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_529_fu_30721_p1() {
    mul_ln1118_529_fu_30721_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF97);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_530_fu_30728_p0() {
    mul_ln1118_530_fu_30728_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_530_fu_30728_p1() {
    mul_ln1118_530_fu_30728_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEC3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_531_fu_30735_p0() {
    mul_ln1118_531_fu_30735_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_531_fu_30735_p1() {
    mul_ln1118_531_fu_30735_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDBE);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_532_fu_30742_p0() {
    mul_ln1118_532_fu_30742_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_532_fu_30742_p1() {
    mul_ln1118_532_fu_30742_p1 =  (sc_lv<10>) (ap_const_lv28_1A4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_533_fu_30749_p0() {
    mul_ln1118_533_fu_30749_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_533_fu_30749_p1() {
    mul_ln1118_533_fu_30749_p1 =  (sc_lv<11>) (ap_const_lv28_228);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_534_fu_30756_p0() {
    mul_ln1118_534_fu_30756_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_534_fu_30756_p1() {
    mul_ln1118_534_fu_30756_p1 =  (sc_lv<10>) (ap_const_lv28_179);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_535_fu_30763_p0() {
    mul_ln1118_535_fu_30763_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_535_fu_30763_p1() {
    mul_ln1118_535_fu_30763_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD48);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_536_fu_30770_p0() {
    mul_ln1118_536_fu_30770_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_536_fu_30770_p1() {
    mul_ln1118_536_fu_30770_p1 =  (sc_lv<11>) (ap_const_lv28_347);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_537_fu_30777_p0() {
    mul_ln1118_537_fu_30777_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_537_fu_30777_p1() {
    mul_ln1118_537_fu_30777_p1 =  (sc_lv<11>) (ap_const_lv28_295);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_538_fu_30784_p0() {
    mul_ln1118_538_fu_30784_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_538_fu_30784_p1() {
    mul_ln1118_538_fu_30784_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD32);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_539_fu_30791_p0() {
    mul_ln1118_539_fu_30791_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_539_fu_30791_p1() {
    mul_ln1118_539_fu_30791_p1 =  (sc_lv<10>) (ap_const_lv28_1D2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_540_fu_30798_p0() {
    mul_ln1118_540_fu_30798_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_540_fu_30798_p1() {
    mul_ln1118_540_fu_30798_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF79);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_541_fu_30805_p0() {
    mul_ln1118_541_fu_30805_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_541_fu_30805_p1() {
    mul_ln1118_541_fu_30805_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE96);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_542_fu_30812_p0() {
    mul_ln1118_542_fu_30812_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_542_fu_30812_p1() {
    mul_ln1118_542_fu_30812_p1 =  (sc_lv<10>) (ap_const_lv28_170);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_543_fu_30819_p0() {
    mul_ln1118_543_fu_30819_p0 =  (sc_lv<18>) (sext_ln1118_100_fu_2438_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_543_fu_30819_p1() {
    mul_ln1118_543_fu_30819_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF65);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_544_fu_30826_p0() {
    mul_ln1118_544_fu_30826_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_544_fu_30826_p1() {
    mul_ln1118_544_fu_30826_p1 =  (sc_lv<10>) (ap_const_lv28_1EF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_545_fu_30833_p0() {
    mul_ln1118_545_fu_30833_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_545_fu_30833_p1() {
    mul_ln1118_545_fu_30833_p1 =  (sc_lv<10>) (ap_const_lv28_13A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_546_fu_30840_p0() {
    mul_ln1118_546_fu_30840_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_546_fu_30840_p1() {
    mul_ln1118_546_fu_30840_p1 =  (sc_lv<11>) (ap_const_lv28_331);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_547_fu_30847_p0() {
    mul_ln1118_547_fu_30847_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_547_fu_30847_p1() {
    mul_ln1118_547_fu_30847_p1 =  (sc_lv<10>) (ap_const_lv28_130);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_548_fu_30854_p0() {
    mul_ln1118_548_fu_30854_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_548_fu_30854_p1() {
    mul_ln1118_548_fu_30854_p1 =  (sc_lv<10>) (ap_const_lv28_132);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_549_fu_30861_p0() {
    mul_ln1118_549_fu_30861_p0 =  (sc_lv<18>) (sext_ln1118_147_fu_2706_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_549_fu_30861_p1() {
    mul_ln1118_549_fu_30861_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFAF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_550_fu_30868_p0() {
    mul_ln1118_550_fu_30868_p0 =  (sc_lv<18>) (sext_ln1118_42_fu_2070_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_550_fu_30868_p1() {
    mul_ln1118_550_fu_30868_p1 =  (sc_lv<8>) (ap_const_lv26_57);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_551_fu_30875_p1() {
    mul_ln1118_551_fu_30875_p1 =  (sc_lv<6>) (ap_const_lv24_FFFFE6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_552_fu_30882_p0() {
    mul_ln1118_552_fu_30882_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_552_fu_30882_p1() {
    mul_ln1118_552_fu_30882_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD26);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_553_fu_30889_p0() {
    mul_ln1118_553_fu_30889_p0 =  (sc_lv<18>) (sext_ln1118_58_fu_2161_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_553_fu_30889_p1() {
    mul_ln1118_553_fu_30889_p1 =  (sc_lv<9>) (ap_const_lv27_CA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_554_fu_30896_p0() {
    mul_ln1118_554_fu_30896_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_554_fu_30896_p1() {
    mul_ln1118_554_fu_30896_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB3B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_555_fu_30903_p0() {
    mul_ln1118_555_fu_30903_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_555_fu_30903_p1() {
    mul_ln1118_555_fu_30903_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF39);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_556_fu_30910_p0() {
    mul_ln1118_556_fu_30910_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_556_fu_30910_p1() {
    mul_ln1118_556_fu_30910_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF63);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_557_fu_30917_p0() {
    mul_ln1118_557_fu_30917_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_557_fu_30917_p1() {
    mul_ln1118_557_fu_30917_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_558_fu_30924_p0() {
    mul_ln1118_558_fu_30924_p0 =  (sc_lv<18>) (sext_ln1118_108_fu_2479_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_558_fu_30924_p1() {
    mul_ln1118_558_fu_30924_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFA7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_559_fu_30931_p0() {
    mul_ln1118_559_fu_30931_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_559_fu_30931_p1() {
    mul_ln1118_559_fu_30931_p1 =  (sc_lv<11>) (ap_const_lv28_2A3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_560_fu_30938_p0() {
    mul_ln1118_560_fu_30938_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_560_fu_30938_p1() {
    mul_ln1118_560_fu_30938_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE0C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_561_fu_30945_p0() {
    mul_ln1118_561_fu_30945_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_561_fu_30945_p1() {
    mul_ln1118_561_fu_30945_p1 =  (sc_lv<11>) (ap_const_lv28_2BC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_562_fu_30952_p0() {
    mul_ln1118_562_fu_30952_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_562_fu_30952_p1() {
    mul_ln1118_562_fu_30952_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFED9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_563_fu_30959_p0() {
    mul_ln1118_563_fu_30959_p0 =  (sc_lv<18>) (sext_ln1118_147_fu_2706_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_563_fu_30959_p1() {
    mul_ln1118_563_fu_30959_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFAD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_564_fu_30966_p0() {
    mul_ln1118_564_fu_30966_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_564_fu_30966_p1() {
    mul_ln1118_564_fu_30966_p1 =  (sc_lv<13>) (ap_const_lv28_FFFF4E6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_565_fu_30973_p0() {
    mul_ln1118_565_fu_30973_p0 =  (sc_lv<18>) (sext_ln1118_47_fu_2099_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_565_fu_30973_p1() {
    mul_ln1118_565_fu_30973_p1 =  (sc_lv<9>) (ap_const_lv27_F2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_566_fu_30980_p0() {
    mul_ln1118_566_fu_30980_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_566_fu_30980_p1() {
    mul_ln1118_566_fu_30980_p1 =  (sc_lv<10>) (ap_const_lv28_159);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_567_fu_30987_p0() {
    mul_ln1118_567_fu_30987_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_567_fu_30987_p1() {
    mul_ln1118_567_fu_30987_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEBD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_568_fu_30994_p0() {
    mul_ln1118_568_fu_30994_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_568_fu_30994_p1() {
    mul_ln1118_568_fu_30994_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD27);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_569_fu_31001_p0() {
    mul_ln1118_569_fu_31001_p0 =  (sc_lv<18>) (sext_ln1118_71_fu_2244_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_569_fu_31001_p1() {
    mul_ln1118_569_fu_31001_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFBB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_570_fu_31008_p0() {
    mul_ln1118_570_fu_31008_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_570_fu_31008_p1() {
    mul_ln1118_570_fu_31008_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_571_fu_31015_p0() {
    mul_ln1118_571_fu_31015_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_571_fu_31015_p1() {
    mul_ln1118_571_fu_31015_p1 =  (sc_lv<12>) (ap_const_lv28_FFFF913);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_572_fu_31022_p0() {
    mul_ln1118_572_fu_31022_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_572_fu_31022_p1() {
    mul_ln1118_572_fu_31022_p1 =  (sc_lv<11>) (ap_const_lv28_39B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_573_fu_31029_p0() {
    mul_ln1118_573_fu_31029_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_573_fu_31029_p1() {
    mul_ln1118_573_fu_31029_p1 =  (sc_lv<12>) (ap_const_lv28_53A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_574_fu_31036_p0() {
    mul_ln1118_574_fu_31036_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_574_fu_31036_p1() {
    mul_ln1118_574_fu_31036_p1 =  (sc_lv<10>) (ap_const_lv28_16D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_575_fu_31043_p0() {
    mul_ln1118_575_fu_31043_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_575_fu_31043_p1() {
    mul_ln1118_575_fu_31043_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE29);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_576_fu_31050_p0() {
    mul_ln1118_576_fu_31050_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_576_fu_31050_p1() {
    mul_ln1118_576_fu_31050_p1 =  (sc_lv<10>) (ap_const_lv28_1A0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_577_fu_31057_p0() {
    mul_ln1118_577_fu_31057_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_577_fu_31057_p1() {
    mul_ln1118_577_fu_31057_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFAFC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_578_fu_31064_p0() {
    mul_ln1118_578_fu_31064_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_578_fu_31064_p1() {
    mul_ln1118_578_fu_31064_p1 =  (sc_lv<11>) (ap_const_lv28_255);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_579_fu_31071_p0() {
    mul_ln1118_579_fu_31071_p0 =  (sc_lv<18>) (sext_ln1118_141_fu_2669_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_579_fu_31071_p1() {
    mul_ln1118_579_fu_31071_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_580_fu_31078_p0() {
    mul_ln1118_580_fu_31078_p0 =  (sc_lv<18>) (sext_ln1118_147_fu_2706_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_580_fu_31078_p1() {
    mul_ln1118_580_fu_31078_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF8D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_581_fu_31085_p0() {
    mul_ln1118_581_fu_31085_p0 =  (sc_lv<18>) (sext_ln1118_42_fu_2070_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_581_fu_31085_p1() {
    mul_ln1118_581_fu_31085_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF9F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_582_fu_31092_p0() {
    mul_ln1118_582_fu_31092_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_582_fu_31092_p1() {
    mul_ln1118_582_fu_31092_p1 =  (sc_lv<12>) (ap_const_lv28_4E5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_583_fu_31099_p0() {
    mul_ln1118_583_fu_31099_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_583_fu_31099_p1() {
    mul_ln1118_583_fu_31099_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE98);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_584_fu_31106_p0() {
    mul_ln1118_584_fu_31106_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_584_fu_31106_p1() {
    mul_ln1118_584_fu_31106_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE67);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_585_fu_31113_p0() {
    mul_ln1118_585_fu_31113_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_585_fu_31113_p1() {
    mul_ln1118_585_fu_31113_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE16);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_586_fu_31120_p0() {
    mul_ln1118_586_fu_31120_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_586_fu_31120_p1() {
    mul_ln1118_586_fu_31120_p1 =  (sc_lv<10>) (ap_const_lv28_18C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_587_fu_31127_p0() {
    mul_ln1118_587_fu_31127_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_587_fu_31127_p1() {
    mul_ln1118_587_fu_31127_p1 =  (sc_lv<12>) (ap_const_lv28_525);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_588_fu_31134_p0() {
    mul_ln1118_588_fu_31134_p0 =  (sc_lv<18>) (sext_ln1118_77_fu_2306_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_588_fu_31134_p1() {
    mul_ln1118_588_fu_31134_p1 =  (sc_lv<8>) (ap_const_lv26_62);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_589_fu_31141_p0() {
    mul_ln1118_589_fu_31141_p0 =  (sc_lv<18>) (sext_ln1118_84_fu_2347_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_589_fu_31141_p1() {
    mul_ln1118_589_fu_31141_p1 =  (sc_lv<9>) (ap_const_lv27_C7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_590_fu_31148_p0() {
    mul_ln1118_590_fu_31148_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_590_fu_31148_p1() {
    mul_ln1118_590_fu_31148_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCD7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_591_fu_31155_p0() {
    mul_ln1118_591_fu_31155_p0 =  (sc_lv<18>) (sext_ln1118_100_fu_2438_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_591_fu_31155_p1() {
    mul_ln1118_591_fu_31155_p1 =  (sc_lv<9>) (ap_const_lv27_DE);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_592_fu_31162_p0() {
    mul_ln1118_592_fu_31162_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_592_fu_31162_p1() {
    mul_ln1118_592_fu_31162_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_593_fu_31169_p0() {
    mul_ln1118_593_fu_31169_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_593_fu_31169_p1() {
    mul_ln1118_593_fu_31169_p1 =  (sc_lv<11>) (ap_const_lv28_24C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_594_fu_31176_p0() {
    mul_ln1118_594_fu_31176_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_594_fu_31176_p1() {
    mul_ln1118_594_fu_31176_p1 =  (sc_lv<12>) (ap_const_lv28_FFFF92F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_595_fu_31183_p0() {
    mul_ln1118_595_fu_31183_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_595_fu_31183_p1() {
    mul_ln1118_595_fu_31183_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDE1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_596_fu_31190_p0() {
    mul_ln1118_596_fu_31190_p0 =  (sc_lv<18>) (sext_ln1118_137_fu_2644_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_596_fu_31190_p1() {
    mul_ln1118_596_fu_31190_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF58);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_597_fu_31197_p0() {
    mul_ln1118_597_fu_31197_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_597_fu_31197_p1() {
    mul_ln1118_597_fu_31197_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB9E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_598_fu_31204_p0() {
    mul_ln1118_598_fu_31204_p0 =  (sc_lv<18>) (sext_ln1118_147_fu_2706_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_598_fu_31204_p1() {
    mul_ln1118_598_fu_31204_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFB3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_599_fu_31211_p0() {
    mul_ln1118_599_fu_31211_p0 =  (sc_lv<18>) (sext_ln1118_42_fu_2070_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_599_fu_31211_p1() {
    mul_ln1118_599_fu_31211_p1 =  (sc_lv<8>) (ap_const_lv26_61);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_600_fu_31218_p0() {
    mul_ln1118_600_fu_31218_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_600_fu_31218_p1() {
    mul_ln1118_600_fu_31218_p1 =  (sc_lv<10>) (ap_const_lv28_1D7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_601_fu_31225_p0() {
    mul_ln1118_601_fu_31225_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_601_fu_31225_p1() {
    mul_ln1118_601_fu_31225_p1 =  (sc_lv<10>) (ap_const_lv28_188);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_602_fu_31232_p0() {
    mul_ln1118_602_fu_31232_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_602_fu_31232_p1() {
    mul_ln1118_602_fu_31232_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE68);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_603_fu_31239_p0() {
    mul_ln1118_603_fu_31239_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_603_fu_31239_p1() {
    mul_ln1118_603_fu_31239_p1 =  (sc_lv<10>) (ap_const_lv28_11F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_604_fu_31246_p0() {
    mul_ln1118_604_fu_31246_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_604_fu_31246_p1() {
    mul_ln1118_604_fu_31246_p1 =  (sc_lv<12>) (ap_const_lv28_53E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_605_fu_31253_p0() {
    mul_ln1118_605_fu_31253_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_605_fu_31253_p1() {
    mul_ln1118_605_fu_31253_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCB8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_606_fu_31260_p0() {
    mul_ln1118_606_fu_31260_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_606_fu_31260_p1() {
    mul_ln1118_606_fu_31260_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF26);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_607_fu_31267_p0() {
    mul_ln1118_607_fu_31267_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_607_fu_31267_p1() {
    mul_ln1118_607_fu_31267_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE77);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_608_fu_31274_p0() {
    mul_ln1118_608_fu_31274_p0 =  (sc_lv<18>) (sext_ln1118_100_fu_2438_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_608_fu_31274_p1() {
    mul_ln1118_608_fu_31274_p1 =  (sc_lv<9>) (ap_const_lv27_DF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_609_fu_31281_p0() {
    mul_ln1118_609_fu_31281_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_609_fu_31281_p1() {
    mul_ln1118_609_fu_31281_p1 =  (sc_lv<10>) (ap_const_lv28_137);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_610_fu_31288_p0() {
    mul_ln1118_610_fu_31288_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_610_fu_31288_p1() {
    mul_ln1118_610_fu_31288_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEB5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_611_fu_31295_p0() {
    mul_ln1118_611_fu_31295_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_611_fu_31295_p1() {
    mul_ln1118_611_fu_31295_p1 =  (sc_lv<12>) (ap_const_lv28_4A7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_612_fu_31302_p0() {
    mul_ln1118_612_fu_31302_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_612_fu_31302_p1() {
    mul_ln1118_612_fu_31302_p1 =  (sc_lv<12>) (ap_const_lv28_FFFF999);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_613_fu_31309_p0() {
    mul_ln1118_613_fu_31309_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_613_fu_31309_p1() {
    mul_ln1118_613_fu_31309_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEA4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_614_fu_31316_p0() {
    mul_ln1118_614_fu_31316_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_614_fu_31316_p1() {
    mul_ln1118_614_fu_31316_p1 =  (sc_lv<11>) (ap_const_lv28_3CE);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_615_fu_31323_p0() {
    mul_ln1118_615_fu_31323_p0 =  (sc_lv<18>) (sext_ln1118_139_fu_2661_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_615_fu_31323_p1() {
    mul_ln1118_615_fu_31323_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF69);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_616_fu_31330_p0() {
    mul_ln1118_616_fu_31330_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_616_fu_31330_p1() {
    mul_ln1118_616_fu_31330_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC58);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_617_fu_31337_p0() {
    mul_ln1118_617_fu_31337_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_617_fu_31337_p1() {
    mul_ln1118_617_fu_31337_p1 =  (sc_lv<9>) (ap_const_lv27_D8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_618_fu_31344_p0() {
    mul_ln1118_618_fu_31344_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_618_fu_31344_p1() {
    mul_ln1118_618_fu_31344_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCAB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_619_fu_31351_p0() {
    mul_ln1118_619_fu_31351_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_619_fu_31351_p1() {
    mul_ln1118_619_fu_31351_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFCBB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_620_fu_31358_p0() {
    mul_ln1118_620_fu_31358_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_620_fu_31358_p1() {
    mul_ln1118_620_fu_31358_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC61);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_621_fu_31365_p0() {
    mul_ln1118_621_fu_31365_p0 =  (sc_lv<18>) (sext_ln1118_63_fu_2199_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_621_fu_31365_p1() {
    mul_ln1118_621_fu_31365_p1 =  (sc_lv<9>) (ap_const_lv27_B3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_622_fu_31372_p0() {
    mul_ln1118_622_fu_31372_p0 =  (sc_lv<18>) (sext_ln1118_69_fu_2236_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_622_fu_31372_p1() {
    mul_ln1118_622_fu_31372_p1 =  (sc_lv<6>) (ap_const_lv24_FFFFE5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_623_fu_31379_p0() {
    mul_ln1118_623_fu_31379_p0 =  (sc_lv<18>) (sext_ln1118_78_fu_2310_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_623_fu_31379_p1() {
    mul_ln1118_623_fu_31379_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF22);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_624_fu_31386_p0() {
    mul_ln1118_624_fu_31386_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_624_fu_31386_p1() {
    mul_ln1118_624_fu_31386_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE3F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_625_fu_31393_p0() {
    mul_ln1118_625_fu_31393_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_625_fu_31393_p1() {
    mul_ln1118_625_fu_31393_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDCC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_626_fu_31400_p0() {
    mul_ln1118_626_fu_31400_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_626_fu_31400_p1() {
    mul_ln1118_626_fu_31400_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE27);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_627_fu_31407_p0() {
    mul_ln1118_627_fu_31407_p0 =  (sc_lv<18>) (sext_ln1118_111_fu_2504_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_627_fu_31407_p1() {
    mul_ln1118_627_fu_31407_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF97);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_628_fu_31414_p0() {
    mul_ln1118_628_fu_31414_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_628_fu_31414_p1() {
    mul_ln1118_628_fu_31414_p1 =  (sc_lv<10>) (ap_const_lv28_15E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_629_fu_31421_p0() {
    mul_ln1118_629_fu_31421_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_629_fu_31421_p1() {
    mul_ln1118_629_fu_31421_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD0E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_630_fu_31428_p0() {
    mul_ln1118_630_fu_31428_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_630_fu_31428_p1() {
    mul_ln1118_630_fu_31428_p1 =  (sc_lv<12>) (ap_const_lv28_661);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_631_fu_31435_p0() {
    mul_ln1118_631_fu_31435_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_631_fu_31435_p1() {
    mul_ln1118_631_fu_31435_p1 =  (sc_lv<10>) (ap_const_lv28_12A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_632_fu_31442_p0() {
    mul_ln1118_632_fu_31442_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_632_fu_31442_p1() {
    mul_ln1118_632_fu_31442_p1 =  (sc_lv<10>) (ap_const_lv28_16D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_633_fu_31449_p0() {
    mul_ln1118_633_fu_31449_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_633_fu_31449_p1() {
    mul_ln1118_633_fu_31449_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDAC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_634_fu_31456_p0() {
    mul_ln1118_634_fu_31456_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_634_fu_31456_p1() {
    mul_ln1118_634_fu_31456_p1 =  (sc_lv<9>) (ap_const_lv27_A7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_635_fu_31463_p0() {
    mul_ln1118_635_fu_31463_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_635_fu_31463_p1() {
    mul_ln1118_635_fu_31463_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEC9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_636_fu_31470_p0() {
    mul_ln1118_636_fu_31470_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_636_fu_31470_p1() {
    mul_ln1118_636_fu_31470_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD9C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_637_fu_31477_p0() {
    mul_ln1118_637_fu_31477_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_637_fu_31477_p1() {
    mul_ln1118_637_fu_31477_p1 =  (sc_lv<11>) (ap_const_lv28_296);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_638_fu_31484_p0() {
    mul_ln1118_638_fu_31484_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_638_fu_31484_p1() {
    mul_ln1118_638_fu_31484_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEDC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_639_fu_31491_p0() {
    mul_ln1118_639_fu_31491_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_639_fu_31491_p1() {
    mul_ln1118_639_fu_31491_p1 =  (sc_lv<10>) (ap_const_lv28_125);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_640_fu_31498_p0() {
    mul_ln1118_640_fu_31498_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_640_fu_31498_p1() {
    mul_ln1118_640_fu_31498_p1 =  (sc_lv<11>) (ap_const_lv28_22B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_641_fu_31505_p0() {
    mul_ln1118_641_fu_31505_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_641_fu_31505_p1() {
    mul_ln1118_641_fu_31505_p1 =  (sc_lv<11>) (ap_const_lv28_23A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_642_fu_31512_p0() {
    mul_ln1118_642_fu_31512_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_642_fu_31512_p1() {
    mul_ln1118_642_fu_31512_p1 =  (sc_lv<9>) (ap_const_lv27_8B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_643_fu_31519_p0() {
    mul_ln1118_643_fu_31519_p0 =  (sc_lv<18>) (sext_ln1118_96_fu_2413_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_643_fu_31519_p1() {
    mul_ln1118_643_fu_31519_p1 =  (sc_lv<9>) (ap_const_lv27_A3);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_644_fu_31526_p0() {
    mul_ln1118_644_fu_31526_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_644_fu_31526_p1() {
    mul_ln1118_644_fu_31526_p1 =  (sc_lv<10>) (ap_const_lv28_19A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_645_fu_31533_p0() {
    mul_ln1118_645_fu_31533_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_645_fu_31533_p1() {
    mul_ln1118_645_fu_31533_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF30);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_646_fu_31540_p0() {
    mul_ln1118_646_fu_31540_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_646_fu_31540_p1() {
    mul_ln1118_646_fu_31540_p1 =  (sc_lv<10>) (ap_const_lv28_147);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_647_fu_31547_p0() {
    mul_ln1118_647_fu_31547_p0 =  (sc_lv<18>) (sext_ln1118_117_fu_2537_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_647_fu_31547_p1() {
    mul_ln1118_647_fu_31547_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFB1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_648_fu_31554_p0() {
    mul_ln1118_648_fu_31554_p0 =  (sc_lv<18>) (sext_ln1118_126_fu_2582_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_648_fu_31554_p1() {
    mul_ln1118_648_fu_31554_p1 =  (sc_lv<6>) (ap_const_lv24_FFFFEA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_649_fu_31561_p0() {
    mul_ln1118_649_fu_31561_p0 =  (sc_lv<18>) (sext_ln1118_135_fu_2636_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_649_fu_31561_p1() {
    mul_ln1118_649_fu_31561_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_650_fu_31568_p0() {
    mul_ln1118_650_fu_31568_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_650_fu_31568_p1() {
    mul_ln1118_650_fu_31568_p1 =  (sc_lv<11>) (ap_const_lv28_326);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_651_fu_31575_p0() {
    mul_ln1118_651_fu_31575_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_651_fu_31575_p1() {
    mul_ln1118_651_fu_31575_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF6F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_652_fu_31582_p0() {
    mul_ln1118_652_fu_31582_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_652_fu_31582_p1() {
    mul_ln1118_652_fu_31582_p1 =  (sc_lv<11>) (ap_const_lv28_227);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_653_fu_31589_p0() {
    mul_ln1118_653_fu_31589_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_653_fu_31589_p1() {
    mul_ln1118_653_fu_31589_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB99);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_654_fu_31596_p0() {
    mul_ln1118_654_fu_31596_p0 =  (sc_lv<18>) (sext_ln1118_53_fu_2141_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_654_fu_31596_p1() {
    mul_ln1118_654_fu_31596_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD4);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_655_fu_31603_p0() {
    mul_ln1118_655_fu_31603_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_655_fu_31603_p1() {
    mul_ln1118_655_fu_31603_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD33);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_656_fu_31610_p0() {
    mul_ln1118_656_fu_31610_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_656_fu_31610_p1() {
    mul_ln1118_656_fu_31610_p1 =  (sc_lv<10>) (ap_const_lv28_1AD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_657_fu_31617_p0() {
    mul_ln1118_657_fu_31617_p0 =  (sc_lv<18>) (sext_ln1118_71_fu_2244_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_657_fu_31617_p1() {
    mul_ln1118_657_fu_31617_p1 =  (sc_lv<8>) (ap_const_lv26_53);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_658_fu_31624_p0() {
    mul_ln1118_658_fu_31624_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_658_fu_31624_p1() {
    mul_ln1118_658_fu_31624_p1 =  (sc_lv<10>) (ap_const_lv28_1BF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_659_fu_31631_p0() {
    mul_ln1118_659_fu_31631_p0 =  (sc_lv<18>) (sext_ln1118_87_fu_2359_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_659_fu_31631_p1() {
    mul_ln1118_659_fu_31631_p1 =  (sc_lv<8>) (ap_const_lv26_73);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_660_fu_31638_p0() {
    mul_ln1118_660_fu_31638_p0 =  (sc_lv<18>) (sext_ln1118_93_fu_2392_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_660_fu_31638_p1() {
    mul_ln1118_660_fu_31638_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF94);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_661_fu_31645_p0() {
    mul_ln1118_661_fu_31645_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_661_fu_31645_p1() {
    mul_ln1118_661_fu_31645_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDFB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_662_fu_31652_p0() {
    mul_ln1118_662_fu_31652_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_662_fu_31652_p1() {
    mul_ln1118_662_fu_31652_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD5E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_663_fu_31659_p0() {
    mul_ln1118_663_fu_31659_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_663_fu_31659_p1() {
    mul_ln1118_663_fu_31659_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEB6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_664_fu_31666_p0() {
    mul_ln1118_664_fu_31666_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_664_fu_31666_p1() {
    mul_ln1118_664_fu_31666_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF65);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_665_fu_31673_p0() {
    mul_ln1118_665_fu_31673_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_665_fu_31673_p1() {
    mul_ln1118_665_fu_31673_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFECF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_666_fu_31680_p0() {
    mul_ln1118_666_fu_31680_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_666_fu_31680_p1() {
    mul_ln1118_666_fu_31680_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFBBA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_667_fu_31687_p0() {
    mul_ln1118_667_fu_31687_p0 =  (sc_lv<18>) (sext_ln1118_130_fu_2607_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_667_fu_31687_p1() {
    mul_ln1118_667_fu_31687_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF61);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_668_fu_31694_p0() {
    mul_ln1118_668_fu_31694_p0 =  (sc_lv<18>) (sext_ln1118_134_fu_2632_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_668_fu_31694_p1() {
    mul_ln1118_668_fu_31694_p1 =  (sc_lv<8>) (ap_const_lv26_53);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_669_fu_31701_p0() {
    mul_ln1118_669_fu_31701_p0 =  (sc_lv<18>) (sext_ln1118_143_fu_2677_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_669_fu_31701_p1() {
    mul_ln1118_669_fu_31701_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFF8F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_670_fu_31708_p0() {
    mul_ln1118_670_fu_31708_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_670_fu_31708_p1() {
    mul_ln1118_670_fu_31708_p1 =  (sc_lv<10>) (ap_const_lv28_16C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_671_fu_31715_p0() {
    mul_ln1118_671_fu_31715_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_671_fu_31715_p1() {
    mul_ln1118_671_fu_31715_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEF5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_672_fu_31722_p0() {
    mul_ln1118_672_fu_31722_p0 =  (sc_lv<18>) (sext_ln1118_47_fu_2099_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_672_fu_31722_p1() {
    mul_ln1118_672_fu_31722_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF76);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_673_fu_31729_p0() {
    mul_ln1118_673_fu_31729_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_673_fu_31729_p1() {
    mul_ln1118_673_fu_31729_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEED);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_674_fu_31736_p0() {
    mul_ln1118_674_fu_31736_p0 =  (sc_lv<18>) (sext_ln1118_59_fu_2174_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_674_fu_31736_p1() {
    mul_ln1118_674_fu_31736_p1 =  (sc_lv<8>) (ap_const_lv26_7D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_675_fu_31743_p0() {
    mul_ln1118_675_fu_31743_p0 =  (sc_lv<18>) (sext_ln1118_72_fu_2248_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_675_fu_31743_p1() {
    mul_ln1118_675_fu_31743_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_676_fu_31750_p0() {
    mul_ln1118_676_fu_31750_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_676_fu_31750_p1() {
    mul_ln1118_676_fu_31750_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDB5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_677_fu_31757_p0() {
    mul_ln1118_677_fu_31757_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_677_fu_31757_p1() {
    mul_ln1118_677_fu_31757_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD18);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_678_fu_31764_p0() {
    mul_ln1118_678_fu_31764_p0 =  (sc_lv<18>) (sext_ln1118_92_fu_2388_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_678_fu_31764_p1() {
    mul_ln1118_678_fu_31764_p1 =  (sc_lv<6>) (ap_const_lv24_1D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_679_fu_31771_p0() {
    mul_ln1118_679_fu_31771_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_679_fu_31771_p1() {
    mul_ln1118_679_fu_31771_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDAB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_680_fu_31778_p0() {
    mul_ln1118_680_fu_31778_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_680_fu_31778_p1() {
    mul_ln1118_680_fu_31778_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD2F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_681_fu_31785_p0() {
    mul_ln1118_681_fu_31785_p0 =  (sc_lv<18>) (sext_ln1118_109_fu_2483_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_681_fu_31785_p1() {
    mul_ln1118_681_fu_31785_p1 =  (sc_lv<9>) (ap_const_lv27_9A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_682_fu_31792_p0() {
    mul_ln1118_682_fu_31792_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_682_fu_31792_p1() {
    mul_ln1118_682_fu_31792_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB5B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_683_fu_31799_p0() {
    mul_ln1118_683_fu_31799_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_683_fu_31799_p1() {
    mul_ln1118_683_fu_31799_p1 =  (sc_lv<12>) (ap_const_lv28_4D0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_684_fu_31806_p0() {
    mul_ln1118_684_fu_31806_p0 =  (sc_lv<18>) (sext_ln1118_123_fu_2570_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_684_fu_31806_p1() {
    mul_ln1118_684_fu_31806_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF1E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_685_fu_31813_p0() {
    mul_ln1118_685_fu_31813_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_685_fu_31813_p1() {
    mul_ln1118_685_fu_31813_p1 =  (sc_lv<10>) (ap_const_lv28_183);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_686_fu_31820_p0() {
    mul_ln1118_686_fu_31820_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_686_fu_31820_p1() {
    mul_ln1118_686_fu_31820_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE8B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_687_fu_31827_p0() {
    mul_ln1118_687_fu_31827_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_687_fu_31827_p1() {
    mul_ln1118_687_fu_31827_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFAF8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_688_fu_31834_p0() {
    mul_ln1118_688_fu_31834_p0 =  (sc_lv<18>) (sext_ln1118_43_fu_2074_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_688_fu_31834_p1() {
    mul_ln1118_688_fu_31834_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF7A);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_689_fu_31841_p0() {
    mul_ln1118_689_fu_31841_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_689_fu_31841_p1() {
    mul_ln1118_689_fu_31841_p1 =  (sc_lv<10>) (ap_const_lv28_1EE);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_690_fu_31848_p0() {
    mul_ln1118_690_fu_31848_p0 =  (sc_lv<18>) (sext_ln1118_51_fu_2124_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_690_fu_31848_p1() {
    mul_ln1118_690_fu_31848_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF6D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_691_fu_31855_p1() {
    mul_ln1118_691_fu_31855_p1 =  (sc_lv<6>) (ap_const_lv24_15);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_692_fu_31862_p0() {
    mul_ln1118_692_fu_31862_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_692_fu_31862_p1() {
    mul_ln1118_692_fu_31862_p1 =  (sc_lv<12>) (ap_const_lv28_4A0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_693_fu_31869_p0() {
    mul_ln1118_693_fu_31869_p0 =  (sc_lv<18>) (sext_ln1118_64_fu_2203_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_693_fu_31869_p1() {
    mul_ln1118_693_fu_31869_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFD6);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_694_fu_31876_p0() {
    mul_ln1118_694_fu_31876_p0 =  (sc_lv<18>) (sext_ln1118_69_fu_2236_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_694_fu_31876_p1() {
    mul_ln1118_694_fu_31876_p1 =  (sc_lv<6>) (ap_const_lv24_FFFFE9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_695_fu_31883_p0() {
    mul_ln1118_695_fu_31883_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_695_fu_31883_p1() {
    mul_ln1118_695_fu_31883_p1 =  (sc_lv<11>) (ap_const_lv28_35C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_696_fu_31890_p0() {
    mul_ln1118_696_fu_31890_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_696_fu_31890_p1() {
    mul_ln1118_696_fu_31890_p1 =  (sc_lv<11>) (ap_const_lv28_2DE);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_697_fu_31897_p0() {
    mul_ln1118_697_fu_31897_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_697_fu_31897_p1() {
    mul_ln1118_697_fu_31897_p1 =  (sc_lv<9>) (ap_const_lv27_BB);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_698_fu_31904_p0() {
    mul_ln1118_698_fu_31904_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_698_fu_31904_p1() {
    mul_ln1118_698_fu_31904_p1 =  (sc_lv<10>) (ap_const_lv28_1B9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_699_fu_31911_p0() {
    mul_ln1118_699_fu_31911_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_699_fu_31911_p1() {
    mul_ln1118_699_fu_31911_p1 =  (sc_lv<11>) (ap_const_lv28_2BD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_700_fu_31918_p0() {
    mul_ln1118_700_fu_31918_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_700_fu_31918_p1() {
    mul_ln1118_700_fu_31918_p1 =  (sc_lv<11>) (ap_const_lv28_278);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_701_fu_31925_p0() {
    mul_ln1118_701_fu_31925_p0 =  (sc_lv<18>) (sext_ln1118_118_fu_2541_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_701_fu_31925_p1() {
    mul_ln1118_701_fu_31925_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE93);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_702_fu_31932_p1() {
    mul_ln1118_702_fu_31932_p1 =  (sc_lv<7>) (ap_const_lv25_1FFFFC7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_703_fu_31939_p0() {
    mul_ln1118_703_fu_31939_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_703_fu_31939_p1() {
    mul_ln1118_703_fu_31939_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE9B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_704_fu_31946_p0() {
    mul_ln1118_704_fu_31946_p0 =  (sc_lv<18>) (sext_ln1118_143_fu_2677_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_704_fu_31946_p1() {
    mul_ln1118_704_fu_31946_p1 =  (sc_lv<8>) (ap_const_lv26_47);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_705_fu_31953_p0() {
    mul_ln1118_705_fu_31953_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_705_fu_31953_p1() {
    mul_ln1118_705_fu_31953_p1 =  (sc_lv<12>) (ap_const_lv28_41D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_706_fu_31960_p0() {
    mul_ln1118_706_fu_31960_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_706_fu_31960_p1() {
    mul_ln1118_706_fu_31960_p1 =  (sc_lv<11>) (ap_const_lv28_2B1);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_707_fu_31967_p0() {
    mul_ln1118_707_fu_31967_p0 =  (sc_lv<18>) (sext_ln1118_44_fu_2087_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_707_fu_31967_p1() {
    mul_ln1118_707_fu_31967_p1 =  (sc_lv<8>) (ap_const_lv26_54);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_708_fu_31974_p0() {
    mul_ln1118_708_fu_31974_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_708_fu_31974_p1() {
    mul_ln1118_708_fu_31974_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFBCC);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_709_fu_31981_p0() {
    mul_ln1118_709_fu_31981_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_709_fu_31981_p1() {
    mul_ln1118_709_fu_31981_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFC9E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_710_fu_31988_p0() {
    mul_ln1118_710_fu_31988_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_710_fu_31988_p1() {
    mul_ln1118_710_fu_31988_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFAA7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_711_fu_31995_p0() {
    mul_ln1118_711_fu_31995_p0 =  (sc_lv<18>) (sext_ln1118_67_fu_2215_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_711_fu_31995_p1() {
    mul_ln1118_711_fu_31995_p1 =  (sc_lv<8>) (ap_const_lv26_46);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_712_fu_32002_p0() {
    mul_ln1118_712_fu_32002_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_712_fu_32002_p1() {
    mul_ln1118_712_fu_32002_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD95);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_713_fu_32009_p0() {
    mul_ln1118_713_fu_32009_p0 =  (sc_lv<18>) (sext_ln1118_83_fu_2343_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_713_fu_32009_p1() {
    mul_ln1118_713_fu_32009_p1 =  (sc_lv<10>) (ap_const_lv28_128);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_714_fu_32016_p0() {
    mul_ln1118_714_fu_32016_p0 =  (sc_lv<18>) (sext_ln1118_90_fu_2380_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_714_fu_32016_p1() {
    mul_ln1118_714_fu_32016_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF1F);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_715_fu_32023_p0() {
    mul_ln1118_715_fu_32023_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_715_fu_32023_p1() {
    mul_ln1118_715_fu_32023_p1 =  (sc_lv<11>) (ap_const_lv28_316);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_716_fu_32030_p0() {
    mul_ln1118_716_fu_32030_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_716_fu_32030_p1() {
    mul_ln1118_716_fu_32030_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE91);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_717_fu_32037_p0() {
    mul_ln1118_717_fu_32037_p0 =  (sc_lv<18>) (sext_ln1118_107_fu_2475_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_717_fu_32037_p1() {
    mul_ln1118_717_fu_32037_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFDED);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_718_fu_32044_p0() {
    mul_ln1118_718_fu_32044_p0 =  (sc_lv<18>) (sext_ln1118_110_fu_2500_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_718_fu_32044_p1() {
    mul_ln1118_718_fu_32044_p1 =  (sc_lv<12>) (ap_const_lv28_441);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_719_fu_32051_p0() {
    mul_ln1118_719_fu_32051_p0 =  (sc_lv<18>) (sext_ln1118_120_fu_2549_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_719_fu_32051_p1() {
    mul_ln1118_719_fu_32051_p1 =  (sc_lv<9>) (ap_const_lv27_83);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_720_fu_32058_p0() {
    mul_ln1118_720_fu_32058_p0 =  (sc_lv<18>) (sext_ln1118_125_fu_2578_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_720_fu_32058_p1() {
    mul_ln1118_720_fu_32058_p1 =  (sc_lv<12>) (ap_const_lv28_FFFFB78);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_721_fu_32065_p0() {
    mul_ln1118_721_fu_32065_p0 =  (sc_lv<18>) (sext_ln1118_128_fu_2599_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_721_fu_32065_p1() {
    mul_ln1118_721_fu_32065_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFE6B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_722_fu_32072_p0() {
    mul_ln1118_722_fu_32072_p0 =  (sc_lv<18>) (sext_ln1118_137_fu_2644_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_722_fu_32072_p1() {
    mul_ln1118_722_fu_32072_p1 =  (sc_lv<9>) (ap_const_lv27_B0);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_723_fu_32079_p0() {
    mul_ln1118_723_fu_32079_p0 =  (sc_lv<18>) (sext_ln1118_139_fu_2661_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_723_fu_32079_p1() {
    mul_ln1118_723_fu_32079_p1 =  (sc_lv<9>) (ap_const_lv27_C8);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_724_fu_32086_p0() {
    mul_ln1118_724_fu_32086_p0 =  (sc_lv<18>) (sext_ln1118_144_fu_2694_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_724_fu_32086_p1() {
    mul_ln1118_724_fu_32086_p1 =  (sc_lv<11>) (ap_const_lv28_2F2);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_725_fu_32093_p0() {
    mul_ln1118_725_fu_32093_p0 =  (sc_lv<18>) (sext_ln1118_47_fu_2099_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_725_fu_32093_p1() {
    mul_ln1118_725_fu_32093_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF3B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_726_fu_32100_p0() {
    mul_ln1118_726_fu_32100_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_726_fu_32100_p1() {
    mul_ln1118_726_fu_32100_p1 =  (sc_lv<11>) (ap_const_lv28_332);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_727_fu_32107_p0() {
    mul_ln1118_727_fu_32107_p0 =  (sc_lv<18>) (sext_ln1118_58_fu_2161_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_727_fu_32107_p1() {
    mul_ln1118_727_fu_32107_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF6C);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_728_fu_32114_p0() {
    mul_ln1118_728_fu_32114_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_728_fu_32114_p1() {
    mul_ln1118_728_fu_32114_p1 =  (sc_lv<11>) (ap_const_lv28_381);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_729_fu_32121_p0() {
    mul_ln1118_729_fu_32121_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_729_fu_32121_p1() {
    mul_ln1118_729_fu_32121_p1 =  (sc_lv<12>) (ap_const_lv28_7DF);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_730_fu_32128_p0() {
    mul_ln1118_730_fu_32128_p0 =  (sc_lv<18>) (sext_ln1118_82_fu_2326_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_730_fu_32128_p1() {
    mul_ln1118_730_fu_32128_p1 =  (sc_lv<10>) (ap_const_lv28_147);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_731_fu_32135_p0() {
    mul_ln1118_731_fu_32135_p0 =  (sc_lv<18>) (sext_ln1118_87_fu_2359_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_731_fu_32135_p1() {
    mul_ln1118_731_fu_32135_p1 =  (sc_lv<8>) (ap_const_lv26_71);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_732_fu_32142_p0() {
    mul_ln1118_732_fu_32142_p0 =  (sc_lv<18>) (sext_ln1118_91_fu_2384_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_732_fu_32142_p1() {
    mul_ln1118_732_fu_32142_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEFA);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_733_fu_32149_p0() {
    mul_ln1118_733_fu_32149_p0 =  (sc_lv<18>) (sext_ln1118_99_fu_2425_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_733_fu_32149_p1() {
    mul_ln1118_733_fu_32149_p1 =  (sc_lv<12>) (ap_const_lv28_432);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_734_fu_32156_p0() {
    mul_ln1118_734_fu_32156_p0 =  (sc_lv<18>) (sext_ln1118_101_fu_2442_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_734_fu_32156_p1() {
    mul_ln1118_734_fu_32156_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEF7);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_735_fu_32163_p0() {
    mul_ln1118_735_fu_32163_p0 =  (sc_lv<18>) (sext_ln1118_112_fu_2508_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_735_fu_32163_p1() {
    mul_ln1118_735_fu_32163_p1 =  (sc_lv<9>) (ap_const_lv27_7FFFF2E);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_736_fu_32170_p0() {
    mul_ln1118_736_fu_32170_p0 =  (sc_lv<18>) (sext_ln1118_124_fu_2574_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_736_fu_32170_p1() {
    mul_ln1118_736_fu_32170_p1 =  (sc_lv<8>) (ap_const_lv26_49);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_737_fu_32177_p0() {
    mul_ln1118_737_fu_32177_p0 =  (sc_lv<18>) (sext_ln1118_129_fu_2603_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_737_fu_32177_p1() {
    mul_ln1118_737_fu_32177_p1 =  (sc_lv<8>) (ap_const_lv26_3FFFFA5);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_738_fu_32184_p0() {
    mul_ln1118_738_fu_32184_p0 =  (sc_lv<18>) (sext_ln1118_133_fu_2628_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_738_fu_32184_p1() {
    mul_ln1118_738_fu_32184_p1 =  (sc_lv<10>) (ap_const_lv28_117);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_739_fu_32191_p0() {
    mul_ln1118_739_fu_32191_p0 =  (sc_lv<18>) (sext_ln1118_138_fu_2657_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_739_fu_32191_p1() {
    mul_ln1118_739_fu_32191_p1 =  (sc_lv<11>) (ap_const_lv28_23D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_740_fu_32198_p0() {
    mul_ln1118_740_fu_32198_p0 =  (sc_lv<18>) (sext_ln1118_146_fu_2702_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_740_fu_32198_p1() {
    mul_ln1118_740_fu_32198_p1 =  (sc_lv<9>) (ap_const_lv27_D9);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_741_fu_32205_p0() {
    mul_ln1118_741_fu_32205_p0 =  (sc_lv<18>) (sext_ln1118_41_fu_2066_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_741_fu_32205_p1() {
    mul_ln1118_741_fu_32205_p1 =  (sc_lv<10>) (ap_const_lv28_16B);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_742_fu_32212_p0() {
    mul_ln1118_742_fu_32212_p0 =  (sc_lv<18>) (sext_ln1118_45_fu_2091_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_742_fu_32212_p1() {
    mul_ln1118_742_fu_32212_p1 =  (sc_lv<11>) (ap_const_lv28_2CD);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_743_fu_32219_p0() {
    mul_ln1118_743_fu_32219_p0 =  (sc_lv<18>) (sext_ln1118_49_fu_2116_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_743_fu_32219_p1() {
    mul_ln1118_743_fu_32219_p1 =  (sc_lv<11>) (ap_const_lv28_FFFFD9D);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_744_fu_32226_p0() {
    mul_ln1118_744_fu_32226_p0 =  (sc_lv<18>) (sext_ln1118_57_fu_2157_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_744_fu_32226_p1() {
    mul_ln1118_744_fu_32226_p1 =  (sc_lv<10>) (ap_const_lv28_165);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_745_fu_32233_p0() {
    mul_ln1118_745_fu_32233_p0 =  (sc_lv<18>) (sext_ln1118_60_fu_2178_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_745_fu_32233_p1() {
    mul_ln1118_745_fu_32233_p1 =  (sc_lv<10>) (ap_const_lv28_FFFFEED);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_746_fu_32240_p0() {
    mul_ln1118_746_fu_32240_p0 =  (sc_lv<18>) (sext_ln1118_62_fu_2195_p1.read());
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_746_fu_32240_p1() {
    mul_ln1118_746_fu_32240_p1 =  (sc_lv<12>) (ap_const_lv28_437);
}

void dense_resource_ap_fixed_18_8_5_3_0_ap_fixed_18_8_5_3_0_config3_s::thread_mul_ln1118_747_fu_32247_p0() {
    mul_ln1118_747_fu_32247_p0 =  (sc_lv<18>) (sext_ln1118_68_fu_2232_p1.read());
}

}

