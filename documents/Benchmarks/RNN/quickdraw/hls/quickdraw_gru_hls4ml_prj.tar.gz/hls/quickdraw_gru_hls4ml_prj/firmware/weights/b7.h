//Numpy array shape [5]
//Min -0.408587753773
//Max 0.611603140831
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
model_default_t b7[5];
#else
model_default_t b7[5] = {-0.1820859462, -0.0957100391, -0.4085877538, 0.6116031408, -0.4016828537};
#endif

#endif
