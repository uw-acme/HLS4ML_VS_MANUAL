//Numpy array shape [10]
//Min -0.022026734427
//Max 0.044509027153
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[10];
#else
model_default_t b5[10] = {-0.0166468993, -0.0220267344, 0.0203714445, -0.0130144702, 0.0008853686, 0.0162781887, 0.0059102476, -0.0192671549, 0.0002445073, 0.0445090272};
#endif

#endif
