//Numpy array shape [3]
//Min -0.017250927165
//Max 0.034020178020
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
model_default_t b7[3];
#else
model_default_t b7[3] = {0.0140909748, 0.0340201780, -0.0172509272};
#endif

#endif
