//Numpy array shape [5]
//Min -0.199007853866
//Max 0.588723540306
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[5];
#else
model_default_t b3[5] = {0.2036757618, 0.5887235403, 0.1964086145, -0.1990078539, 0.3878609538};
#endif

#endif
