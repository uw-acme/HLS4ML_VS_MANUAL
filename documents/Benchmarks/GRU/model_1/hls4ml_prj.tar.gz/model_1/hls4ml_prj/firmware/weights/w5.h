//Numpy array shape [5, 1]
//Min -3.008872985840
//Max 1.449711322784
//Number of zeros 0

#ifndef W5_H_
#define W5_H_

#ifndef __SYNTHESIS__
model_default_t w5[5];
#else
model_default_t w5[5] = {1.4497113228, -3.0088729858, 1.3390139341, -2.2929325104, -1.7744688988};
#endif

#endif
