//Numpy array shape [1]
//Min -0.059671096504
//Max -0.059671096504
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[1];
#else
model_default_t b5[1] = {-0.0596710965};
#endif

#endif
